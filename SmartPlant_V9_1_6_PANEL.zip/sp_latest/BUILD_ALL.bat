@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ============================================================
echo  SMART PLANT - FULL BUILD  (Android APK + PC EXE + Setup.exe)
echo ============================================================
echo.
echo ---- STEP 1 of 2: Android APK ----
call "%~dp0Android_App\BUILD_ANDROID_APK.bat" nopause
if not errorlevel 1 goto step2
echo.
echo WARNING: APK build failed (see Android_App\android_build.log).
echo Setup.exe can still be built, but it will NOT contain the APK.
choice /c YN /m "Continue with PC EXE + Setup.exe anyway"
if errorlevel 2 exit /b 1

:step2
echo.
echo ---- STEP 2 of 2: PC EXE + Setup.exe ----
call "%~dp0PC_App\BUILD_PC_FINAL.bat"
set "RC=%ERRORLEVEL%"
echo.
echo ============================================================
echo  FINAL FILES
echo ============================================================
if exist "%~dp0APK_Output\SmartPlantAndroid.apk" echo  Android APK : %~dp0APK_Output\SmartPlantAndroid.apk
if not exist "%~dp0APK_Output\SmartPlantAndroid.apk" echo  Android APK : NOT BUILT
if exist "%~dp0Setup_Output\SmartPlantIrrigationSystem_Setup.exe" echo  PC Setup    : %~dp0Setup_Output\SmartPlantIrrigationSystem_Setup.exe
if not exist "%~dp0Setup_Output\SmartPlantIrrigationSystem_Setup.exe" echo  PC Setup    : NOT BUILT
echo ============================================================
if "%RC%"=="0" if exist "%~dp0Setup_Output" start "" explorer "%~dp0Setup_Output"
exit /b %RC%
