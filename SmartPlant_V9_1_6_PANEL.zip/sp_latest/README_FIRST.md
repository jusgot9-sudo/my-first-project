# Smart Plant V9.1.3 - build guide (no .bat files)

## setup.exe (Windows) + APK (Android)
**Easiest - GitHub (nothing to install):**
1. Create a GitHub repo, upload this whole folder.
2. Actions tab -> "Build Smart Plant" -> Run workflow.
3. After ~10 min download `SmartPlant-Windows-Setup` (SmartPlantIrrigationSystem_Setup.exe) and `SmartPlantAndroid-apk`.

**Or on your PC:** install Python 3.13, then `python build.py`.

**Everything in one click (Windows):** double-click `BUILD_ALL.bat` -> builds `APK_Output\\SmartPlantAndroid.apk`, the PC EXE and `Setup_Output\\SmartPlantIrrigationSystem_Setup.exe` (APK is embedded in Setup). Needs Python 3.11-3.13 and Android Studio (gives the Android SDK; any JDK 17-21 is picked automatically). APK only: `Android_App\\BUILD_ANDROID_APK.bat`.

**Windows PC-only build:** double-click `PC_App\\BUILD_PC_FINAL.bat` (needs Python 3.11-3.13). It makes an isolated environment, installs requirements, builds the app exe and then `Setup_Output\\SmartPlantIrrigationSystem_Setup.exe`. Log: `PC_App\\pc_build_final.log`.
Android APK: use the GitHub workflow (or Android Studio).

**EXE release security:** `build.py` writes `Setup_Output\\SHA256SUMS.txt`. Optional Authenticode signing: see `EXE_SECURITY_RELEASE.md`.

**PC + Android shared control:** connect the phone to the **PC server address** (not direct ESP32 mode) when you want both screens synchronized.

## Using the app
- The PC app contains its own server - no separate server, nothing to start.
- Settings -> AI & Voice -> paste your Groq API key -> Save. No key = "NO API KEY" message.
- Android app: enter the PC's IP shown in the PC app (same Wi-Fi).
- Local Whisper/Ollama mode (no key): run from source, `pip install -r PC_App/requirements-local-ai.txt`.

## Updating the app (PC + phone) from GitHub
1. Change code, commit, push to GitHub.
2. Create a tag: GitHub -> Releases -> "Draft a new release" -> new tag `v9.1.3` -> Publish
   (or `git tag v9.1.2 && git push origin v9.1.2`).
3. The workflow builds and attaches `SmartPlantIrrigationSystem_Setup.exe` + `SmartPlantAndroid.apk` to that release.
4. In the app: Settings -> App updates -> "Check for updates".
   - PC: "Update now" downloads + installs silently and restarts.
   - Phone: "Download APK" opens the APK; tap it to install over the old app.
5. V9.1.2 also adds phone-first navigation, a bottom tab bar, no pinch zoom and no horizontal scrolling, and a non-blocking startup toast when a newer GitHub release is found.

### One-time setup for phone updates
- Repo must be **Public** (the in-app updater reads GitHub anonymously).
- Settings -> Secrets and variables -> Actions -> New repository secret:
  name `ANDROID_KEYSTORE_BASE64`, value = full text of `ANDROID_KEYSTORE_BASE64.txt` (given separately - never commit it).
  Without it every APK has a different signature and the phone refuses to update in place.

## The installer (custom)
`Installer/ui/` = the setup screens (index.html, css/style.css, js/main.js - edit these to restyle it).
`Installer/installer.py` = copies files, shortcuts, firewall, Windows uninstall entry, Uninstall.exe, silent mode for auto-update.
