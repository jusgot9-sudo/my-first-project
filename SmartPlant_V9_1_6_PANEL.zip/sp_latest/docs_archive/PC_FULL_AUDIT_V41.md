# Smart Plant V41 — PC Full Audit & Fix

## Confirmed PC issues fixed

1. **Startup JavaScript ReferenceError** — `init()` referenced `data.groq_key_set` before any `data` variable existed. This aborted PC initialization. The code now checks the actual local key and loaded config safely.
2. **PC scan capability regression** — after finding the ESP32, the UI switched the Windows app into direct-board mode and disabled PC server/history/plants/settings capabilities. Windows now keeps the local Flask UI/API and the backend talks to the discovered ESP32. Android alone switches to direct-board mode.
3. **Stale build entry points** — `BUILD_ALL_WINDOWS.bat` and `BUILD_RELEASE_AND_SETUP.bat` were still calling the V36 build filename. They now call `BUILD_FINAL_WINDOWS_V41.cmd`.
4. **PC development launcher dependency churn** — `PC_App/run_pc.bat` installed packages on every launch, which could fail on an offline machine before the app even started. It now verifies the installed dependencies and tells the developer to run `build_exe.bat` once when dependencies are missing.
5. **Release hygiene** — removed Python `__pycache__` folders from the packaged source.

## Architecture kept

- Phone -> same Wi-Fi -> ESP32
- PC -> same Wi-Fi -> ESP32
- The PC Flask process is only the local desktop UI/data host; it is not a remote plant server.
- Android uses direct ESP32 transport after discovery.

## Validation

- Python source compiles successfully.
- PC JavaScript parses with Node `--check`.
- HTML id references used by PC JS resolve.
- Installer/build script references point to the active V41 entry point.
- No secret API key is embedded in source.

Physical ESP32/UNO hardware and actual Windows EXE compilation require the target Windows machine and connected hardware, respectively.
