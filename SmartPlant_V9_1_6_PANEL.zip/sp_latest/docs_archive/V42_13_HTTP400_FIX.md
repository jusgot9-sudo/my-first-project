V42.13 HTTP 400 FIX

The active AI path uses only Groq Chat Completions at:
https://api.groq.com/openai/v1/chat/completions

Model: openai/gpt-oss-20b

Fixes:
- JSON mode and structured outputs add include_reasoning=false for GPT-OSS.
- Verification uses 256 completion tokens instead of 16.
- AI chat fallback: plain text only.
- Groq provider JSON error details are surfaced.
- Added PC_App\TEST_GROQ_API.bat to test the exact endpoint without printing the key.
