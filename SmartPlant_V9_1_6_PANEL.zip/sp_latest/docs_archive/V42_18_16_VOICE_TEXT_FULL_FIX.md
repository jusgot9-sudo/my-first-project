# Smart Plant V42.18.16

- Groq Responses API is the primary AI text path; Chat Completions and SDK are fallbacks.
- The current user message is never duplicated in the history sent to Groq.
- PC native voice returns transcript + AI text before TTS; frontend handles Google TTS.
- PC continuous voice waits for TTS completion, then starts the next microphone turn.
- Android continuous voice session state is correctly retained between recognition, AI, and TTS.
- Text send timeout and UI reset are aligned.
- PC and Android share the same versioned frontend asset.
