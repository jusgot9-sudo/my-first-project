# Smart Plant V42.8 - 5-pass audit

## Pass 1 - Secret handling
- No Groq API key is embedded in source, HTML, JavaScript, Android assets, or installer scripts.
- PC backend reads `GROQ_API_KEY` only from the Windows USER environment.
- Legacy persisted `groq_api_key`, `openai_api_key`, and `openweather_api_key` fields are scrubbed from the SQLite config at startup.
- Android no longer stores a Groq key in SharedPreferences.

## Pass 2 - Client UI
- No Groq API key input (`sGroqKey`) remains in the PC or Android dashboard UI.
- No browser/localStorage Groq key persistence remains.
- Voice AI remains the primary interaction path.

## Pass 3 - PC/Android architecture
- PC is the single Groq AI hub.
- Android uses the PC Smart Plant hub over LAN and never needs a second Groq key.
- PC uses the existing Groq AI, Whisper transcription, Orpheus English TTS, and Google TTS fallback paths.

## Pass 4 - Static validation
- `python -m py_compile PC_App/app.py PC_App/launcher.py` passed.
- `node --check PC_App/static/js/app.js` passed.
- `node --check Android_App/app/src/main/assets/ui/js/app.js` passed.
- Static scan found no client-side key persistence.
- Teacher photo hashes are identical in PC and Android assets.

## Pass 5 - Android build state
- The previous `TextToSpeech.getEngines()` static-call compile error is removed in `MainActivity.java`.
- The Android Gradle wrapper could not download Gradle 8.9 in the sandbox because external network access is unavailable. A Windows build is therefore required for final APK compilation.
