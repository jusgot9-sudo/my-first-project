# Smart Plant V42.10 — Groq Chat Completions final patch

- AI provider: Groq only.
- Model: `openai/gpt-oss-20b`.
- AI endpoint: `POST https://api.groq.com/openai/v1/chat/completions`.
- Python SDK: `groq` only for AI text generation.
- Structured Outputs use strict JSON Schema for the Smart Plant control envelope.
- Earlier compatibility notes are historical; V42.15 no longer sends JSON Object or JSON Schema response formats for AI chat.
- Verification endpoint now uses Chat Completions rather than the beta Responses API.
- Groq Whisper and Orpheus TTS remain enabled.
- Windows native voice capture/playback remains enabled.
- Provider: Groq only. No OpenAI API key, OpenAI endpoint, or OpenAI SDK is used.
- Android continues to use the same Settings field and PC hub/LAN architecture.
