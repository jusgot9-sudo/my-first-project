SMART PLANT SYSTEM — ANDROID CLIENT V4
======================================

The app opens directly through the Cyberpunk boot screen. There is no login
screen. Enter the PC server address on the main screen and tap CONNECT.

Example:
192.168.1.10:5000

The Android app reads real telemetry from the PC backend. When the hardware is
not connected, the app shows BOARD NOT CONNECTED and -- instead of invented
sensor values.

Both Android phone and PC must be on the same WiFi network.
