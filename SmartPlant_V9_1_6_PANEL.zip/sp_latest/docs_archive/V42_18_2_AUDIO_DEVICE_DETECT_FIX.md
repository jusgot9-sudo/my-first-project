V42.18.2 AUDIO + VOICE FIX

PC
- Automatic audio scan waits for the pywebview native bridge instead of racing DOMContentLoaded.
- Audio-device changes trigger a re-scan.
- Browser enumerateDevices() is used as a fallback when the native audio bridge cannot query devices.
- PyInstaller spec explicitly collects sounddevice and _sounddevice.

Android
- One complete AndroidBridge now exposes board discovery, SpeechRecognizer, TTS and audio-device detection.
- The APK reports microphone and speaker devices in AI & Voice settings.
- Audio devices are rechecked when the app becomes visible again.
- Continuous voice waits for TTS to finish before starting the next recognition turn.
