V37 AI CONTROL FLOW

Text/voice command -> Groq JSON {reply, action} -> local validation -> ESP32 /api/control -> real result -> spoken/UI confirmation.

Allowed actions: pump_on, pump_off, auto_on, auto_off.
No action is sent for questions/recommendations.
Water-level safety and max-runtime protections remain active.
No fake sensor values are generated.
