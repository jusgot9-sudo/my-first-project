SMART PLANT V42.18.4 FINAL

TEXT CHAT
- AI reply is rendered immediately in the chat window. TTS cannot block or hide a text reply.
- Duplicate Send requests are blocked until the current request finishes.
- App JavaScript version query updated to 42.18.4 to prevent stale UI code.

PC AUDIO
- Native TTS order: Groq Orpheus WAV, Google TTS MP3, Windows SAPI fallback.
- Native audio diagnostics still use the real selected/default microphone and speaker.

ANDROID AUDIO
- Native SpeechRecognizer remains the voice input path.
- Native TextToSpeech uses STREAM_MUSIC and full per-utterance volume.

AI NETWORK
- Android routes AI chat to the discovered Smart Plant PC hub.
- PC remains the Groq API credential holder.
