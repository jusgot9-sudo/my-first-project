# Native Windows Desktop App

The PC EXE now runs the Flask backend in the background and shows the dashboard inside a native pywebview application window. It does not open Chrome or Edge.

Build from `PC_App` with `build_exe.bat`.

Output:
`PC_App\dist\SmartPlantIrrigationSystem.exe`

The Flask server still binds to `0.0.0.0:5000`, so the Android app and ESP32 can connect over the same LAN. The desktop window uses `http://127.0.0.1:5000` internally.

Windows renderer: pywebview can use Microsoft Edge WebView2. If the EXE opens but the content area is blank, install/update the WebView2 Runtime.
