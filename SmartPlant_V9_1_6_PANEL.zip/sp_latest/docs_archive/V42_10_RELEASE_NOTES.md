# Smart Plant V42.10 — Groq Chat Completions release

## AI transport
- Groq is the only runtime AI provider.
- Text AI uses `POST https://api.groq.com/openai/v1/chat/completions`.
- Model is pinned to `openai/gpt-oss-20b`.
- The request uses Groq's `response_format.type=json_schema` strict mode for the Smart Plant action envelope.
- A compatibility retry uses `json_object` mode only when a provider/SDK rejects structured output configuration.
- The verification endpoint uses the same Chat Completions API, not the Responses API.
- Provider: Groq only. No OpenAI API key, OpenAI endpoint, or OpenAI SDK is used.

## Voice
- PC native microphone capture remains enabled through sounddevice.
- Speech-to-text remains Groq Whisper `whisper-large-v3-turbo`.
- English TTS remains Groq Orpheus `canopylabs/orpheus-v1-english` with `troy` voice.
- Sinhala/Japanese continue through Google TTS fallback.
- Windows playback remains native, so browser autoplay is not required.

## Settings
- Groq key can be entered from Settings -> AI and Voice on PC and Android.
- PC stores the key in Windows-user-protected storage.
- Android forwards the key to the connected PC hub and clears the field after save.
- The key is never written into frontend localStorage or APK assets.

## Android
- Existing microphone runtime-permission flow preserved.
- Previous `TextToSpeech.getEngines()` static-call error is absent from the source.
- Kotlin stdlib dependency remains pinned to one version to avoid the previous duplicate-class failure.

## Preserved project items
- Mr. Sudesh photo is present in both PC and Android UI assets.
- PC credit: Developed by Tharusha.
- Android credit: Developed by Geenuka.
