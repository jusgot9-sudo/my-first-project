# Smart Plant V42.4

- Android opens directly on the dashboard; the old connect gate/scan splash is removed from startup.
- Android performs native Smart Plant PC hub discovery silently in the background.
- Microphone permission is requested after the Android activity/WebView is visible, then voice recognition reports real readiness/errors.
- Android Voice AI uses the PC hub TTS endpoint first (Groq Orpheus English / Google TTS fallback) and native Android TTS only as an emergency playback fallback.
- Android AI settings panel is hidden from the phone UI; the PC hub remains the API-key control point.
- Android Gradle dependency resolution pins Kotlin stdlib components to 1.8.22 to resolve the duplicate-class error between 1.8.22 and 1.6.21.
