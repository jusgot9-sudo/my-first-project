V42.14 HTTP 400 / JSON object fix

Root-cause mitigation:
- PC AI chat no longer sends response_format=json_object or json_schema.
- AI chat now uses normal Groq Chat Completions text output with reasoning_format=hidden and parses the required JSON envelope locally.
- AI verification also uses normal text Chat Completions instead of JSON Object Mode.
- The chat path no longer depends on the Groq Python SDK being importable because it uses direct HTTPS.
- PC launcher run_pc.bat had a malformed nested quote in its dependency check; this is fixed.
- TEST_GROQ_API.bat now matches the same normal Chat Completions request shape and never prints the API key.

The Groq model remains openai/gpt-oss-20b, served through api.groq.com.
