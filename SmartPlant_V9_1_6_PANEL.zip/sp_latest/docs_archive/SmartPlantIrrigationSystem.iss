#define MyAppName "Smart Plant Irrigation System"
#ifndef MyAppVersion
  #define MyAppVersion "9.0.0"
#endif
#define MyAppPublisher "Tharusha"
#define MyAppExeName "SmartPlantIrrigationSystem.exe"

[Setup]
AppId={{7F9B5D9C-6E63-4CB6-9E10-7A4C4A5A2D20}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Smart Plant Irrigation System
DefaultGroupName={#MyAppName}
OutputDir=..\Setup_Output
OutputBaseFilename=SmartPlantIrrigationSystem_Setup
SetupIconFile=..\setup_assets\app_icon.ico
UninstallDisplayIcon={app}\app_icon.ico
WizardStyle=modern
WizardImageFile=..\setup_assets\wizard_large.bmp
WizardSmallImageFile=..\setup_assets\wizard_small.bmp
LicenseFile=..\setup_assets\AGREEMENT.txt
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
CloseApplications=yes
RestartApplications=no
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a Desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "firewall"; Description: "Allow phone / ESP32 access on the home network (firewall rule)"; GroupDescription: "Network:"

[Files]
Source: "..\PC_App\dist\SmartPlantIrrigationSystem.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\setup_assets\app_icon.ico"; DestDir: "{app}"; Flags: ignoreversion
; Android app (built by the same pipeline) - copied next to the PC app so it can be sent to a phone.
Source: "..\Android_App\app\build\outputs\apk\debug\app-debug.apk"; DestDir: "{app}"; DestName: "SmartPlantAndroid.apk"; Flags: ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\app_icon.ico"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\app_icon.ico"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant TCP 5000"""; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant UDP 4210"""; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant UDP 4211"""; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""Smart Plant TCP 5000"" dir=in action=allow protocol=TCP localport=5000 profile=domain,private"; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""Smart Plant UDP 4210"" dir=in action=allow protocol=UDP localport=4210 profile=domain,private"; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""Smart Plant UDP 4211"" dir=in action=allow protocol=UDP localport=4211 profile=domain,private"; Flags: runhidden waituntilterminated; Tasks: firewall
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Smart Plant Irrigation System"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant TCP 5000"""; Flags: runhidden
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant UDP 4210"""; Flags: runhidden
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""Smart Plant UDP 4211"""; Flags: runhidden
