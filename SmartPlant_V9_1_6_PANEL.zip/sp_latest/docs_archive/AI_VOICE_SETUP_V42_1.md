# AI Voice Setup V42.1

## Engine
- Groq OpenAI-compatible Responses API
- Model: `openai/gpt-oss-20b`
- PC server owns the Groq API key
- Android uses the PC Smart Plant hub and does not require the Groq key

## Voice
- Speech input: browser/Android native speech recognition
- Speech output on PC: Google TTS via `gTTS`
- English is the default; Sinhala and Japanese remain available

## First run
1. Start the PC app.
2. Open Settings → AI & Voice.
3. Paste your current/replacement Groq key and press Save AI settings.
4. The status now performs a real `responses.create()` verification instead of only checking the models list.
5. Press Voice and speak a Smart Plant question or control command.

## Security
Never place a live Groq API key inside the ZIP, source code, APK, or installer files. A key that has been posted publicly should be revoked/rotated in the Groq console before continued use.

## LAN
- PC dashboard/API: TCP 5000
- Controller discovery: UDP 4210
- Phone-to-PC discovery: UDP 4211
- Run `PC_App\\ALLOW_NETWORK_ACCESS.bat` once as administrator, or let the elevated installer create these Private/Domain firewall rules.
