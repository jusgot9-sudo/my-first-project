BUILD WINDOWS EXE

Run build_exe.bat on Windows.
Output:
dist\SmartPlantSystem.exe

The project uses Flask locally and automatically opens the dashboard in a
browser when launcher.py is used.

No login is required in V4.
