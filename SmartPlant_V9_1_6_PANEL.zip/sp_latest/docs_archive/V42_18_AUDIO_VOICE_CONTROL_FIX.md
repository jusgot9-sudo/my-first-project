# Smart Plant Irrigation System V42.18

- Android Voice button now uses the native Android SpeechRecognizer instead of relying on WebView MediaRecorder.
- Android voice permission approval resumes the pending voice request automatically.
- Android TTS uses the device speech engine and STREAM_MUSIC; unsupported Sinhala voice packs fall back to an installed English/default voice so replies do not become silently muted.
- AI control keeps the real PC -> ESP32 `/api/control` -> UNO D7 relay path.
- Added a conservative explicit-command fallback for clear pump/automatic-irrigation voice commands when the model returns prose instead of an action envelope.
- No API key is embedded in the Android package.

