# Smart Plant V42.8 - Groq key setup

The app no longer accepts or stores a Groq API key in the UI. Configure the key once on the Windows PC with `PC_App\\SET_GROQ_API_KEY.bat`.

The PC backend reads `GROQ_API_KEY` from the Windows user environment. Android contains no Groq key and uses the PC Smart Plant hub for AI, transcription and control.

This follows Groq's documented environment-variable approach for API key management. See the Groq Quickstart and security guidance.
