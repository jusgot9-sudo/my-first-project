SMART PLANT - FULL LAN SCAN FIX

මේ version එකේ ප්‍රධාන වෙනස්කම්:

1. PC scan screen එක 0 / 0 වගේ freeze වීම අඩු කරලා real scan count එක මුලින්ම පෙන්වයි.
2. PC එකේ active/private LAN /24 subnet scan කරන full host sweep එක භාවිතා කරයි.
3. කලින් save කරපු ESP32 IP එක, smartplant.local සහ known ESP32 addresses මුලින් probe කරන නිසා board එක තිබ්බොත් ඉක්මනින් හොයාගනී.
4. ESP32 හඳුනාගන්නේ Smart Plant project/board/firmware identity එකෙන්. PC Flask server එක ESP32 කියලා වැරදි ලෙස detect නොවේ.
5. Scan progress එක real checked/total count එකෙන් update වේ.
6. Scan status API එක temporary fail වුණොත් screen එක forever freeze නොවී error එක පෙන්වයි.
7. Radar animation එක scan එක ඇත්තටම running කියලා පෙන්වීමට indeterminate sweep එකක් තියෙනවා.
8. Android scan bridge එක අයින් කරලා නැහැ. Android credit = Developed by Geenuka.
9. PC scan credit = Developed by Tharusha.

RUN TEST
-----------
PC_App\run_pc.bat

BUILD EXE
-----------
PC_App\BUILD_FULL_SCAN_FIX.bat

Build එකෙන් පස්සේ:
PC_App\dist\SmartPlantIrrigationSystem.exe

සටහන:
මේ ZIP එකේ source code fix එක ඇතුළත්. Windows EXE එක update කරගන්න BUILD_FULL_SCAN_FIX.bat එක Windows PC එකේ run කරන්න.
