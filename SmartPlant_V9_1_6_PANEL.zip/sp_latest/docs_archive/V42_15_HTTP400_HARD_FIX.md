V42.15 HTTP 400 hard fix

Runtime AI chat changes:
- Groq Chat Completions remains the only AI chat endpoint.
- Model remains openai/gpt-oss-20b.
- AI chat requests are hard-locked to ordinary text output.
- No response_format field is sent for AI chat.
- No reasoning_format field is sent for AI chat.
- include_reasoning=false is sent so the client receives only the final answer text.
- The application locally parses the small {reply, action} envelope.
- AI verification uses the same text-only request shape.
- Browser/WebView JavaScript files are cache-busted with v42.15 query strings.
- PC launcher dependency-check quoting remains fixed.

The user's Groq key is never embedded in this package.
