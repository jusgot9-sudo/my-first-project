SMART PLANT - GROQ API KEY SETUP
================================

ONE place to configure the Groq key:

    SET_GROQ_API_KEY.bat

That runs the PC setup script:

    PC_App\SET_GROQ_API_KEY.bat

The script asks for the key from:
    https://console.groq.com/keys

The key is stored as the Windows USER environment variable:
    GROQ_API_KEY

The Smart Plant PC server reads this environment variable at runtime.
It does NOT save the secret in SQLite, HTML, JavaScript, Android assets, or
localStorage.

ANDROID
-------
The Android app intentionally has no Groq API key field and no stored Groq
key. It connects to the Smart Plant PC hub on the local network. The PC hub
handles Groq AI/voice services.

CHANGE / REMOVE KEY
-------------------
SET_GROQ_API_KEY.bat       = set or replace the key
REMOVE_GROQ_API_KEY.bat    = remove the Windows user key

After changing the key, close and reopen Smart Plant.
