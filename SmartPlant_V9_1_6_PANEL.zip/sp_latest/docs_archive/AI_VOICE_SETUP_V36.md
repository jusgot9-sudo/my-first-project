# Smart Plant V36 — AI + Voice + Plant Control

1. Settings -> AI & Voice.
2. Turn on AI Assistant.
3. Turn on AI plant control for explicit pump/automatic-irrigation commands.
4. Enter/replace the Groq API key.
5. Save AI settings.
6. Press Test AI.
7. Use text chat or Voice chat.
8. Auto Speak controls spoken AI replies.

Allowed plant actions:
- pump_on (1–600 seconds)
- pump_off
- auto_on
- auto_off

The ESP32 remains authoritative: pump start is blocked when water level is unavailable or at/below the safety minimum, and the maximum pump runtime is enforced.
