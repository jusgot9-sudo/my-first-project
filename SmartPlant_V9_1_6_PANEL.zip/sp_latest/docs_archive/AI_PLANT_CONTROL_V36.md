# Smart Plant V36 — AI Plant Control

Phone -> Same Wi-Fi -> ESP32
PC -> Same Wi-Fi -> ESP32

The AI Assistant reads the live controller snapshot and rule-based alerts. It can report problems and execute explicit plant-control requests:
- pump_on for 1-600 seconds;
- pump_off;
- auto_on;
- auto_off.

The controller remains authoritative. Pump start is blocked when the water-level sensor is unavailable or at/below the safety minimum, and the controller enforces its maximum runtime.

The AI must never invent sensor values or claim an action succeeded without a real controller response.

Settings -> AI & Voice contains:
- AI Assistant enabled;
- AI plant control enabled/disabled;
- Auto Speak;
- Groq API key rotation;
- model selection;
- optional OpenWeather settings.

The API key is not included in firmware or source files.
