# Smart Plant V36 — Final Two-Pass Audit

## Scope
PC app, Android app, shared UI, API contracts, AI/voice bridge, ESP32 firmware, Arduino UNO relay firmware, build scripts, installer configuration, firmware organization, and secret scanning.

## Pass 1 — Static / syntax
- PC Python syntax: PASS (`python -m py_compile PC_App/app.py`)
- PC shared JavaScript syntax: PASS (`node --check`)
- Android shared JavaScript syntax: PASS (`node --check`)
- Android XML parse: PASS
- Android Java lexical BOM/braces sanity: PASS (full Gradle compile requires the Windows/Android build environment)
- AI envelope/action parser behavioral checks: PASS
- Secret scan for the API key previously pasted in chat: PASS — not present in the release source
- Firmware canonical files exist: PASS

## Pass 2 — Cross-file / integration contracts
- Phone -> same Wi-Fi -> ESP32: PASS
- PC -> same Wi-Fi -> ESP32: PASS
- ESP32 UDP discovery + TCP HTTP fallback: PASS by source contract
- AI status/settings/chat routes align with UI: PASS
- PC AI explicit action execution aligns with `/api/control`: PASS
- Android AI explicit action execution aligns with `/api/control`: PASS
- AI error/diagnostic context uses live controller telemetry: PASS
- Missing sensor readings remain null/unavailable rather than fabricated: PASS by source contract
- Pump safety blocks start on missing/low water: PASS by source contract
- UNO relay mapping = D7: PASS
- ESP32/UNO UART mapping = GPIO17/16 <-> D10/D11: PASS
- Firmware organization: canonical files under `Firmware/ESP32/` and `Firmware/ArduinoUNO/`; older copies archived under `Firmware/Legacy/`: PASS
- API-key rotation through Settings without rebuilding: PASS by app/backend design
- UTF-8/BOM/malformed source scan: PASS
- Release package contains no `__pycache__` or `.pyc`: PASS

## AI control behavior
The AI can return and execute only explicit current-user requests for `pump_on`, `pump_off`, `auto_on`, or `auto_off`. It must not invent telemetry or claim execution before the app/controller returns the real result. Existing hardware/controller safety limits remain authoritative.

## Limitations
This environment has no physical ESP32/UNO board, so sensor/relay electrical behavior cannot be physically verified here. The Windows-only Inno Setup compiler and the full Android Gradle distribution are not available in this Linux sandbox, so the final EXE/Setup/APK binaries must be built on the target Windows machine using `BUILD_FINAL_WINDOWS_V36.cmd`.
