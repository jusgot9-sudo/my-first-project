# Smart Plant Irrigation System V42.17

## AI / Groq
- User enters only the Groq API key; `openai/gpt-oss-20b` remains internally pinned.
- Chat requests use Groq's Chat Completions endpoint only.
- No `response_format=json_object`, no `json_schema`, and no `reasoning_format` are sent.
- The first request sets `include_reasoning=false`; a compatibility retry removes optional generation parameters entirely.
- The model response is treated as ordinary text and parsed locally for the small plant-control envelope, preventing a structured-output HTTP 400 from being introduced by the app.
- Saved Groq key is kept outside the project in the Windows user's protected Smart Plant data folder.

## PC microphone / speaker
- Real PortAudio device discovery lists all detected microphones and speakers.
- User can select a microphone and speaker inside Settings; selections persist.
- Voice capture uses the selected microphone.
- English Groq WAV TTS is played through the selected speaker first.
- Audio test plays a tone through the selected speaker and performs a real 2-second microphone capture with RMS/peak diagnostics.
- Windows Microphone Privacy and Sound Settings buttons are included for access problems.
- The old presence-only microphone test was removed.

## Android
- `RECORD_AUDIO` permission flow now guards repeated permission requests.

## Validation
- No Groq key is embedded in the package.
- Python/JavaScript syntax and archive integrity should be checked before distribution.
- Physical Windows microphone/speaker hardware remains a target-PC test because the build environment cannot access that hardware.
