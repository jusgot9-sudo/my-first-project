# V42.9 — Groq key in Settings (PC + Android)

The Groq API key can now be entered from **Settings -> AI and Voice** on both PC and Android.

## PC
- `PC_App/templates/dashboard.html` contains the key input and Save/Clear/Test controls.
- `PC_App/static/js/app.js` sends the key to `/api/ai/settings` and never puts it into localStorage.
- `PC_App/app.py` persists the key in a Windows-user protected local secret using DPAPI; the key is also applied to the current process immediately.
- SQLite config never receives the key.

## Android
- `Android_App/app/src/main/assets/ui/index.html` contains the same Settings UI.
- `Android_App/app/src/main/assets/ui/js/app.js` sends the key to the connected PC hub.
- The Android app clears the field after save and does not persist the key in SharedPreferences or APK assets.

## Model
- Pinned Smart Plant model: `openai/gpt-oss-20b`.

## Verification
- Python syntax check
- PC JS syntax check
- Android JS syntax check
- HTML duplicate-id check
- Required-field / route reference check
- Secret scan
- ZIP integrity check
