# Smart Plant Irrigation System V42.1 — Voice First

## AI engine
- Groq OpenAI-compatible Chat Completions API
- Model: `openai/gpt-oss-20b`
- PC-only API key storage
- Android connects to the PC Smart Plant hub for AI requests

## Voice
- PC voice reply: Google TTS via `gTTS`
- English is the default language; Sinhala and Japanese remain available
- Android microphone permission is requested by the operating system on first use; network permissions are normal install-time permissions

## LAN / firewall
- TCP 5000: PC dashboard/API
- UDP 4210: controller discovery
- UDP 4211: PC discovery for Android
- `PC_App\ALLOW_NETWORK_ACCESS.bat` self-elevates once and adds Domain + Private firewall rules

## Security
- Do not place a live Groq key in source code, APK, or ZIP.
- Use PC Settings → AI & Voice or the `GROQ_API_KEY` environment variable on the PC host.
