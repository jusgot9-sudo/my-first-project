# Smart Plant Irrigation System V42 — Voice-First Release

## User experience
- Voice input only; no AI text-entry box and no Send button.
- English is the default voice language; Sinhala is selectable.
- PC voice output uses Google TTS through the `gTTS` Python package.
- Android voice requests connect to the Smart Plant PC hub over the same Wi-Fi; the phone does not call Groq directly.
- AI is restricted to Smart Plant / irrigation / sensors / automation / device / developer topics.

## Platform credits
- PC: Developed by Tharusha.
- Android: Developed by Geenuka.
- The AI answers the developer-name question according to the platform it is running on.

## Real hardware actions
- AI may request only: `pump_on`, `pump_off`, `auto_on`, `auto_off`.
- Pump relay is the Arduino UNO relay on D7 via ESP32 UART.
- No unsupported light/fan controls are advertised by this release.

## Validation
- Python syntax check passed.
- PC JavaScript syntax check passed.
- Android bundled JavaScript syntax check passed.
- Android Gradle build was not completed in the sandbox because the Gradle distribution could not be downloaded due network restrictions.
- Live Google TTS network generation was not exercised in the sandbox because outbound package/network access is restricted.

## Voice engine reference
- GitHub project: https://github.com/rany2/gTTS
- Package used by the PC build: `gTTS==7.2.8`.
