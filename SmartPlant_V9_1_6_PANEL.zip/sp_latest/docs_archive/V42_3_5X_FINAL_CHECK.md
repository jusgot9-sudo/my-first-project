# Smart Plant V42.3 — 5X final static audit

1. **Project/assets**
   - Teacher photo exists in both PC and Android bundles.
   - PC and Android teacher photo hashes are identical.
   - No real Groq API key is embedded in the project archive.

2. **Python**
   - `PC_App/app.py` compiles successfully with `py_compile`.
   - Groq SDK import is optional at startup; the application reports a useful error if the dependency is missing.

3. **JavaScript**
   - PC `app.js` passes `node --check`.
   - Android `app.js` passes `node --check`.
   - No UTF-8 BOM is present in either JavaScript file.

4. **Android permissions / LAN**
   - `INTERNET`, network state, Wi-Fi and multicast permissions are declared.
   - `RECORD_AUDIO` is declared and requested at runtime.
   - WebView audio + camera permission requests are forwarded only after Android grants the matching runtime permission.
   - Permanently denied microphone access gets a visible App Settings recovery path.

5. **AI/TTS/API**
   - AI model remains `openai/gpt-oss-20b` with Groq OpenAI-compatible Responses API.
   - English TTS uses `canopylabs/orpheus-v1-english` / `troy` through `/api/groq.../audio/speech` internally via the Groq SDK.
   - Long English TTS is split to the documented 200-character chunks and merged as WAV.
   - Sinhala/Japanese use Google TTS; English automatically falls back to Google TTS if Groq TTS fails.
   - `/api/ai/tts` returns `audio/wav` for Groq Orpheus and `audio/mpeg` for Edge fallback.

6. **Firewall**
   - TCP 5000, UDP 4210, UDP 4211 are the only inbound Smart Plant rules.
   - Rules are limited to Domain + Private profiles; Public remains closed.

7. **Archive**
   - ZIP integrity test passes after packaging.
