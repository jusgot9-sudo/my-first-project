# SmartPlant V42 — Five-Pass Audit Report

## Scope
Audited the full V41 project used as the source for V42, with targeted fixes for the reported AI/Voice settings failure and Android/PC voice behavior.

## Pass 1 — Project structure
PASS
- PC app, Android app, installer, firmware and documentation paths exist.
- Active Android UI assets and PC dashboard files are present.
- No user API key was inserted into source.

## Pass 2 — Python / JavaScript syntax
PASS
- `PC_App/app.py` and `PC_App/launcher.py` compile with Python 3.
- PC `app.js` passes Node `--check`.
- Android `app.js` passes Node `--check`.
- MainActivity source was structurally checked for balanced delimiters and required methods/imports.

## Pass 3 — Android UI / touch / voice contract
PASS
- WebView zoom remains disabled.
- Horizontal document overflow remains blocked on mobile CSS.
- `RECORD_AUDIO` permission remains present.
- Android bridge exposes `startVoice`, `stopVoice`, `speakText`, `hasAiKey`, `validateGroqKey`, `aiChat`.
- Sinhala recognition uses `si-LK`.
- Android TTS prefers an installed Google TTS engine and a Sinhala voice when available.
- The app reports missing Sinhala voice data instead of silently switching to English.

## Pass 4 — AI/API behavior
PASS
- AI model is pinned to `openai/gpt-oss-120b`.
- Groq remains the only AI API used by the application.
- API key is runtime-configured, not shipped in source.
- If a valid key exists but the AI toggle was previously left OFF, the chat/test path automatically re-enables AI so the reported “Enable AI in Settings first” failure does not block a configured key.
- API auto-detect also checks the Android-native stored key, not only browser localStorage.
- AI control remains limited to validated plant-control actions.

## Pass 5 — Secret/encoding/package integrity
PASS
- Exact user-supplied Groq key is absent from the release package.
- No `gsk_...` secret pattern is present in active source.
- UTF-8 source files read successfully.
- ZIP was recreated after all patches.

## Voice architecture note
Gemini TTS/Live audio is itself a Gemini API capability. Therefore, this V42 build does **not** claim to use a Gemini voice while also claiming “no second API”. To preserve the requested one-API design, AI text/control uses Groq and voice output uses the device/browser speech engine, preferring Google TTS and Sinhala (`si-LK`) on Android.

## Validation limitation
This audit is source/static plus local toolchain based. No physical Android handset, ESP32 board, or Arduino UNO board is attached to this environment, so physical microphone, speaker, Wi-Fi, sensor, relay and hardware-control behavior cannot be claimed as field-tested here.
