V38 UPDATE: Direct Groq AI, full mobile app surface, persistent AI chat memory, and current Groq model defaults.

# Smart Plant Irrigation System — V36 Final

## Network architecture

Phone -> Same Wi-Fi -> ESP32
PC    -> Same Wi-Fi -> ESP32

The ESP32 is the network controller. The PC Flask app is optional desktop functionality; it is not required as a relay between the phone and ESP32.

## Hardware

- ESP32 DevKit V1 / 38-pin
- DHT11 — temperature + humidity — GPIO4
- Capacitive soil moisture — GPIO34
- Water-level sensor — GPIO35
- MQ-2 — GPIO32
- DS18B20 — GPIO33
- Arduino UNO relay bridge — D7
- ESP32 UART2: GPIO17 TX / GPIO16 RX
- UNO serial: D10 RX / D11 TX (shift UNO TX from 5 V to 3.3 V before ESP32 RX)

## AI + voice

The AI Assistant reads live controller data and a rule-based diagnostic report. It can:

- report current plant/controller problems;
- start the pump for an explicitly requested duration (1–600 seconds);
- stop the pump;
- enable automatic irrigation;
- disable automatic irrigation.

The AI cannot invent telemetry or claim success. The controller/app returns the actual result after the command is attempted.

### Settings

Open `Settings -> AI & Voice` in PC or Android:

1. Enable AI Assistant.
2. Enable AI plant control when you want explicit plant-control commands from chat or voice.
3. Enter or replace the Groq API key.
4. Save and test.
5. Enable Auto Speak for spoken replies.

A key can be rotated later from Settings without rebuilding the project. No real key is included in this package.

## Example AI commands

- Start the pump for 20 seconds.
- Stop the pump.
- Turn automatic irrigation on.
- Turn automatic irrigation off.
- Give me a live plant health report.
- Tell me what is wrong with the system.

## Build order

1. Flash the Arduino UNO firmware from `Firmware/ArduinoUNO/`.
2. Flash the ESP32 firmware from `Firmware/ESP32/`.
3. Build the Windows desktop application with `BUILD_FINAL_WINDOWS_V36.cmd`.
4. Build the Android debug APK with `Android_App/build_apk.bat` or the all-in-one Windows build.
5. Build the Inno Setup package after the PC EXE and APK exist.

## Security note

Do not commit or publish Groq/OpenWeather API keys, private keystores, passwords, or Wi-Fi passwords in source code. The app provides runtime Settings for API-key rotation.
