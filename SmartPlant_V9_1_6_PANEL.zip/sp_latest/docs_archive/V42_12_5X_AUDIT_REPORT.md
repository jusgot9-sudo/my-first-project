# Smart Plant V42.12 — 5-pass audit

## Pass 1 — Provider/network
- Active AI provider: Groq only.
- Chat endpoint: `https://api.groq.com/openai/v1/chat/completions`.
- No `api.openai.com` endpoint in active PC/Android application code.
- No OpenAI Python SDK import in active application code.

## Pass 2 — Settings
- PC Settings → AI and Voice exposes a Groq API key field.
- Android Settings → AI and Voice exposes the same Groq API key field.
- Provider is displayed as `Groq`.
- The model is displayed as `GPT-OSS 20B (Groq)`; the internal Groq model identifier remains `openai/gpt-oss-20b` because that is the identifier accepted by Groq for the hosted GPT-OSS model.

## Pass 3 — JSON/AI flow
- Backend parses both Chat Completions `choices[].message.content` and JSON control envelopes.
- Invalid/non-JSON model output is converted to a plain-text reply with no hardware action.
- Allowed actions are validated before execution.

## Pass 4 — PC/Android UI assets
- Teacher photo exists in both PC and Android UI assets.
- PC and Android teacher photo SHA-256: `3d99ecf84aa5cbb0629695f05827be0933b43f8b17c4ca2065346942e8e1f184`.
- Android microphone permission code remains present.

## Pass 5 — release integrity
- Python syntax check: PASS.
- PC UI JavaScript syntax check: PASS.
- Android UI JavaScript syntax check: PASS.
- ZIP integrity test: PASS.
- No raw `gsk_...` credential is embedded in the release archive.
