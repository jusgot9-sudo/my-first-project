# Smart Plant V42.6 — Native PC Voice Fix

The Windows desktop EXE no longer relies on WebView `getUserMedia()` for the PC voice path. It records the microphone natively through `sounddevice`/PortAudio. This avoids the WebView microphone permission path that was causing the Voice orb to animate without receiving audio.

## Windows permissions

Windows still controls whether desktop applications may use the microphone. This cannot be safely bypassed by a normal application. Run `ENABLE_PC_VOICE_AND_NETWORK.bat` once. It opens the Windows microphone and sound pages and installs the Smart Plant Private/Domain firewall rules. Turn on:

- Microphone access
- Let desktop apps access your microphone

Also select the correct Windows default input/output device.

## Runtime behavior

1. PC EXE starts the local Flask server.
2. The firewall bootstrap runs; it self-elevates only if the Smart Plant rules are missing.
3. Clicking the Voice orb calls `native_voice_chat`.
4. Native microphone audio is recorded for 8 seconds and converted to WAV in memory.
5. Groq Whisper transcribes it.
6. Groq GPT-OSS 20B decides the plant-only response and allowed control action.
7. English uses Groq Orpheus TTS first; Sinhala/Japanese use Google TTS.
8. Windows plays the generated audio natively, so browser autoplay/audio permission is not needed for PC TTS.

If Windows denies microphone access, the app opens `Settings > Privacy & security > Microphone` automatically and shows the actual PortAudio/microphone error.
