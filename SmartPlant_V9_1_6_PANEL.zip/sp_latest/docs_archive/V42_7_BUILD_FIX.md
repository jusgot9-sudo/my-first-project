# Smart Plant V42.7 — Android build fix

- Fixed `TextToSpeech.getEngines()` static-call compilation error in `MainActivity.java`.
- Android now uses the device/default TTS engine after constructing a `TextToSpeech` instance.
- Suppressed the non-fatal JDK 21 / Java 8 source-target deprecation warning.
- No Groq API key is embedded in the Android project.
