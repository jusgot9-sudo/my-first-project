# Smart Plant V42.12 — Groq-only provider

- AI provider: Groq only.
- Groq API key is configured from Settings → AI and Voice on PC and Android.
- Primary chat endpoint: https://api.groq.com/openai/v1/chat/completions
- Internal model ID: openai/gpt-oss-20b (this is the model identifier required by Groq for its hosted GPT-OSS model; it is not an OpenAI API endpoint or key).
- No `api.openai.com` calls.
- No `OPENAI_API_KEY`.
- No OpenAI Python SDK.
- Android does not ship a Groq key.
