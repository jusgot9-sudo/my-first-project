# SmartPlant V9.1.1 security audit

## Fixes applied

The PC Flask server now rejects API requests carrying an untrusted browser `Origin`, allows the bundled Android `https://appassets.androidplatform.net` origin explicitly instead of using wildcard CORS, and adds `nosniff`, frame, referrer, permissions, and no-cache headers. This reduces cross-site request forgery and cross-origin data exposure while preserving the PC WebView and Android app flows.

Board tokens are now accepted only through the `X-Board-Token` header. Query-string tokens were removed because URLs can be copied into browser history, proxy logs, screenshots, and analytics logs.

The Android WebView no longer permits legacy `file://` or universal file-origin access. External URL launching from the JavaScript bridge is restricted to GitHub release/download hosts, which is the only external destination used by the updater.

## Existing protections confirmed

- API keys are kept outside the general SQLite configuration blob and Windows uses DPAPI when available.
- Android permission requests are limited to the appassets origin.
- Flask debug mode is disabled in the launcher/server.
- Request bodies have a global size limit and voice upload handlers validate size/type paths.
- Update downloads are restricted to the configured GitHub repository by the existing updater code.
- Pump controls retain telemetry, water-level, maximum-runtime, and safety cut-off checks.

## Important deployment setting

The PC server intentionally binds to `0.0.0.0` so the phone can reach it over the home LAN, and the controller/PC protocol intentionally supports local HTTP. Use a private Wi-Fi network, keep the Windows firewall profile limited to Private/Domain, and do not port-forward the SmartPlant port to the public internet. For stronger protection, configure a unique board token in Settings and configure the same token in the firmware/controller.

## Validation

After these changes, run the included `BUILD_SETUP_5X_CHECK_AND_FIX.bat` on Windows. It runs five source/configuration checks before building the installer. The supplied ZIP should also be integrity-tested after transfer.
