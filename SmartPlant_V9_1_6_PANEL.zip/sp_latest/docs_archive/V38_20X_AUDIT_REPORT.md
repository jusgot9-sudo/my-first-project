# Smart Plant V38 — 20X Audit Report

Scope: PC + Android UI + direct Groq AI + ESP32/UNO firmware + build/configuration.

1. PC Python syntax — PASS
2. PC JavaScript syntax — PASS
3. Android JavaScript syntax — PASS
4. Android Manifest XML — PASS
5. Android/PC HTML parse — PASS
6. Android applicationId — PASS (`com.smartplant.app`)
7. Android build scripts package id — PASS
8. Deprecated Groq model IDs removed from active source — PASS
9. Exposed Groq-secret pattern scan — PASS (no embedded live key)
10. Current Groq model default — PASS (`openai/gpt-oss-120b`)
11. Groq chat endpoint — PASS
12. Android viewport disables user scaling — PASS
13. WebView pinch/zoom disabled — PASS
14. Android horizontal page overflow blocked — PASS
15. Android 5x2 app navigation — PASS
16. AI local chat memory (last 20 messages) — PASS
17. Original Android page IDs preserved (except intentionally removed optional weather fields) — PASS
18. Original Android navigation destinations preserved — PASS
19. ESP32 CORS/API/safety contract — PASS
20. UNO D7 relay + installer configuration — PASS

### Environment limitations
Physical ESP32/UNO boards are not attached to this environment, so real sensor/relay behavior cannot be physically exercised here. Android Gradle distribution is not cached; the wrapper attempts to download Gradle in an offline environment and therefore cannot produce a real APK in this sandbox.
