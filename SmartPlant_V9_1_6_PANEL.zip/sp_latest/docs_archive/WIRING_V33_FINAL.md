# Smart Plant V33 Final Wiring

## ESP32 DevKit 38-pin

| Device | ESP32 pin | Notes |
|---|---|---|
| DHT11 DATA | GPIO4 | VCC 3.3V, GND common |
| Capacitive soil analog | GPIO34 | ADC1 input; power sensor appropriately |
| Water level analog | GPIO35 | ADC1 input; ensure output never exceeds 3.3V |
| MQ-2 analog AO | GPIO32 | ADC1 input; use a safe voltage divider/level shifter when the module can output 5V |
| DS18B20 DATA | GPIO33 | 4.7k pull-up from DATA to 3.3V |
| UNO TX -> ESP32 RX | GPIO16 | UNO D11 through 5V->3.3V divider/level shifter |
| ESP32 TX -> UNO RX | GPIO17 | UNO D10 input |
| GND | GND | common ground |

## Arduino UNO

| Device | UNO pin |
|---|---|
| Relay input | D7 | active-low default |
| ESP32 TX2 -> UNO RX | D10 | 3.3V signal into UNO input |
| UNO TX -> ESP32 RX2 | D11 | **level shift to <=3.3V before GPIO16** |
| Common ground | GND | must be shared |

## Pump power

Do not power a pump directly from ESP32/UNO GPIO. Use an appropriately rated relay/driver and a separate pump supply. Keep low-voltage logic grounds arranged correctly for the chosen driver.

## Sensors

All five channels are enabled in firmware: DHT11, capacitive soil moisture, water level, MQ-2 and DS18B20. MQ-2 percent is withheld during the first 60 seconds of warm-up. Invalid readings stay `null`/`--`.
