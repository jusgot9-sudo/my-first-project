# Smart Plant V42.2 — Five-Pass Final Audit

## Pass 1 — Teacher asset
- `PC_App/static/img/teacher_sudesh.png` exists.
- `Android_App/app/src/main/assets/ui/img/teacher_sudesh.png` exists.
- PC and Android copies are byte-identical.
- Both boot UIs contain `#introTeacherPhoto` pointing to the included image.

## Pass 2 — UI / JavaScript
- PC and Android HTML parse without mismatched non-void tags.
- PC and Android JavaScript pass Node syntax checks.
- The teacher-photo fallback emoji remains hidden when the real photo is present.
- Developer credits remain platform-aware: PC = Tharusha, Android = Geenuka.

## Pass 3 — AI / JSON / TTS
- Flask source passes `py_compile`.
- Groq uses the OpenAI-compatible base URL and `openai/gpt-oss-20b` through `client.responses.create(...)`.
- `/api/ai/verify` accepts both GET and POST; this fixes the former frontend POST -> backend GET-only 405 path that surfaced as `BAD_JSON`.
- Frontend transport now parses response text safely and reports the real HTTP/API error instead of collapsing non-JSON error pages into `BAD_JSON`.
- `gTTS==7.2.8` is present for Google TTS.

## Pass 4 — Android permissions / LAN
- Manifest declares INTERNET, ACCESS_NETWORK_STATE, CHANGE_NETWORK_STATE, ACCESS_WIFI_STATE, CAMERA, and RECORD_AUDIO.
- Microphone runtime permission is requested when not already granted; the old persistent suppression flag is no longer used to block future prompts.
- WebView camera permission is bridged to Android's runtime CAMERA permission.
- Wi-Fi binding and cleartext LAN access are configured for the local PC/ESP32 HTTP architecture.
- Windows firewall scripts allow TCP 5000, UDP 4210, and UDP 4211 on Domain + Private profiles.
- The installer is configured with `PrivilegesRequired=admin` so firewall rules can be installed.

## Pass 5 — Release/package/security
- No real `gsk_...` Groq secret is shipped in source or archive; the supplied key was not embedded.
- ZIP CRC verification passes.
- Required teacher photo, audit report, PC UI, Android UI, and AI backend files are present in the final archive.
- Android Gradle wrapper was inspected; an actual APK build cannot be completed in this sandbox because the wrapper needs to download Gradle 8.9 from `services.gradle.org`, which is blocked in this environment.
