# Smart Plant Irrigation System V42.16

- User enters only the Groq API key; the AI model is pinned internally.
- Groq Chat Completions request is minimal and does not send `response_format` or `include_reasoning`.
- PC native microphone capture uses the selected/default Windows input device and the device-native sample rate when necessary.
- PC WAV playback uses `winsound` memory playback; Edge MP3 remains the fallback for Sinhala/Japanese.
- Native `Speak Last` and voice replies try the Windows native path first and then the browser/server TTS fallback.
- Added a non-destructive PC speaker + microphone diagnostic.
- No API key is embedded in the package.

Important: physical microphone/speaker hardware still needs to be tested on the target Windows PC.
