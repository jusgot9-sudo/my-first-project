SMART PLANT V39 — ONE GROQ API + AUTO-DETECT

- One AI provider: Groq.
- One AI model: openai/gpt-oss-120b.
- Settings -> AI & Voice -> paste key once -> Save.
- Startup auto-detects the saved key and verifies that GPT-OSS 120B is available through GET /openai/v1/models.
- Android uses a native validation bridge so verification does not depend on browser CORS.
- PC can verify directly or through its bundled local app endpoint; no remote Smart Plant server is required.
- API key can be replaced later from Settings without rebuilding the APK/EXE.
- AI Assistant and AI plant control remain independently enable/disable-able.
- Voice chat remains available for Android microphone -> speech -> AI -> TTS, with browser speech support on PC where available.
- The exposed key previously pasted into chat is NOT embedded in this release. Rotate/revoke it before use.
