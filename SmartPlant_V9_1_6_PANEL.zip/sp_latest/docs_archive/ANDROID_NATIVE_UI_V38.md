V38 ANDROID UI

Original HTML/CSS/JS/features are preserved. The Android-only CSS/Java layer now enforces:
- full-screen portrait app surface
- user-scalable=no viewport
- WebView zoom disabled
- pinch/multi-touch zoom swallowed
- no horizontal page scrolling
- fixed two-row bottom navigation (10 destinations)
- safe-area padding for modern phones
- wrapped tables and cards instead of sideways overflow
- responsive AI chat and voice controls
- AI conversation history persists locally on the device
