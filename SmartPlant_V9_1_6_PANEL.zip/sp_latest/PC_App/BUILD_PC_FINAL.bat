@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0.."
set "ROOT=%~dp0.."
set "LOG=%ROOT%\PC_App\pc_build_final.log"
set "VENV=%ROOT%\.pc_build_venv"
set "PY=%VENV%\Scripts\python.exe"

if not exist "%ROOT%\VERSION.txt" (
    echo ERROR: VERSION.txt not found. Extract the project completely first.
    pause
    exit /b 1
)

>"%LOG%" echo ============================================================
>>"%LOG%" echo SMART PLANT V9.1.3 - PC EXE + SETUP FINAL BUILD
>>"%LOG%" echo Started: %date% %time%
>>"%LOG%" echo Root: %ROOT%
>>"%LOG%" echo ============================================================

echo.
echo ============================================================
echo SMART PLANT V9.1.3 - PC EXE + SETUP FINAL BUILD
echo ============================================================
echo Full log: %LOG%
echo.

echo [1/5] Finding Python 3.11-3.13...
where python.exe >>"%LOG%" 2>&1
if errorlevel 1 goto fail_python
for /f "delims=" %%V in ('python -c "import sys; print('.'.join(map(str,sys.version_info[:3])))"') do set "PYVER=%%V"
echo Python %PYVER%
>>"%LOG%" echo Python %PYVER%
python -c "import sys; assert (3,11) <= sys.version_info < (3,14), 'Python 3.11-3.13 required'" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_python

if not exist "%PY%" (
    echo [2/5] Creating isolated PC build environment...
    python -m venv "%VENV%" >>"%LOG%" 2>&1
    if errorlevel 1 goto fail_venv
) else (
    echo [2/5] Reusing isolated PC build environment...
)

if not exist "%PY%" goto fail_venv

"%PY%" -m pip install --upgrade pip >>"%LOG%" 2>&1
if errorlevel 1 goto fail_pip
"%PY%" -m pip install -r "%ROOT%\PC_App\requirements.txt" pyinstaller >>"%LOG%" 2>&1
if errorlevel 1 goto fail_pip

echo [3/5] Checking source files and syntax...
"%PY%" -m py_compile "%ROOT%\build.py" "%ROOT%\PC_App\launcher.py" "%ROOT%\PC_App\app.py" "%ROOT%\PC_App\local_voice_engine.py" "%ROOT%\Installer\installer.py" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_syntax

for %%F in (
 "%ROOT%\VERSION.txt"
 "%ROOT%\PC_App\SmartPlantIrrigationSystem.spec"
 "%ROOT%\PC_App\launcher.py"
 "%ROOT%\PC_App\app.py"
 "%ROOT%\PC_App\local_voice_engine.py"
 "%ROOT%\PC_App\app_icon.ico"
 "%ROOT%\Installer\installer.py"
 "%ROOT%\Installer\ui\index.html"
 "%ROOT%\Installer\ui\css\style.css"
 "%ROOT%\Installer\ui\js\main.js"
 "%ROOT%\Installer\ui\img\logo.png"
 "%ROOT%\setup_assets\app_icon.ico"
 "%ROOT%\setup_assets\AGREEMENT.txt"
) do if not exist "%%~F" goto fail_files

echo [4/5] Building PC EXE + Setup.exe... 
>>"%LOG%" echo.
>>"%LOG%" echo [BUILD] python build.py all
"%PY%" -u "%ROOT%\build.py" all >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"

echo.
echo ---------------- FULL BUILD LOG ----------------
type "%LOG%"
echo -------------- END FULL BUILD LOG --------------
if not "%RC%"=="0" goto fail_build

echo [5/5] Verifying final files...
if not exist "%ROOT%\PC_App\dist\SmartPlantIrrigationSystem.exe" goto fail_output
if not exist "%ROOT%\Setup_Output\SmartPlantIrrigationSystem_Setup.exe" goto fail_output
if not exist "%ROOT%\Setup_Output\SHA256SUMS.txt" goto fail_output

echo.
echo ============================================================
echo                     BUILD SUCCESS
echo ============================================================
echo PC EXE:
echo   %ROOT%\PC_App\dist\SmartPlantIrrigationSystem.exe
echo Setup.exe:
echo   %ROOT%\Setup_Output\SmartPlantIrrigationSystem_Setup.exe
echo Release folder:
echo   %ROOT%\Setup_Output
echo Full log:
echo   %LOG%
echo ============================================================
pause
exit /b 0

:fail_python
echo ERROR: Python 3.11-3.13 is required.
goto fail
:fail_venv
echo ERROR: Could not create the isolated Python build environment.
goto fail
:fail_pip
echo ERROR: Python dependencies could not be installed.
goto fail
:fail_syntax
echo ERROR: Python syntax check failed.
goto fail
:fail_files
echo ERROR: A required PC build file is missing.
goto fail
:fail_build
echo ERROR: PC EXE / Setup build failed. The full log is above and saved at:
echo %LOG%
goto fail
:fail_output
echo ERROR: Final EXE, Setup.exe, or SHA256 manifest is missing.
goto fail
:fail
echo.
echo ============================================================
echo                      BUILD FAILED
echo ============================================================
echo Log: %LOG%
echo ============================================================
pause
exit /b 1
