"""
Smart Plant Irrigation & Monitoring System - PC server
Developed by Tharusha

Design notes
------------
* No fake telemetry. Values stay "--" and the link reads OFFLINE until a real
  controller reports in. Pump controls are locked while offline.
* Two link modes:
    push - the board POSTs /api/telemetry and polls GET /api/command
    poll - this server reads the board itself at GET <board>/api/state and
           sends POST <board>/api/control (same contract the phone app uses)
* Settings persist in SQLite, so the .exe remembers everything between runs.
* One background worker owns automation, safety cut-offs, the daily schedule
  and history pruning, so behaviour does not depend on a browser being open.
"""

from flask import Flask, render_template, request, jsonify, make_response
from pathlib import Path
import ipaddress
from datetime import datetime, timedelta
import json
import sqlite3
import csv
import io
import os
import re
import socket
import sys
import tempfile
import threading
import time
import urllib.request
import urllib.error
import urllib.parse
import math
import struct


try:
    from groq import Groq
except Exception:
    Groq = None

try:
    from gtts import gTTS
except Exception:
    gTTS = None

import local_voice_engine as local_voice

try:
    import sounddevice as sounddevice
except Exception:
    sounddevice = None

try:
    import winsound
except Exception:
    winsound = None

try:
    import pygame
except Exception:
    pygame = None

# Never send controller traffic through a corporate/system HTTP proxy.
# The phone + PC + ESP32 architecture is local-Wi-Fi only.
DIRECT_LAN_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))

BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
DATA_DIR = Path(
    os.environ.get(
        "SMARTPLANT_DATA",
        os.path.join(
            os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
            "Smart Plant System"
        )
    )
)

DATA_DIR.mkdir(parents=True, exist_ok=True)# ============================================================
# SMART PLANT USER DATA
# Keep SQLite database outside Program Files.
# ============================================================
DB_PATH = DATA_DIR / "smartplant.db"

PORT = int(os.environ.get("SMARTPLANT_PORT", "5000"))
START_TIME = time.time()

app = Flask(
    __name__,
    static_folder=str(BASE / "static"),
    static_url_path="",
    template_folder=str(BASE / "templates"),
)
app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
app.config["JSON_SORT_KEYS"] = False

LOCK = threading.RLock()

DEFAULTS = {
    "board_name": "Smart Plant ESP32",
    "board_type": "Smart Plant Controller + Arduino UNO relay D7",
    "board_token": "CHANGE-ME-BOARD-TOKEN",
    "link_mode": "poll",              # push | poll  (poll = PC reads the board)
    "board_url": "",                 # auto-discovery finds the controller on the local network
    "auto_discover": True,            # hunt for the board on the LAN when it is quiet
    "connection_timeout": 6,
    "soil_threshold": 30.0,
    "moisture_target": 60.0,
    "water_safety": 20.0,
    "max_runtime": 600,
    "schedule_enabled": False,
    "schedule_time": "06:30",
    "schedule_seconds": 20,
    "temp_min": 10.0,
    "temp_max": 45.0,
    "hum_min": 25.0,
    "hum_max": 95.0,
    "gas_alert": 60.0,
    "retention_days": 30,
    "ai_enabled": True,
    "ai_control_enabled": True,
    "ai_model": "openai/gpt-oss-20b",
    "weather_location": "",
    "audio_input_device": -1,
    "audio_output_device": -1,
    "io": {"soil": "GPIO34", "temperature_humidity": "GPIO4", "water_temp": "GPIO33", "water": "GPIO35", "mq2": "GPIO32", "pump": "UNO D7 via UART", "matrix_din": "GPIO23", "matrix_cs": "GPIO5", "matrix_clk": "GPIO18"},
}

CFG = dict(DEFAULTS)
CFG["io"] = dict(DEFAULTS["io"])
CONFIG_REVISION = 1

# PC build: pump cooldown is intentionally disabled. Pump runs can restart
# immediately after stop, subject to water-safety and max-runtime protections.

RUN = {
    "telemetry": None,          # last real sensor payload
    "last_seen": 0.0,
    "firmware": "Unknown",
    "pump": False,
    "auto_mode": True,
    "pump_started": None,
    "pump_until": None,         # timed run
    "queue": [],                # commands waiting for the board (push mode)
    "last_schedule": "",        # YYYY-MM-DD of the last scheduled run
    "board_error": "",
    "poll_fails": 0,          # consecutive failed polls, used to drop OFFLINE fast
    "scan": {
        "active": False,
        "checked": 0,
        "total": 0,
        "target": "",
        "found": "",
        "error": "",
    },
}

SCAN_STOP = threading.Event()
DISCOVERY_PORT = 4210
DISCOVERY_MESSAGE = b"SMARTPLANT_DISCOVER_V2"
PC_DISCOVERY_PORT = 4211
PC_DISCOVERY_REQUEST = b"SMARTPLANT_PC_DISCOVER_V1"


# --------------------------------------------------------------------------
# Google Text-to-Speech + phone-to-PC discovery
# --------------------------------------------------------------------------
# Text-to-speech is intentionally Google-only in this build. Groq remains the
# AI/chat + Whisper service, while Google TTS is used for audible replies.
GOOGLE_TTS_LANGS = {
    "en": "en",
    "si": "si",
    "ja": "ja",
}
GOOGLE_TTS_MAX_CHARS = 5000

def google_tts_available():
    return gTTS is not None

def google_tts_lang(language):
    return GOOGLE_TTS_LANGS.get(str(language or "en").lower().strip(), "en")

def google_tts_mp3(text, language="en"):
    if gTTS is None:
        raise RuntimeError("Google TTS package is not installed. Reinstall the app with the latest setup.exe.")
    clean = re.sub(r"\s+", " ", str(text or "").strip())[:GOOGLE_TTS_MAX_CHARS]
    if not clean:
        raise ValueError("TTS text is empty.")
    import io
    out = io.BytesIO()
    tts = gTTS(text=clean, lang=google_tts_lang(language), slow=False, lang_check=True)
    tts.write_to_fp(out)
    return out.getvalue()


# --------------------------------------------------------------------------
# Native Windows voice path
# --------------------------------------------------------------------------
# The desktop EXE should not depend on WebView microphone permissions.  On
# Windows the native recorder captures PCM directly with PortAudio (via
# sounddevice).  The captured WAV is sent to the existing Groq Whisper route,
# the existing plant-only AI controller decides allowed actions, and TTS is
# played through the Windows audio stack.  This removes WebView getUserMedia
# from the PC path entirely.

def _audio_devices_snapshot():
    """Return real PortAudio input/output devices plus selected/default devices."""
    if sounddevice is None or sys.platform != "win32":
        raise RuntimeError("Native Windows audio support is not installed or this is not Windows.")
    try:
        devices = sounddevice.query_devices()
    except Exception as exc:
        raise RuntimeError("Could not query Windows audio devices: %s" % str(exc).replace("\n", " ")[:420]) from exc

    inputs=[]; outputs=[]
    for idx, info in enumerate(devices):
        try:
            channels_in=int(info.get("max_input_channels",0) or 0)
            channels_out=int(info.get("max_output_channels",0) or 0)
            item={
                "index": int(idx),
                "name": str(info.get("name") or ("Audio device %d" % idx)),
                "hostapi": str(info.get("hostapi") if info.get("hostapi") is not None else ""),
                "input_channels": channels_in,
                "output_channels": channels_out,
                "default_samplerate": float(info.get("default_samplerate") or 0),
            }
            if channels_in>0: inputs.append(item)
            if channels_out>0: outputs.append(item)
        except Exception:
            continue

    default_in=-1; default_out=-1
    try:
        dd=sounddevice.default.device
        if isinstance(dd,(list,tuple)):
            if len(dd)>0 and isinstance(dd[0],int): default_in=int(dd[0])
            if len(dd)>1 and isinstance(dd[1],int): default_out=int(dd[1])
        elif isinstance(dd,int):
            default_in=int(dd)
    except Exception:
        pass

    selected_in=int(CFG.get("audio_input_device",-1) or -1)
    selected_out=int(CFG.get("audio_output_device",-1) or -1)
    valid_in={x["index"] for x in inputs}; valid_out={x["index"] for x in outputs}
    if selected_in not in valid_in: selected_in=-1
    if selected_out not in valid_out: selected_out=-1
    if default_in not in valid_in: default_in=inputs[0]["index"] if inputs else -1
    if default_out not in valid_out: default_out=outputs[0]["index"] if outputs else -1
    return {
        "ok": True,
        "inputs": inputs,
        "outputs": outputs,
        "default_input": default_in,
        "default_output": default_out,
        "selected_input": selected_in,
        "selected_output": selected_out,
    }


def _resolve_audio_device(direction="input"):
    snap=_audio_devices_snapshot()
    wanted=int(CFG.get("audio_input_device" if direction=="input" else "audio_output_device",-1) or -1)
    valid={x["index"] for x in (snap["inputs"] if direction=="input" else snap["outputs"])}
    if wanted in valid: return wanted
    return snap["default_input"] if direction=="input" else snap["default_output"]


def _record_native_wav(seconds=8, samplerate=16000, device=None):
    if sounddevice is None:
        raise RuntimeError("Native microphone support is not installed. Reinstall the app with the latest setup.exe.")
    seconds=max(2,min(15,int(seconds or 8)))
    device=_resolve_audio_device("input") if device is None else int(device)
    try:
        info=dict(sounddevice.query_devices(device=device))
    except Exception as exc:
        raise RuntimeError("Selected microphone could not be found: %s" % str(exc).replace("\n"," ")[:320]) from exc
    if int(info.get("max_input_channels",0) or 0) <= 0:
        raise RuntimeError("Selected audio device is not an input/microphone device.")
    actual_rate=int(round(float(info.get("default_samplerate") or samplerate)))
    if actual_rate < 8000 or actual_rate > 96000: actual_rate=int(samplerate)
    try:
        sounddevice.check_input_settings(device=device,samplerate=actual_rate,channels=1,dtype="int16")
    except Exception as first:
        for rate in (16000,44100,48000):
            if rate==actual_rate: continue
            try:
                sounddevice.check_input_settings(device=device,samplerate=rate,channels=1,dtype="int16")
                actual_rate=rate
                break
            except Exception:
                pass
        else:
            raise RuntimeError("Microphone format is not supported for '%s': %s" % (str(info.get("name") or "Selected mic"), str(first).replace("\n"," ")[:300])) from first

    frames=[]
    def callback(indata, frame_count, time_info, status):
        if status:
            # Status is informational; the captured bytes remain usable.
            pass
        frames.append(bytes(indata))
    try:
        with sounddevice.RawInputStream(device=device,samplerate=actual_rate,blocksize=0,dtype="int16",channels=1,callback=callback):
            deadline=time.monotonic()+seconds
            while time.monotonic()<deadline:
                time.sleep(0.05)
    except Exception as exc:
        raise RuntimeError("Windows microphone could not be opened: %s" % str(exc).replace("\n"," ")[:420]) from exc
    raw=b"".join(frames)
    if len(raw)<3200:
        raise RuntimeError("Microphone returned too little audio. Check Windows microphone privacy access and the selected input device.")
    import io, wave
    buf=io.BytesIO()
    with wave.open(buf,"wb") as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(actual_rate); wf.writeframes(raw)
    return buf.getvalue()


def _play_wav_sounddevice(data, device=None):
    if sounddevice is None: raise RuntimeError("sounddevice is not installed.")
    device=_resolve_audio_device("output") if device is None else int(device)
    import io, wave
    with wave.open(io.BytesIO(data),"rb") as wf:
        channels=wf.getnchannels(); rate=wf.getframerate(); width=wf.getsampwidth(); raw=wf.readframes(wf.getnframes())
    if width not in (1,2,4):
        raise RuntimeError("Unsupported WAV sample width: %d" % width)
    dtype={1:"int8",2:"int16",4:"int32"}[width]
    try:
        with sounddevice.RawOutputStream(device=device,samplerate=rate,blocksize=0,dtype=dtype,channels=channels) as out:
            out.write(raw)
    except Exception as exc:
        raise RuntimeError("Selected speaker could not play audio: %s" % str(exc).replace("\n"," ")[:420]) from exc


def _make_test_tone_wav():
    import io, wave
    rate=44100; channels=1; duration=0.65
    frames=bytearray()
    for n in range(int(rate*duration)):
        t=n/rate
        # Two short tones make the test obvious without being painfully loud.
        f=660.0 if t<0.30 else 880.0
        env=max(0.0,min(1.0, min(t/0.02,(duration-t)/0.03)))
        sample=int(0.18*env*32767.0*math.sin(2*math.pi*f*t))
        frames += struct.pack('<h',sample)
    buf=io.BytesIO()
    with wave.open(buf,'wb') as wf:
        wf.setnchannels(channels); wf.setsampwidth(2); wf.setframerate(rate); wf.writeframes(bytes(frames))
    return buf.getvalue()


def _capture_level(raw_wav):
    import io, wave
    with wave.open(io.BytesIO(raw_wav),'rb') as wf:
        raw=wf.readframes(wf.getnframes())
        width=wf.getsampwidth()
        channels=wf.getnchannels()
    if width!=2 or not raw: return {"peak":0,"rms":0.0}
    count=len(raw)//2
    # Sample at most 80k points for quick diagnostics.
    step=max(1,count//80000)
    total=0.0; peak=0; seen=0
    for i in range(0,count,step):
        off=i*2
        if off+2>len(raw): break
        v=abs(struct.unpack_from('<h',raw,off)[0])
        peak=max(peak,v); total += v*v; seen += 1
    rms=math.sqrt(total/seen) if seen else 0.0
    return {"peak":int(peak),"rms":round(rms,1),"channels":channels}


def _play_windows_audio(data, mime="audio/wav"):
    if not data:
        raise RuntimeError("No audio data was returned for playback.")
    if winsound is None or sys.platform != "win32":
        raise RuntimeError("Windows audio playback is unavailable.")
    mime_text=str(mime).lower()
    if "wav" in mime_text:
        # Prefer the app-selected PortAudio output. If that device cannot play
        # the WAV, fall back to the normal Windows sound endpoint.
        try:
            _play_wav_sounddevice(data)
            return
        except Exception as first:
            try:
                winsound.PlaySound(data, winsound.SND_MEMORY | winsound.SND_SYNC)
                return
            except Exception as second:
                raise RuntimeError("Speaker playback failed: %s | Windows fallback: %s" % (str(first)[:260], str(second)[:260])) from second

    import tempfile
    with tempfile.NamedTemporaryFile(prefix="smartplant_google_tts_", suffix=".mp3", delete=False) as fp:
        path=Path(fp.name); fp.write(data)
    errors=[]
    try:
        # Google generates the speech; pygame is only the native MP3 playback layer.
        if pygame is not None:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init(frequency=44100)
                pygame.mixer.music.load(str(path))
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    time.sleep(0.05)
                try: pygame.mixer.music.unload()
                except Exception: pass
                return
            except Exception as exc:
                errors.append("pygame: "+str(exc).replace("\n"," ")[:240])
        # Final fallback is audio playback only; no Microsoft speech synthesis is used.
        if sys.platform == "win32":
            try:
                import ctypes
                winmm=ctypes.windll.winmm; alias="smartplantgoogletts"
                command=lambda text: winmm.mciSendStringW(text, None, 0, 0)
                command("close %s" % alias)
                err=command('open "%s" type mpegvideo alias %s' % (str(path).replace('"',''), alias))
                if err: raise RuntimeError("MCI open error %s" % err)
                try:
                    err=command("play %s wait" % alias)
                    if err: raise RuntimeError("MCI play error %s" % err)
                    return
                finally: command("close %s" % alias)
            except Exception as exc:
                errors.append("Windows MP3 playback: "+str(exc).replace("\n"," ")[:260])
        raise RuntimeError("Google TTS audio playback failed. " + " | ".join(errors))
    finally:
        try: path.unlink(missing_ok=True)
        except Exception: pass


def native_audio_devices():
    try:
        return _audio_devices_snapshot()
    except Exception as exc:
        return {"ok":False,"inputs":[],"outputs":[],"error":str(exc).replace("\n"," ")[:500]}


def set_native_audio_devices(input_device=None, output_device=None):
    """Persist selected input/output device indexes in the Smart Plant settings."""
    snap=_audio_devices_snapshot()
    ins={x["index"] for x in snap["inputs"]}; outs={x["index"] for x in snap["outputs"]}
    with LOCK:
        if input_device is not None:
            iv=int(input_device)
            if iv != -1 and iv not in ins: raise RuntimeError("Selected microphone is not available.")
            CFG["audio_input_device"]=iv
        if output_device is not None:
            ov=int(output_device)
            if ov != -1 and ov not in outs: raise RuntimeError("Selected speaker is not available.")
            CFG["audio_output_device"]=ov
    save_config()
    return native_audio_devices()


def native_audio_test():
    """Real PC audio diagnostic: detect devices, play a tone, and capture the mic."""
    result={"ok":False,"speaker":False,"microphone":False,"microphone_capture":False,"error":""}
    if sounddevice is None or sys.platform!="win32":
        result["error"]="Native Windows audio support is unavailable."
        return result
    try:
        snap=_audio_devices_snapshot()
        result.update({"inputs":snap["inputs"],"outputs":snap["outputs"],"default_input":snap["default_input"],"default_output":snap["default_output"],"selected_input":snap["selected_input"],"selected_output":snap["selected_output"]})
        if not snap["outputs"]: raise RuntimeError("No speaker/output device was detected.")
        if not snap["inputs"]: raise RuntimeError("No microphone/input device was detected. Check Windows Privacy > Microphone.")
        result["input_device"] = next((x for x in snap["inputs"] if x["index"]==_resolve_audio_device("input")),snap["inputs"][0])
        result["output_device"] = next((x for x in snap["outputs"] if x["index"]==_resolve_audio_device("output")),snap["outputs"][0])
        try:
            _play_wav_sounddevice(_make_test_tone_wav())
            result["speaker"]=True
        except Exception as exc:
            result["error"]="Speaker: "+str(exc).replace("\n"," ")[:320]
        try:
            raw=_record_native_wav(seconds=2,device=_resolve_audio_device("input"))
            result["microphone_capture"]=True
            result["microphone"]=True
            result["microphone_level"]=_capture_level(raw)
        except Exception as exc:
            extra="Microphone: "+str(exc).replace("\n"," ")[:360]
            result["error"]=(result["error"]+" | "+extra).strip(" |")
        result["ok"]=bool(result["speaker"] and result["microphone_capture"])
        return result
    except Exception as exc:
        result["error"]=(result.get("error")+" | "+str(exc)).strip(" |")[:700]
        return result


def open_windows_microphone_settings():
    if sys.platform!="win32": return False
    try:
        os.startfile("ms-settings:privacy-microphone"); return True
    except Exception:
        try:
            import subprocess
            subprocess.Popen(["cmd","/c","start","","ms-settings:privacy-microphone"],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)); return True
        except Exception: return False


def open_windows_sound_settings():
    if sys.platform!="win32": return False
    try:
        os.startfile("ms-settings:sound"); return True
    except Exception:
        try:
            import subprocess
            subprocess.Popen(["cmd","/c","start","","ms-settings:sound"],creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)); return True
        except Exception: return False


def _native_tts_and_play(text_value, language):
    if not google_tts_available():
        raise RuntimeError("Google TTS is not installed. Reinstall the app with the latest setup.exe.")
    audio = google_tts_mp3(text_value, language)
    _play_windows_audio(audio, "audio/mpeg")
    return "Google TTS"


# --------------------------------------------------------------------------
# Self-update from GitHub Releases (PC installs setup.exe; phone opens the APK link)
# --------------------------------------------------------------------------
def _read_text_asset(name, default=""):
    for base in (BASE, Path(__file__).resolve().parent, Path(__file__).resolve().parent.parent):
        try:
            v = (base / name).read_text(encoding="utf-8").strip()
            if v:
                return v
        except OSError:
            pass
    return default


APP_VERSION = _read_text_asset("VERSION.txt", "0.0.0").lstrip("vV")
UPDATE_REPO = os.environ.get("SMARTPLANT_UPDATE_REPO", "").strip() or _read_text_asset("update_repo.txt", "")


def _ver_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v or ""))[:4]) or (0,)


def check_for_update():
    if not re.fullmatch(r"[\w.-]+/[\w.-]+", UPDATE_REPO or ""):
        return {"ok": False, "error": "Update repository is not configured (build the app through the GitHub workflow)."}
    req = urllib.request.Request("https://api.github.com/repos/%s/releases/latest" % UPDATE_REPO,
                                 headers={"Accept": "application/vnd.github+json", "User-Agent": "SmartPlant-Updater"})
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            rel = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        msg = "No release published yet." if exc.code == 404 else "GitHub error %s" % exc.code
        return {"ok": False, "error": msg, "current": APP_VERSION}
    except Exception as exc:
        return {"ok": False, "error": "Cannot reach GitHub: " + str(exc)[:160], "current": APP_VERSION}
    latest = str(rel.get("tag_name") or "").lstrip("vV")
    exe = apk = None
    for a in rel.get("assets") or []:
        n = str(a.get("name") or "").lower()
        if n.endswith(".exe") and "setup" in n:
            exe = a.get("browser_download_url")
        elif n.endswith(".apk"):
            apk = a.get("browser_download_url")
    return {"ok": True, "current": APP_VERSION, "latest": latest,
            "update_available": _ver_tuple(latest) > _ver_tuple(APP_VERSION),
            "exe_url": exe, "apk_url": apk, "notes": str(rel.get("body") or "")[:1500]}


def install_update_windows():
    """Download the latest setup.exe from our GitHub release and run it silently."""
    if sys.platform != "win32":
        return {"ok": False, "error": "Installing updates is only supported on Windows."}
    info = check_for_update()
    if not info.get("ok"):
        return info
    if not info.get("update_available"):
        return {"ok": False, "error": "You already have the latest version (%s)." % info["current"]}
    url = info.get("exe_url") or ""
    if not url.startswith("https://github.com/" + UPDATE_REPO + "/"):
        return {"ok": False, "error": "The release has no setup.exe attached."}
    dest = os.path.join(tempfile.gettempdir(), "SmartPlantIrrigationSystem_Setup_update.exe")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "SmartPlant-Updater"})
        with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
            shutil_copy = r.read(1 << 20)
            total = 0
            while shutil_copy:
                f.write(shutil_copy); total += len(shutil_copy)
                shutil_copy = r.read(1 << 20)
        if total < 1_000_000:
            raise RuntimeError("Downloaded file is too small (%d bytes)." % total)
    except Exception as exc:
        return {"ok": False, "error": "Download failed: " + str(exc)[:200]}
    import subprocess
    subprocess.Popen([dest, "/SILENT", "/CLOSEAPPLICATIONS", "/RESTARTAPPLICATIONS", "/SP-"],
                     creationflags=getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
    threading.Timer(1.5, lambda: os._exit(0)).start()
    return {"ok": True, "installing": info["latest"]}


# --------------------------------------------------------------------------
# Persistent AI memory (survives restarts): remembered facts + recent turns
# --------------------------------------------------------------------------
_REMEMBER_PATTERNS = [
    r"(?:please\s+)?remember\s+(?:that\s+)?(.+)",
    r"(?:don'?t|do not)\s+forget\s+(?:that\s+)?(.+)",
    r"(.+?)\s+(?:mathak|mathaka)\s+(?:thiyaganna|thiyagann?a|thibbanna)\b",
    r"(?:mathak|mathaka)\s+(?:thiyaganna|karaganna)\s*[:,-]?\s*(.+)",
    r"මතක\s*තියාගන්න[,:\s]*(.+)",
    r"(.+?)\s+මතක\s*තියාගන්න",
    r"(.+?)\s+(?:අමතක\s*කරන්න\s*එපා)",
]
_FORGET_RE = re.compile(r"(?:forget everything|clear (?:your )?memory|memory eka (?:clear|delete)|memory eka ain karanna|මතකය\s*මකන්න|මතක\s*මකන්න)", re.I)


def _mem_db():
    c = db()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS ai_memory_facts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, fact TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS ai_memory_turns(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL);
        """
    )
    return c


def memory_extract_fact(text):
    raw = re.sub(r"\s+", " ", str(text or "").strip())
    if not raw or len(raw) > 400:
        return None
    for pat in _REMEMBER_PATTERNS:
        m = re.search(pat, raw, re.I)
        if m:
            fact = m.group(1).strip(" .,:;!?-")
            if 3 <= len(fact) <= 300:
                return fact
    return None


def memory_facts():
    try:
        c = _mem_db()
        try:
            return [r["fact"] for r in c.execute("SELECT fact FROM ai_memory_facts ORDER BY id DESC LIMIT 30")][::-1]
        finally:
            c.close()
    except Exception:
        return []


def memory_recent_turns(n=8):
    try:
        c = _mem_db()
        try:
            rows = c.execute("SELECT role,text FROM ai_memory_turns ORDER BY id DESC LIMIT ?", (int(n),)).fetchall()
        finally:
            c.close()
        return [{"role": r["role"], "text": r["text"]} for r in rows][::-1]
    except Exception:
        return []


def memory_save_turn(user_text, reply_text):
    try:
        c = _mem_db()
        try:
            t = stamp()
            c.execute("INSERT INTO ai_memory_turns(ts,role,text) VALUES(?,?,?)", (t, "user", str(user_text)[:1200]))
            c.execute("INSERT INTO ai_memory_turns(ts,role,text) VALUES(?,?,?)", (t, "assistant", str(reply_text)[:1200]))
            c.execute("DELETE FROM ai_memory_turns WHERE id NOT IN (SELECT id FROM ai_memory_turns ORDER BY id DESC LIMIT 200)")
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def memory_add_fact(fact):
    c = _mem_db()
    try:
        c.execute("INSERT OR IGNORE INTO ai_memory_facts(ts,fact) VALUES(?,?)", (stamp(), fact[:300]))
        c.execute("DELETE FROM ai_memory_facts WHERE id NOT IN (SELECT id FROM ai_memory_facts ORDER BY id DESC LIMIT 100)")
        c.commit()
    finally:
        c.close()


def memory_clear():
    c = _mem_db()
    try:
        c.execute("DELETE FROM ai_memory_facts"); c.execute("DELETE FROM ai_memory_turns"); c.commit()
    finally:
        c.close()


def _local_ai_reply(message, language="en", history=None):
    """Local reply with persistent memory. Ollama first; Groq fallback if Ollama is down.

    Returns (reply_text, info_dict, backend_label).
    """
    info = local_voice.detect_language_and_dialect(message)
    si = info.get("language") in ("si", "singlish", "mixed") or language == "si"
    if _FORGET_RE.search(message):
        memory_clear()
        return ("හරි, මම මතකය සම්පූර්ණයෙන්ම මකා දැමුවා." if si else "Okay, I cleared my memory."), info, "memory"
    fact = memory_extract_fact(message)
    if fact:
        memory_add_fact(fact)
        add_event("AI Memory", fact[:120])
        reply = ("හරි, මතක තියාගත්තා: " + fact) if si else ("Okay, I'll remember: " + fact)
        memory_save_turn(message, reply)
        return reply, info, "memory"
    # Use the UI history when present, otherwise the persisted turns (so memory survives restarts).
    hist = history if isinstance(history, list) and history else memory_recent_turns(8)
    try:
        reply = local_voice.ollama_chat(message, info, history=hist, live_context=snapshot(),
                                        ui_language=language, memory=memory_facts())
        backend = "ollama:" + local_voice.OLLAMA_MODEL
    except Exception as local_exc:
        if ai_key() and Groq is not None:
            envelope, err = ai_reply(message, language, hist, "pc")
            if err or not envelope or not envelope.get("reply"):
                raise local_exc
            reply, backend = str(envelope["reply"]).strip(), "groq-fallback"
        else:
            raise local_exc
    memory_save_turn(message, reply)
    return reply, info, backend


def _local_apply_control(spoken, reply):
    """Run explicit (Sinhala / Singlish / English) control commands and annotate the reply."""
    action = _explicit_control_fallback(spoken)
    action_result = _execute_ai_action(action) if action else {"executed": False, "reason": "no_control_requested"}
    if action:
        if action_result.get("executed"):
            reply += "\n\nControl applied: " + str(action_result.get("action"))
            if action_result.get("seconds"):
                reply += " for %ds." % int(action_result["seconds"])
        else:
            reply += "\n\nControl not applied: " + str(action_result.get("reason") or "unknown control error")
    return reply, action, action_result


def native_local_tts(text_value, language="en"):
    text_value = str(text_value or "").strip()
    try:
        wav = local_voice.synthesize_wav(text_value, language)
        if wav:
            _play_windows_audio(wav, "audio/wav")
            return {"ok": True, "engine": "coqui-local"}
        engine = local_voice.local_tts(text_value, language)
        return {"ok": True, "engine": engine}
    except local_voice.NoLocalVoice as exc:
        # No Sinhala/Japanese voice installed locally: fall back to Google TTS if available.
        try:
            return {"ok": True, "engine": _native_tts_and_play(text_value, language) + " (fallback: no local voice)"}
        except Exception as exc2:
            return {"ok": False, "error": (str(exc) + " Fallback failed: " + str(exc2)).replace("\n", " ")[:700]}
    except Exception as exc:
        return {"ok": False, "error": str(exc).replace("\n", " ")[:700]}


def native_tts(text_value, language="en"):
    """PyWebView-safe native TTS bridge used by the PC dashboard.

    The launcher exposes this function directly to JavaScript, so it must
    always return a JSON-safe result instead of raising into the bridge.
    """
    try:
        engine=_native_tts_and_play(str(text_value or "").strip(), language)
        return {"ok": True, "engine": engine}
    except Exception as exc:
        return {"ok": False, "error": str(exc).replace("\n", " ")[:700]}


def native_voice_chat(language="en", platform="pc", seconds=8, history=None):
    """Run one native desktop voice turn and return transcript + AI reply."

    Returns a JSON-safe dictionary for the pywebview bridge.  The PC EXE uses
    this path instead of browser/WebView microphone capture, so the Voice orb
    can work even when WebView's microphone permission is unavailable.
    """
    language=str(language or "en").lower().strip()
    if language not in ("en","si","ja"):
        language="en"
    raw=_record_native_wav(seconds=seconds)
    key=ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    if Groq is None:
        raise RuntimeError("Groq Python SDK is not installed on the PC.")

    client=Groq(api_key=key)
    result=client.audio.transcriptions.create(
        file=("smartplant-native-voice.wav",raw),
        model="whisper-large-v3-turbo",
        language=language,
        response_format="json",
        temperature=0.0,
        prompt="Smart Plant irrigation system, plant, soil moisture, water tank, pump, auto irrigation, sensor, temperature, humidity, developer, Tharusha, Geenuka, Sudesh.",
    )
    spoken=str(getattr(result,"text","") or "").strip()
    if not spoken:
        raise RuntimeError("No speech was detected. Please speak after the microphone starts.")

    envelope,err=ai_reply(spoken,language,history or [],platform or "pc")
    if err:
        raise RuntimeError(err)
    if envelope is not None and envelope.get("action") is None:
        fallback_action=_explicit_control_fallback(spoken)
        if fallback_action is not None:
            envelope["action"]=fallback_action
    action_result=_execute_ai_action(envelope.get("action")) if envelope else {"executed":False,"reason":"no_ai_response"}
    final_reply=str(envelope.get("reply") or "").strip()
    if envelope and envelope.get("action") is not None:
        if action_result.get("executed"):
            final_reply += "\n\nControl applied: " + str(action_result.get("action"))
            if action_result.get("seconds"):
                final_reply += " for %ds." % int(action_result["seconds"])
        else:
            final_reply += "\n\nControl not applied: " + str(action_result.get("reason") or "unknown control error")

    # Return the transcript and AI answer before any speech synthesis.
    # The desktop frontend performs Google TTS separately, preventing the
    # native bridge call from blocking the UI on network TTS/audio playback.
    return {
        "ok": True,
        "transcript": spoken[:4000],
        "reply": final_reply[:12000],
        "model": ai_model(),
        "action": envelope.get("action") if envelope else None,
        "action_result": action_result,
        "tts_engine": "frontend-google-tts",
        "tts_error": "",
    }



def native_local_voice_chat(language="en", seconds=8, history=None):
    """One fully local voice turn: native mic -> Whisper -> dialect -> Ollama -> control."""
    language = str(language or "en").lower().strip()
    if language not in ("en", "si", "ja"):
        language = "en"
    raw = _record_native_wav(seconds=seconds)
    tmp = tempfile.NamedTemporaryFile(prefix="smartplant_local_voice_", suffix=".wav", delete=False)
    tmp.write(raw)
    tmp.close()
    try:
        spoken = local_voice.transcribe_audio(tmp.name, language=language)
    except Exception as exc:
        return {"ok": False, "error": str(exc).replace("\n", " ")[:700]}
    finally:
        try: os.unlink(tmp.name)
        except OSError: pass
    try:
        reply, info, backend = _local_ai_reply(spoken, language, history)
    except Exception as exc:
        return {"ok": False, "transcript": spoken[:4000], "error": str(exc).replace("\n", " ")[:900]}
    final_reply, action, action_result = _local_apply_control(spoken, reply)
    return {
        "ok": True,
        "transcript": spoken[:4000],
        "language": info.get("language"),
        "dialect": info.get("dialect"),
        "reply": final_reply[:12000],
        "model": backend,
        "action": action,
        "action_result": action_result,
        "tts_engine": "local",
    }

def pc_discovery_loop():
    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", PC_DISCOVERY_PORT))
        while True:
            try:
                data, addr = sock.recvfrom(1024)
            except OSError:
                break
            if data.strip() != PC_DISCOVERY_REQUEST or not addr:
                continue
            reply = "SMARTPLANT_PC_DISCOVER_V1|%s|%d|Smart Plant PC" % (lan_ip(), PORT)
            try:
                sock.sendto(reply.encode("utf-8"), addr)
            except OSError:
                pass
    except OSError:
        pass
    finally:
        if sock is not None:
            try: sock.close()
            except OSError: pass

# --------------------------------------------------------------------------
# database
# --------------------------------------------------------------------------
def db():
    c = sqlite3.connect(DB_PATH, timeout=10)
    c.row_factory = sqlite3.Row
    return c


def init_db():
    c = db()
    c.executescript(
        """
        CREATE TABLE IF NOT EXISTS sensor_history(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            soil REAL NOT NULL, temperature REAL NOT NULL, humidity REAL NOT NULL,
            water REAL NOT NULL, gas REAL, water_temp REAL,
            pump INTEGER NOT NULL, auto_mode INTEGER NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_hist_ts ON sensor_history(timestamp);

        CREATE TABLE IF NOT EXISTS events(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL, event TEXT NOT NULL, details TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_ev_ts ON events(timestamp);

        CREATE TABLE IF NOT EXISTS plants(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, plant_type TEXT NOT NULL, zone TEXT NOT NULL,
            moisture_min REAL NOT NULL, moisture_target REAL NOT NULL, notes TEXT NOT NULL);

        CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """
    )
    # Schema migration for older project databases. Older builds did not have MQ-2 gas history.
    cols = {row[1] for row in c.execute("PRAGMA table_info(sensor_history)").fetchall()}
    if "gas" not in cols:
        c.execute("ALTER TABLE sensor_history ADD COLUMN gas REAL")
        cols.add("gas")
    if "water_temp" not in cols:
        c.execute("ALTER TABLE sensor_history ADD COLUMN water_temp REAL")
        cols.add("water_temp")
    if "ph" in cols:
        # The pH probe was dropped from the hardware build. SQLite can't just
        # drop a NOT NULL column, so rebuild the table without it and keep
        # every existing row of history.
        c.executescript(
            """
            CREATE TABLE sensor_history_new(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                soil REAL, temperature REAL, humidity REAL,
                water REAL, gas REAL, water_temp REAL,
                pump INTEGER NOT NULL, auto_mode INTEGER NOT NULL);
            INSERT INTO sensor_history_new(id,timestamp,soil,temperature,humidity,water,gas,water_temp,pump,auto_mode)
                SELECT id,timestamp,soil,temperature,humidity,water,gas,water_temp,pump,auto_mode FROM sensor_history;
            DROP TABLE sensor_history;
            ALTER TABLE sensor_history_new RENAME TO sensor_history;
            CREATE INDEX IF NOT EXISTS idx_hist_ts ON sensor_history(timestamp);
            """
        )
        cols = {row[1] for row in c.execute("PRAGMA table_info(sensor_history)").fetchall()}

    # Newer hardware builds may have only part of the sensor set connected.
    # Make the sensor columns nullable so the history stores real available
    # readings without inventing 0%/0°C values for missing channels.
    info = c.execute("PRAGMA table_info(sensor_history)").fetchall()
    notnull = {row[1]: bool(row[3]) for row in info}
    sensor_cols = ("soil", "temperature", "humidity", "water")
    if any(notnull.get(k, False) for k in sensor_cols):
        c.executescript(
            """
            CREATE TABLE sensor_history_new(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                soil REAL, temperature REAL, humidity REAL,
                water REAL, gas REAL, water_temp REAL,
                pump INTEGER NOT NULL, auto_mode INTEGER NOT NULL);
            INSERT INTO sensor_history_new(id,timestamp,soil,temperature,humidity,water,gas,water_temp,pump,auto_mode)
                SELECT id,timestamp,soil,temperature,humidity,water,gas,water_temp,pump,auto_mode FROM sensor_history;
            DROP TABLE sensor_history;
            ALTER TABLE sensor_history_new RENAME TO sensor_history;
            CREATE INDEX IF NOT EXISTS idx_hist_ts ON sensor_history(timestamp);
            """
        )
    c.commit()
    c.close()


def load_config():
    c = db()
    row = c.execute("SELECT value FROM settings WHERE key='config'").fetchone()
    if not row:
        c.close()
        return
    try:
        stored = json.loads(row["value"])
    except ValueError:
        c.close()
        return

    # Remove API-key fields left behind by older builds. Only the supported
    # provider secret names are recognized by the active application.
    allowed_secret_keys = {"groq_api_key", "openweather_api_key"}
    stale_secret_keys = {k for k in stored.keys() if isinstance(k, str) and k.endswith("_api_key") and k not in allowed_secret_keys} if isinstance(stored, dict) else set()
    scrubbed = bool(stale_secret_keys) if isinstance(stored, dict) else False
    if isinstance(stored, dict):
        for k in stale_secret_keys:
            stored.pop(k, None)
        # Supported secrets are never kept in the general config blob.
        for k in allowed_secret_keys:
            if k in stored:
                stored.pop(k, None)
                scrubbed = True

    with LOCK:
        for key, default in DEFAULTS.items():
            if key not in stored:
                continue
            if key == "io" and isinstance(stored[key], dict):
                CFG["io"].update({k: str(v)[:24] for k, v in stored[key].items() if k in DEFAULTS["io"]})
            elif not isinstance(default, dict):
                CFG[key] = stored[key]

    if scrubbed:
        clean_blob = json.dumps(CFG, ensure_ascii=False)
        c.execute("UPDATE settings SET value=? WHERE key='config'", (clean_blob,))
        c.commit()
    c.close()


def save_config():
    # Never persist API secrets, even if a stale caller sends one.
    global CONFIG_REVISION
    with LOCK:
        clean = {k: v for k, v in CFG.items() if not (isinstance(k, str) and k.endswith("_api_key"))}
        blob = json.dumps(clean, ensure_ascii=False)
    c = db()
    c.execute("INSERT INTO settings(key,value) VALUES('config',?) "
              "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (blob,))
    c.commit()
    c.close()
    with LOCK:
        CONFIG_REVISION += 1


def add_event(event, details=""):
    c = db()
    c.execute("INSERT INTO events(timestamp,event,details) VALUES(?,?,?)",
              (stamp(), event, str(details)[:240]))
    c.commit()
    c.close()


def stamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def clamp(v, lo, hi):
    return max(lo, min(hi, float(v)))


def lan_ip():
    """Return a usable local IPv4 address without requiring internet access."""
    candidates = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip.startswith(("127.", "169.254.")):
                continue
            try:
                if ipaddress.ip_address(ip).is_private:
                    candidates.append(ip)
            except ValueError:
                pass
    except OSError:
        pass
    if candidates:
        return candidates[0]
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 9))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith("127."):
            return ip
    except OSError:
        pass
    return "127.0.0.1"


def board_base():
    u = str(CFG.get("board_url") or "").strip()
    if not u:
        return ""
    if not u.startswith(("http://", "https://")):
        u = "http://" + u
    return u.rstrip("/")


def connected():
    with LOCK:
        return bool(RUN["telemetry"] and time.time() - RUN["last_seen"] <= CFG["connection_timeout"])


def set_pump(on, seconds=None):
    with LOCK:
        on = bool(on)
        if on and not RUN["pump"]:
            RUN["pump_started"] = time.time()
        if not on and RUN["pump"]:
            RUN["pump_started"] = None
            RUN["pump_until"] = None
        RUN["pump"] = on
        if on and seconds:
            RUN["pump_until"] = time.time() + float(seconds)


def queue_command(action, seconds=None):
    """Deliver a command directly to the discovered ESP32 whenever possible."""
    cmd = {"action": action, "queued_at": datetime.now().isoformat(timespec="seconds")}
    if seconds:
        cmd["seconds"] = int(seconds)
    # Current architecture is PC -> same Wi-Fi -> ESP32. Direct control is
    # therefore authoritative; the local queue remains only as a legacy push
    # compatibility path when no board URL is available yet.
    if board_base():
        ok, detail = board_post("/api/control", cmd)
        if not ok:
            with LOCK:
                RUN["board_error"] = detail
        return ok
    with LOCK:
        RUN["queue"].append(cmd)
        RUN["queue"] = RUN["queue"][-25:]
    return True


def board_get(path, timeout=4):
    base = board_base()
    if not base:
        return None, "No board address set."
    try:
        req = urllib.request.Request(base + path, headers={"Accept": "application/json"})
        with DIRECT_LAN_OPENER.open(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace")), ""
    except (urllib.error.URLError, socket.timeout, ValueError, OSError) as e:
        return None, str(e)[:120]


def board_post(path, payload, timeout=4):
    base = board_base()
    if not base:
        return False, "No board address set."
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(base + path, data=data, method="POST",
                                     headers={"Content-Type": "application/json"})
        with DIRECT_LAN_OPENER.open(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", "replace")
        try:
            return bool(json.loads(body).get("ok", True)), body[:120]
        except ValueError:
            return True, body[:120]
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        return False, str(e)[:120]


def _pct(v):
    """0-100 reading, or None when the sensor is not answering."""
    if v is None:
        return None
    try:
        return round(clamp(v, 0, 100), 1)
    except (TypeError, ValueError):
        return None


def _num(v):
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if f != f else round(f, 1)          # f != f catches NaN


def accept_telemetry(d, source="push"):
    """Accept a real board response even when sensors are not wired yet.

    Connection state is based on the controller answering and identifying
    itself, not on whether every sensor currently has a value. Missing sensor
    channels stay None and are rendered as "--"; they are never replaced with
    synthetic zeroes.
    """
    sensors = d.get("sensors") if isinstance(d.get("sensors"), dict) else {}
    reading = {
        "soil": _pct(d.get("soil", sensors.get("soil"))),
        "temperature": _num(d.get("temperature", sensors.get("temperature"))),
        "humidity": _pct(d.get("humidity", sensors.get("humidity"))),
        "water": _pct(d.get("water", sensors.get("water"))),
        "gas": _pct(d.get("gas", sensors.get("gas"))),
        "water_temp": _num(d.get("water_temp", sensors.get("water_temp"))),
    }

    identity = " ".join(str(d.get(k, "")) for k in ("project", "board_name", "board_type", "firmware"))
    is_controller = "smartplant" in identity.lower().replace(" ", "") or "smart plant" in identity.lower()
    if not is_controller:
        return False, "The response is not a Smart Plant controller."

    with LOCK:
        first = RUN["telemetry"] is None
        RUN["telemetry"] = reading
        RUN["last_seen"] = time.time()
        RUN["board_error"] = ""
        if d.get("firmware"):
            RUN["firmware"] = str(d["firmware"])[:64]
        if d.get("board_name"):
            CFG["board_name"] = str(d["board_name"])[:64]
        if d.get("board_type"):
            CFG["board_type"] = str(d["board_type"])[:64]
        # The board is the authority on its own relay state.
        if "pump" in d:
            RUN["pump"] = bool(d["pump"])
        if "auto_mode" in d:
            RUN["auto_mode"] = bool(d["auto_mode"])
    if first:
        add_event("Link", "Controller reported in (%s mode)" % source)
    store_sample()
    return True, ""


def store_sample():
    """Store a row when the reading actually changed - no duplicate spam."""
    with LOCK:
        t = dict(RUN["telemetry"] or {})
        pump, auto = RUN["pump"], RUN["auto_mode"]
    if not t:
        return
    c = db()
    last = c.execute("SELECT soil,temperature,humidity,water,gas,water_temp,pump FROM sensor_history "
                     "ORDER BY id DESC LIMIT 1").fetchone()
    # Store exactly the real readings that are available. SQLite sensor
    # columns are nullable after the compatibility migration above, so a
    # disconnected channel remains NULL instead of becoming a fake zero.
    if all(t.get(k) is None for k in ("soil", "temperature", "humidity", "water", "gas", "water_temp")):
        c.close()
        return
    core = {k: t.get(k) for k in ("soil", "temperature", "humidity", "water", "gas")}
    same = last and all([
        last["soil"] == core["soil"],
        last["temperature"] == core["temperature"],
        last["humidity"] == core["humidity"],
        last["water"] == core["water"],
        last["gas"] == core["gas"],
        last["water_temp"] == t.get("water_temp"),
        last["pump"] == int(pump),
    ])
    if not same:
        c.execute("INSERT INTO sensor_history(timestamp,soil,temperature,humidity,water,gas,water_temp,pump,auto_mode) "
                  "VALUES(?,?,?,?,?,?,?,?,?)",
                  (stamp(), core["soil"], core["temperature"], core["humidity"], core["water"],
                   core["gas"], t.get("water_temp"), int(pump), int(auto)))
        c.commit()
    c.close()


def snapshot():
    with LOCK:
        on = connected()
        t = dict(RUN["telemetry"] or {})
        out = {
            "connected": on,
            "board_online": on,
            "telemetry_stale": not on,
            "board_name": CFG["board_name"],
            "board_type": CFG["board_type"],
            "firmware": RUN["firmware"],
            "link_mode": CFG["link_mode"],
            "last_seen": datetime.fromtimestamp(RUN["last_seen"]).strftime("%H:%M:%S") if RUN["last_seen"] else None,
            "soil": t.get("soil"), "temperature": t.get("temperature"),
            "humidity": t.get("humidity"), "water": t.get("water"), "gas": t.get("gas"),
            "water_temp": t.get("water_temp"),
            "pump": bool(RUN["pump"]) if on else False,
            "auto_mode": bool(RUN["auto_mode"]),
            "soil_threshold": CFG["soil_threshold"],
            "moisture_target": CFG["moisture_target"],
            "water_safety": CFG["water_safety"],
            "pump_seconds": int(time.time() - RUN["pump_started"]) if RUN["pump_started"] else None,
            "board_error": RUN["board_error"],
            "uptime": human_uptime(time.time() - START_TIME),
        }
    return out


def human_uptime(sec):
    sec = int(sec)
    h, m = sec // 3600, (sec % 3600) // 60
    if h:
        return "%dh %dm" % (h, m)
    return "%dm %ds" % (m, sec % 60)


def build_alerts(s):
    alerts = []
    if not s["connected"]:
        detail = RUN["board_error"] or "No recent telemetry from the controller."
        alerts.append({"level": "critical", "title": "Controller offline", "details": detail})
        return alerts
    if s["soil"] is not None and s["soil"] <= CFG["soil_threshold"]:
        alerts.append({"level": "warning", "title": "Soil is dry",
                       "details": "Soil %.1f%% is at or below the %.1f%% start point." % (s["soil"], CFG["soil_threshold"])})
    if s["water"] is not None and s["water"] <= CFG["water_safety"]:
        alerts.append({"level": "critical", "title": "Water tank low",
                       "details": "Tank %.1f%% is at or below the %.1f%% safety minimum. Refill it." % (s["water"], CFG["water_safety"])})
    if s["temperature"] is not None and not CFG["temp_min"] <= s["temperature"] <= CFG["temp_max"]:
        alerts.append({"level": "warning", "title": "Temperature out of range",
                       "details": "%.1f°C is outside %.0f–%.0f°C." % (s["temperature"], CFG["temp_min"], CFG["temp_max"])})
    if s["humidity"] is not None and not CFG["hum_min"] <= s["humidity"] <= CFG["hum_max"]:
        alerts.append({"level": "warning", "title": "Humidity out of range",
                       "details": "%.1f%% is outside %.0f–%.0f%%." % (s["humidity"], CFG["hum_min"], CFG["hum_max"])})
    if s.get("gas") is not None and s["gas"] >= CFG["gas_alert"]:
        alerts.append({"level": "critical", "title": "MQ-2 gas level high",
                       "details": "Relative gas level %.1f%% is at or above the %.1f%% alert level." % (s["gas"], CFG["gas_alert"])})
    return alerts


# --------------------------------------------------------------------------
# background worker: safety, automation, schedule, poll bridge, pruning
# --------------------------------------------------------------------------
def local_subnets():
    """Return IPv4 network prefixes visible on this PC, preferring real masks."""
    nets, seen = [], set()

    # Optional psutil gives the exact Windows/Linux interface netmask.
    try:
        import psutil
        for entries in psutil.net_if_addrs().values():
            for a in entries:
                if getattr(a, "family", None) != socket.AF_INET:
                    continue
                ip = str(getattr(a, "address", ""))
                mask = str(getattr(a, "netmask", ""))
                if not ip or ip.startswith(("127.", "169.254.")):
                    continue
                if mask:
                    try:
                        net = ipaddress.ip_network(f"{ip}/{mask}", strict=False)
                        if net.version == 4 and net.prefixlen <= 30:
                            # On wider Wi-Fi networks (/16, /8), a full sweep of
                            # the entire address space is not practical. The UDP
                            # discovery path covers the broadcast domain; for TCP
                            # fallback scan the /24 containing this host instead of
                            # incorrectly probing 10.0.0.x for a 10.x LAN.
                            if net.prefixlen < 24:
                                net = ipaddress.ip_network(f"{ip}/24", strict=False)
                            if str(net) not in seen:
                                seen.add(str(net))
                                nets.append(net)
                    except ValueError:
                        pass
    except Exception:
        pass

    # Fallback: host address list, treating the common Wi-Fi case as /24.
    if not nets:
        try:
            for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
                ip = info[4][0]
                if ip.startswith(("127.", "169.254.")):
                    continue
                try:
                    net = ipaddress.ip_network(f"{ip}/24", strict=False)
                    if str(net) not in seen:
                        seen.add(str(net))
                        nets.append(net)
                except ValueError:
                    pass
        except OSError:
            pass

    # Route-derived address, without requiring DNS/internet connectivity.
    try:
        s4 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s4.connect(("192.0.2.1", 9))
        ip = s4.getsockname()[0]
        s4.close()
        if ip and not ip.startswith(("127.", "169.254.")):
            net = ipaddress.ip_network(f"{ip}/24", strict=False)
            if str(net) not in seen:
                seen.add(str(net))
                nets.insert(0, net)
    except OSError:
        pass
    return nets


def looks_like_board(data):
    if not isinstance(data, dict):
        return False
    project = str(data.get("project", "")).strip().lower()
    board_name = str(data.get("board_name", "")).strip().lower()
    firmware = str(data.get("firmware", "")).strip().lower()
    device = str(data.get("device_id", "")).strip().lower()
    identity = " ".join((project, board_name, firmware, device))
    # Require project-specific identity, never just "ESP32".
    return "smartplant" in identity.replace(" ", "") or "smart plant" in identity


def discovery_broadcasts():
    """Return useful IPv4 broadcast targets for the interfaces on this PC."""
    targets = ["255.255.255.255"]
    try:
        # The OS route used for outbound traffic is usually the active LAN.
        s4 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s4.connect(("8.8.8.8", 80))
            ip = s4.getsockname()[0]
            if "." in ip:
                a, b, c, _ = ip.split(".")
                targets.append("%s.%s.%s.255" % (a, b, c))
        finally:
            s4.close()
    except OSError:
        pass
    # Also include any IPv4 /24 networks reported by the host.
    for net in local_subnets():
        try:
            targets.append(str(net.broadcast_address))
        except Exception:
            pass
    out, seen = [], set()
    for x in targets:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def parse_discovery_packet(data):
    try:
        raw = data.decode("utf-8", "replace").strip()
    except Exception:
        return None
    parts = raw.split("|")
    if len(parts) < 4 or parts[0] != "SMARTPLANT_DISCOVER_V2":
        return None
    ip = parts[1].strip()
    try:
        parsed = ipaddress.ip_address(ip)
        if parsed.version != 4 or not parsed.is_private:
            return None
    except ValueError:
        return None
    if "smartplant" not in parts[2].lower().replace(" ", ""):
        return None
    return ip


def udp_discover(timeout=2.2, progress=None):
    """Ask the local broadcast domain for a Smart Plant controller.

    This is the fast path used by the PC app. The firmware answers with its
    current IP, so DHCP/static-IP changes do not break discovery. TCP subnet
    probing remains as a fallback.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.settimeout(0.35)
        try:
            sock.bind(("", 0))
        except OSError:
            pass

        for broadcast in discovery_broadcasts():
            if SCAN_STOP.is_set():
                return ""
            packet = DISCOVERY_MESSAGE
            try:
                sock.sendto(packet, (broadcast, DISCOVERY_PORT))
                if progress:
                    progress(0, 1, "UDP broadcast discovery → %s" % broadcast, "")
            except OSError:
                continue

        deadline = time.time() + timeout
        while time.time() < deadline and not SCAN_STOP.is_set():
            try:
                data, addr = sock.recvfrom(1024)
            except socket.timeout:
                continue
            except OSError:
                break
            if not addr:
                continue
            ip = addr[0]
            packet_ip = parse_discovery_packet(data)
            if packet_ip:
                verified = probe_ip(packet_ip, timeout=0.7)
                if verified:
                    return verified
            elif probe_ip(ip, timeout=0.7):
                return ip
    finally:
        sock.close()
    return ""


def probe_ip(ip, timeout=0.45):
    """Return the IP only when /api/state identifies a Smart Plant ESP32."""
    try:
        req = urllib.request.Request(
            "http://%s/api/state" % ip,
            headers={"Accept": "application/json", "Cache-Control": "no-cache"},
        )
        with DIRECT_LAN_OPENER.open(req, timeout=timeout) as r:
            if r.getcode() != 200:
                return None
            data = json.loads(r.read().decode("utf-8", "replace"))
        return ip if looks_like_board(data) else None
    except Exception:
        return None


def build_scan_targets():
    """Build a complete, de-duplicated LAN scan plan with best candidates first."""
    targets = []

    def add(host):
        host = str(host or "").strip()
        if not host:
            return
        host = host.replace("http://", "").replace("https://", "")
        host = host.split("/")[0].split(":")[0].strip()
        if host and host not in targets:
            targets.append(host)

    # Fast candidates first. A saved IP makes a reconnect nearly instant.
    saved = str(CFG.get("board_url") or "").strip()
    add(saved)
    for host in ("smartplant.local",):
        add(host)

    # Then scan the actual local IPv4 networks. Keep a conservative host cap
    # so a /16 school network does not turn the UI into a multi-minute scan.
    for net in local_subnets():
        hosts = list(net.hosts()) if net.num_addresses <= 1024 else []
        if not hosts:
            base = str(net.network_address).rsplit(".", 1)[0]
            hosts = [ipaddress.ip_address(f"{base}.{h}") for h in range(1, 255)]
        for host in hosts:
            add(str(host))

    return targets


def discover_board(progress=None, stop_event=None):
    """Fast concurrent LAN discovery. Returns a real ESP32 IP or ''.

    progress(checked, total, target, found) is called as probes finish.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FuturesTimeout

    targets = build_scan_targets()
    total = len(targets)
    checked = 0
    if progress:
        progress(0, total, "FAST UDP DISCOVERY // broadcasting on local WiFi...", "")
    try:
        found_udp = udp_discover(progress=progress)
    except Exception:
        found_udp = ""
    if found_udp and not (stop_event is not None and stop_event.is_set()):
        if progress:
            progress(1, max(1, total), "UDP controller response: %s" % found_udp, found_udp)
        return found_udp

    if progress:
        progress(0, total, "TCP FALLBACK // full LAN host probe...", "")

    with ThreadPoolExecutor(max_workers=128) as pool:
        futures = {pool.submit(probe_ip, ip): ip for ip in targets}
        try:
            for fut in as_completed(futures, timeout=14):
                if stop_event is not None and stop_event.is_set():
                    break
                try:
                    found = fut.result()
                except Exception:
                    found = None
                checked += 1
                target = futures.get(fut, "Checking LAN...")
                if progress:
                    progress(checked, total, target, found or "")
                if found:
                    for other in futures:
                        if other is not fut:
                            other.cancel()
                    return found
        except FuturesTimeout:
            pass
    return ""


def _set_scan_state(**changes):
    """Thread-safe update of the manual LAN-scan status shown in the UI."""
    with LOCK:
        scan = RUN.setdefault("scan", {})
        scan.update(changes)


def _manual_scan_worker():
    SCAN_STOP.clear()

    def progress(checked, total, target, found):
        _set_scan_state(checked=checked, total=total, target=target or "", found=found or "")

    try:
        found = discover_board(progress=progress, stop_event=SCAN_STOP)
        stopped = SCAN_STOP.is_set()
        if found and not stopped:
            with LOCK:
                CFG["board_url"] = found
                CFG["link_mode"] = "poll"
                RUN["board_error"] = ""
            save_config()
            add_event("Link", "Manual scan found the board at %s" % found)
            _set_scan_state(active=False, found=found, error="")
        elif stopped:
            _set_scan_state(active=False, found="", error="Scan stopped.")
        else:
            _set_scan_state(
                active=False,
                found="",
                error="No board answered. Same WiFi on both devices?",
            )
    except Exception as exc:
        _set_scan_state(active=False, found="", error=str(exc)[:240])
    finally:
        SCAN_STOP.clear()



def worker():
    last_prune = 0.0
    last_scan = 0.0
    while True:
        try:
            # The board is polled whenever we have an address and nothing has
            # pushed recently. That way a firmware built with ENABLE_PC_SERVER 0
            # still lights up the dashboard without touching any setting.
            if board_base() and (CFG["link_mode"] == "poll" or not connected()):
                data, err = board_get("/api/state", timeout=2)
                if looks_like_board(data):
                    accept_telemetry(data, source="poll")
                    with LOCK:
                        RUN["poll_fails"] = 0
                elif err:
                    with LOCK:
                        RUN["board_error"] = err
                        RUN["poll_fails"] += 1
                        was_up = connected()
                        # Two failed polls in a row (board unplugged, WiFi
                        # dropped, etc.) - go OFFLINE now instead of waiting
                        # out the connection_timeout window. One dropped
                        # packet is normal on WiFi and does not flip status.
                        if RUN["poll_fails"] >= 2:
                            RUN["last_seen"] = 0.0
                    if was_up and RUN["poll_fails"] >= 2:
                        add_event("Link", "Controller went offline: %s" % err)

            # Still nothing after 45s? Go and look for the board ourselves.
            if (CFG.get("auto_discover") and not connected()
                    and time.time() - last_scan > 20):
                last_scan = time.time()
                found = discover_board()
                if found:
                    with LOCK:
                        CFG["board_url"] = found
                        CFG["link_mode"] = "poll"
                        RUN["board_error"] = ""
                    save_config()
                    add_event("Link", "Board found on the network at %s" % found)
                else:
                    with LOCK:
                        RUN["board_error"] = ("No Smart Plant board answered on this network. "
                                              "Check that the PC and the ESP32 are on the same WiFi.")
                last_scan = time.time()

            now = time.time()
            s = snapshot()

            if s["connected"]:
                # 1. timed run finished
                with LOCK:
                    until = RUN["pump_until"]
                if until and now >= until:
                    set_pump(False)
                    queue_command("pump_off")
                    add_event("Control", "Timed run finished")

                # 2. safety: maximum runtime
                with LOCK:
                    started = RUN["pump_started"]
                    running = RUN["pump"]
                if running and started and now - started > CFG["max_runtime"]:
                    set_pump(False)
                    queue_command("pump_off")
                    add_event("Safety", "Max pump runtime reached")

                # 3. safety: tank too low
                if running and s["water"] is not None and s["water"] <= CFG["water_safety"]:
                    set_pump(False)
                    queue_command("pump_off")
                    add_event("Safety", "Water level too low")

                # 4. daily schedule
                if CFG["schedule_enabled"]:
                    today = datetime.now().strftime("%Y-%m-%d")
                    hhmm = datetime.now().strftime("%H:%M")
                    with LOCK:
                        done = RUN["last_schedule"] == today
                    if not done and hhmm == str(CFG["schedule_time"])[:5]:
                        with LOCK:
                            RUN["last_schedule"] = today
                        if s["water"] is not None and s["water"] > CFG["water_safety"]:
                            secs = min(int(CFG["schedule_seconds"]), int(CFG["max_runtime"]))
                            set_pump(True, secs)
                            if queue_command("pump_on", secs):
                                add_event("Schedule", "Scheduled run %ds" % secs)
                            else:
                                set_pump(False)
                                add_event("Schedule", "Pump command failed: %s" % (RUN.get("board_error") or "controller rejected"))
                        else:
                            add_event("Schedule", "Skipped: tank below safety level")

                # 5. auto irrigation
                with LOCK:
                    auto, running = RUN["auto_mode"], RUN["pump"]
                if auto and s["soil"] is not None:
                    if (not running
                            and s["soil"] <= CFG["soil_threshold"]
                            and s["water"] is not None and s["water"] > CFG["water_safety"]):
                        secs = min(int(CFG["max_runtime"]), 600)
                        set_pump(True, secs)
                        if queue_command("pump_on", secs):
                            add_event("Auto", "Pump on: soil %.1f%% below %.1f%%" % (s["soil"], CFG["soil_threshold"]))
                        else:
                            set_pump(False)
                            add_event("Auto", "Pump command failed: %s" % (RUN.get("board_error") or "controller rejected"))
                    elif running and s["soil"] >= CFG["moisture_target"]:
                        set_pump(False)
                        if queue_command("pump_off"):
                            add_event("Auto", "Pump off: target %.1f%% reached" % CFG["moisture_target"])
                        else:
                            add_event("Auto", "Pump-off command failed: %s" % (RUN.get("board_error") or "controller rejected"))

            # 6. prune old history once an hour
            if now - last_prune > 3600:
                last_prune = now
                cutoff = (datetime.now() - timedelta(days=int(CFG["retention_days"]))).strftime("%Y-%m-%d %H:%M:%S")
                c = db()
                c.execute("DELETE FROM sensor_history WHERE timestamp < ?", (cutoff,))
                c.execute("DELETE FROM events WHERE timestamp < ?", (cutoff,))
                c.commit()
                c.close()
        except Exception as e:                                  # keep the loop alive
            try:
                add_event("Server", "Worker error: %s" % str(e)[:160])
            except Exception:
                pass
        time.sleep(1)


# --------------------------------------------------------------------------
# AI helpers
# --------------------------------------------------------------------------
AI_SECRET_PATH = DATA_DIR / "groq_api_key.bin"
MANUS_SECRET_PATH = DATA_DIR / "manus_api_key.bin"

def _dpapi_protect(raw: bytes) -> bytes:
    if os.name != "nt" or not raw:
        return raw
    import ctypes
    from ctypes import wintypes
    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    inp = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    in_blob = BLOB(len(raw), ctypes.cast(inp, ctypes.POINTER(ctypes.c_ubyte)))
    out_blob = BLOB()
    if not crypt.CryptProtectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)):
        raise OSError("Windows DPAPI encryption failed")
    try:
        return bytes((ctypes.c_ubyte * out_blob.cbData).from_address(ctypes.addressof(out_blob.pbData.contents)))
    finally:
        kernel.LocalFree(out_blob.pbData)


def _dpapi_unprotect(raw: bytes) -> bytes:
    if os.name != "nt" or not raw:
        return raw
    import ctypes
    from ctypes import wintypes
    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]
    crypt = ctypes.windll.crypt32
    kernel = ctypes.windll.kernel32
    inp = (ctypes.c_ubyte * len(raw)).from_buffer_copy(raw)
    in_blob = BLOB(len(raw), ctypes.cast(inp, ctypes.POINTER(ctypes.c_ubyte)))
    out_blob = BLOB()
    if not crypt.CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)):
        raise OSError("Windows DPAPI decryption failed")
    try:
        return bytes((ctypes.c_ubyte * out_blob.cbData).from_address(ctypes.addressof(out_blob.pbData.contents)))
    finally:
        kernel.LocalFree(out_blob.pbData)


def _load_saved_groq_key():
    try:
        if not AI_SECRET_PATH.exists():
            return ""
        blob = AI_SECRET_PATH.read_bytes()
        if not blob:
            return ""
        return _dpapi_unprotect(blob).decode("utf-8").strip()
    except Exception:
        return ""


def _save_groq_key(value: str):
    value = str(value or "").strip()
    if not value:
        try:
            AI_SECRET_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        os.environ.pop("GROQ_API_KEY", None)
        return False
    protected = _dpapi_protect(value.encode("utf-8"))
    tmp = AI_SECRET_PATH.with_suffix(".tmp")
    tmp.write_bytes(protected)
    try:
        tmp.replace(AI_SECRET_PATH)
    except Exception:
        AI_SECRET_PATH.write_bytes(protected)
        try: tmp.unlink()
        except Exception: pass
    try:
        if os.name != "nt":
            AI_SECRET_PATH.chmod(0o600)
    except Exception:
        pass
    os.environ["GROQ_API_KEY"] = value
    return True
def _load_saved_manus_key():
    try:
        if not MANUS_SECRET_PATH.exists(): return ""
        return _dpapi_unprotect(MANUS_SECRET_PATH.read_bytes()).decode("utf-8").strip()
    except Exception:
        return ""
def _save_manus_key(value: str):
    value = str(value or "").strip()
    if not value:
        try: MANUS_SECRET_PATH.unlink(missing_ok=True)
        except Exception: pass
        os.environ.pop("MANUS_API_KEY", None)
        return False
    protected = _dpapi_protect(value.encode("utf-8"))
    tmp = MANUS_SECRET_PATH.with_suffix(".tmp")
    tmp.write_bytes(protected)
    try: tmp.replace(MANUS_SECRET_PATH)
    except Exception:
        MANUS_SECRET_PATH.write_bytes(protected)
        try: tmp.unlink()
        except Exception: pass
    try:
        if os.name != "nt": MANUS_SECRET_PATH.chmod(0o600)
    except Exception: pass
    os.environ["MANUS_API_KEY"] = value
    return True


def _secret(_name, env_name):
    # Settings-saved Groq key wins over the optional environment variable.
    if env_name == "GROQ_API_KEY":
        saved = _load_saved_groq_key()
        if saved:
            return saved
    return str(os.environ.get(env_name, "")).strip()


def ai_key_source():
    if _load_saved_groq_key():
        return "Smart Plant Settings (Windows user-protected storage)"
    if str(os.environ.get("GROQ_API_KEY", "")).strip():
        return "PC environment variable (GROQ_API_KEY)"
    return "not configured"


def ai_key():
    return _secret("groq_api_key", "GROQ_API_KEY")
def manus_key():
    return _load_saved_manus_key() or str(os.environ.get("MANUS_API_KEY", "")).strip()
def ai_provider():
    return "manus" if manus_key() else ("groq" if ai_key() else "none")


def weather_key():
    return _secret("openweather_api_key", "OPENWEATHER_API_KEY")


def ai_model():
    return "manus-1.6-lite" if manus_key() else "openai/gpt-oss-20b"


def extract_groq_text(payload):
    """Extract user-facing text from Groq Chat Completions or Responses."""
    if not isinstance(payload, dict):
        return ""
    direct = payload.get("output_text")
    if isinstance(direct, str) and direct.strip():
        return direct.strip()

    choices = payload.get("choices")
    if isinstance(choices, list) and choices:
        first = choices[0] if isinstance(choices[0], dict) else {}
        message = first.get("message") if isinstance(first.get("message"), dict) else {}
        for value in (message.get("content"), first.get("text")):
            if isinstance(value, str) and value.strip():
                return value.strip()
            if isinstance(value, list):
                parts=[]
                for part in value:
                    if not isinstance(part, dict):
                        continue
                    candidate = part.get("text") or part.get("content")
                    if isinstance(candidate, str) and candidate.strip():
                        # Never expose reasoning-only blocks.
                        ptype=str(part.get("type") or "")
                        if ptype in ("reasoning", "reasoning_text"):
                            continue
                        parts.append(candidate.strip())
                if parts:
                    return "\n".join(parts).strip()

    output = payload.get("output")
    parts=[]
    if isinstance(output, list):
        for item in output:
            if not isinstance(item, dict) or item.get("type") != "message":
                continue
            content=item.get("content")
            if isinstance(content, str) and content.strip():
                parts.append(content.strip())
            elif isinstance(content, list):
                for part in content:
                    if not isinstance(part, dict):
                        continue
                    if str(part.get("type") or "") != "output_text":
                        continue
                    value=part.get("text")
                    if isinstance(value, str) and value.strip():
                        parts.append(value.strip())
    return "\n".join(parts).strip()


def _parse_ai_envelope(raw_text):
    """Parse the AI control envelope; fall back to plain text without actions."""
    text=str(raw_text or "").strip()
    if not text:
        return {"reply":"", "action":None}
    candidate=re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
    candidate=re.sub(r"\s*```$", "", candidate).strip()
    obj=None
    try:
        obj=json.loads(candidate)
    except (TypeError,ValueError):
        m=re.search(r"\{.*\}", candidate, flags=re.S)
        if m:
            try: obj=json.loads(m.group(0))
            except (TypeError,ValueError): obj=None
    if not isinstance(obj,dict):
        return {"reply":text[:12000], "action":None}
    reply=str(obj.get("reply") or obj.get("message") or text).strip()[:12000]
    action=obj.get("action")
    if not isinstance(action,dict):
        return {"reply":reply, "action":None}
    name=str(action.get("name") or "").strip().lower()
    if name not in {"pump_on","pump_off","auto_on","auto_off"}:
        return {"reply":reply, "action":None}
    clean={"name":name}
    if name=="pump_on":
        try: sec=int(float(action.get("seconds",30)))
        except (TypeError,ValueError): sec=30
        clean["seconds"]=max(1,min(600,sec))
    return {"reply":reply, "action":clean}


def _ai_diagnostics(s):
    issues=[]
    for item in build_alerts(s):
        issues.append({"level":item["level"],"title":item["title"],"details":item["details"]})
    if s.get("connected"):
        missing=[k for k in ("soil","temperature","humidity","water","gas","water_temp") if s.get(k) is None]
        if missing:
            issues.append({"level":"info","title":"Sensor channels unavailable","details":"No valid reading: "+", ".join(missing)})
    return issues


def _explicit_control_fallback(text):
    """Recognize only clear imperative Smart Plant control phrases.

    This is a safety-oriented fallback for cases where the language model
    replies in prose instead of returning the small JSON action envelope.
    Informational/conditional questions are deliberately excluded.
    """
    raw = re.sub(r"\s+", " ", str(text or "").strip().lower())
    if not raw:
        return None
    # Reject question/conditional forms so advice cannot become a command.
    if "?" in raw or re.match(r"^(what|why|when|can|could|should|is|are|will|would|if)\b", raw):
        return None
    # Romanised-Sinhala / Sinhala questions ("... karanna puluwan da", "...ද") are not commands.
    if re.search(r"(\bda|\bdha|\bdo|ද|ෙද)\s*$", raw) or re.search(r"\b(puluwan|puluwanda|kohomada|mokakda)\b", raw):
        return None
    P = r"(?:pump|pompaya|pompe|motor|moter)"
    E = r"\s*(?:eka|ek|ekak)?\s*"
    DO = r"(?:\s+(?:karanna|karan|kara|karapan|karamu))?"
    groups = {
        "pump_off": [
            r"\bpump\s+(off|stop|turn off|switch off|shut off)\b",
            r"\bturn\s+the\s+pump\s+off\b",
            r"පොම්පය\s*(නවත්තන්න|නිවන්න|වහන්න)",
            r"පොම්පය\s*ඔෆ්\s*කරන්න",
            r"\b" + P + E + r"(?:off|stop)\b" + DO,
            r"\b" + P + E + r"(?:nawattanna|nawaththanna|nawatha|nivanna|nivan|wahanna)\b",
            r"\b(?:watura|wathura)\s+(?:nawattanna|nawaththanna|nivanna)\b",
        ],
        "pump_on": [
            r"\bpump\s+(on|start|turn on|switch on)\b",
            r"\bturn\s+the\s+pump\s+on\b",
            r"පොම්පය\s*(දාන්න|අරින්න|ඔන්\s*කරන්න|ක්‍රියාත්මක\s*කරන්න)",
            r"\b" + P + E + r"(?:on|start)\b" + DO,
            r"\b" + P + E + r"(?:dhanna|danna|dapan|arinna|aranna)\b",
            r"\b(?:watura|wathura)\s+(?:dhanna|danna|denna|dapan)\b",
        ],
        "auto_off": [
            r"\b(auto|automatic irrigation)\s+(off|stop|disable|turn off)\b",
            r"ස්වයංක්‍රීය\s*(ජලසම්පාදනය|වතුර)\s*(නවත්තන්න|නිවන්න|අක්‍රිය\s*කරන්න)",
            r"\bauto(?:matic)?(?:\s+mode)?" + E + r"(?:off|disable|nawattanna|nawaththanna|nivanna)\b" + DO,
        ],
        "auto_on": [
            r"\b(auto|automatic irrigation)\s+(on|start|enable|turn on)\b",
            r"ස්වයංක්‍රීය\s*(ජලසම්පාදනය|වතුර)\s*(දාන්න|ඔන්\s*කරන්න|සක්‍රිය\s*කරන්න)",
            r"\bauto(?:matic)?(?:\s+mode)?" + E + r"(?:on|enable|start|dhanna|danna)\b" + DO,
        ],
    }
    for name, pats in groups.items():
        if any(re.search(p, raw, flags=re.I) for p in pats):
            action={"name": name}
            if name=="pump_on":
                m=re.search(r"(\d{1,4})\s*(?:seconds?|secs?|s|thath?para|tath?para|තත්පර\S*)(?=\W|$)",raw,re.I)
                if not m:
                    m=re.search(r"(?:thath?para|tath?para|තත්පර\S*)\s*(\d{1,4})",raw,re.I)
                action["seconds"]=int(m.group(1)) if m else 30
            return action
    return None


def _execute_ai_action(action):
    """Execute only explicit validated AI plant-control actions."""
    if not isinstance(action,dict):
        return {"executed":False,"reason":"no_action"}
    if not bool(CFG.get("ai_control_enabled",True)):
        return {"executed":False,"reason":"AI plant control is disabled in Settings."}
    name=str(action.get("name") or "").lower()
    if name not in ("pump_on","pump_off","auto_on","auto_off"):
        return {"executed":False,"reason":"Action is not allowed."}
    if not connected():
        return {"executed":False,"reason":"Controller is offline."}
    seconds=None
    if name=="pump_on":
        snap=snapshot(); water=snap.get("water")
        if water is None:
            return {"executed":False,"reason":"Water-level sensor is unavailable; pump start is blocked."}
        if water<=CFG["water_safety"]:
            return {"executed":False,"reason":"Water level is at/below the safety minimum."}
        try: seconds=int(action.get("seconds",30))
        except (TypeError,ValueError): seconds=30
        seconds=int(clamp(seconds,1,min(600,int(CFG["max_runtime"]))))
    old_pump=RUN["pump"]; old_auto=RUN["auto_mode"]
    if name=="pump_on": set_pump(True,seconds)
    elif name=="pump_off": set_pump(False)
    elif name=="auto_on":
        with LOCK: RUN["auto_mode"]=True
    elif name=="auto_off":
        with LOCK: RUN["auto_mode"]=False
        if RUN["pump"]: set_pump(False)
    if not queue_command(name,seconds):
        with LOCK:
            RUN["pump"]=old_pump; RUN["auto_mode"]=old_auto
            if name!="pump_off": RUN["pump_until"]=None
            RUN["board_error"]=RUN["board_error"] or "Controller rejected the AI command."
        return {"executed":False,"reason":RUN["board_error"]}
    add_event("AI Control",name+(" %ds"%seconds if seconds else ""))
    return {"executed":True,"action":name,"seconds":seconds,"pump":bool(RUN["pump"]),"auto_mode":bool(RUN["auto_mode"])}



def _groq_chat_sdk(messages, max_completion_tokens=1024, temperature=0.6):
    """Primary Groq chat path using the official Groq Python SDK.

    GPT-OSS supports reasoning_effort plus include_reasoning=False.  Keeping
    reasoning disabled here avoids depending on a reasoning-only field when
    the UI only needs the final assistant answer.
    """
    if Groq is None:
        raise RuntimeError("Groq Python SDK is not installed on the Smart Plant PC hub.")
    key = ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    client = Groq(api_key=key, timeout=25.0, max_retries=0)
    completion = client.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=messages,
        max_completion_tokens=max(256, int(max_completion_tokens)),
        temperature=float(temperature),
        top_p=0.95,
        reasoning_effort="low",
        include_reasoning=False,
        stream=False,
    )
    if not getattr(completion, "choices", None):
        raise RuntimeError("Groq returned no completion choices.")
    msg = getattr(completion.choices[0], "message", None)
    content = getattr(msg, "content", None) if msg is not None else None
    if isinstance(content, list):
        pieces=[]
        for part in content:
            if isinstance(part, dict):
                value=part.get("text") or part.get("content")
                if isinstance(value, str) and value.strip():
                    pieces.append(value.strip())
        content="\n".join(pieces)
    text_value=str(content or "").strip()
    if not text_value:
        raise RuntimeError("Groq chat completed but returned no final text.")
    return {"choices":[{"message":{"role":"assistant","content":text_value}}],"model":getattr(completion,"model","openai/gpt-oss-20b")}


def _groq_chat_http(messages, max_completion_tokens=700, temperature=0.6):
    """Direct HTTP fallback using the documented Groq Chat Completions shape."""
    key = ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    payload = {
        "model": "openai/gpt-oss-20b",
        "messages": messages,
        "max_completion_tokens": max(256, int(max_completion_tokens)),
        "stream": False,
        "temperature": float(temperature),
        "top_p": 0.95,
        "reasoning_effort": "low",
        "include_reasoning": False,
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + key,
            "Accept": "application/json",
            "User-Agent": "SmartPlantIrrigationSystem/42.18.16",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        try:
            obj = json.loads(detail) if detail else None
            if isinstance(obj, dict) and isinstance(obj.get("error"), dict):
                er = obj["error"]
                msg = str(er.get("message") or detail)
                et = str(er.get("type") or "")
                ec = str(er.get("code") or "")
                suffix = " [" + "; ".join(x for x in (et, ec) if x) + "]" if (et or ec) else ""
                detail = msg + suffix
        except Exception:
            pass
        raise RuntimeError("Groq HTTP %s: %s" % (exc.code, detail[:700]))
    except urllib.error.URLError as exc:
        raise RuntimeError("Groq network error: %s" % str(exc.reason or exc))

def _groq_chat_http_minimal(messages, max_completion_tokens=2048):
    key=ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    payload={
        "model":"openai/gpt-oss-20b",
        "messages":messages,
        "max_completion_tokens":max(256, int(max_completion_tokens)),
        "stream":False,
        "temperature":0.6,
        "top_p":0.95,
        "reasoning_effort":"low",
        "include_reasoning":False,
    }
    body=json.dumps(payload,ensure_ascii=False).encode("utf-8")
    req=urllib.request.Request(
        "https://api.groq.com/openai/v1/chat/completions", data=body, method="POST",
        headers={"Content-Type":"application/json","Authorization":"Bearer "+key,"Accept":"application/json","User-Agent":"SmartPlantIrrigationSystem/42.18.16"},
    )
    try:
        with urllib.request.urlopen(req,timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8",errors="replace"))
    except urllib.error.HTTPError as exc:
        detail=""
        try: detail=exc.read().decode("utf-8",errors="replace")
        except Exception: pass
        try:
            obj=json.loads(detail) if detail else None
            if isinstance(obj,dict) and isinstance(obj.get("error"),dict):
                detail=str(obj["error"].get("message") or detail)
        except Exception: pass
        raise RuntimeError("Groq HTTP %s: %s"%(exc.code,detail[:700]))
    except urllib.error.URLError as exc:
        raise RuntimeError("Groq network error: %s"%str(exc.reason or exc))


def _groq_responses_http(messages):
    """Primary direct Groq Responses API call using the current documented shape."""
    key = ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    payload = {
        "model": "openai/gpt-oss-20b",
        "input": [
            {
                "role": str(item.get("role") or "user"),
                "content": str(item.get("content") or "").strip(),
            }
            for item in (messages or [])
            if isinstance(item, dict) and str(item.get("content") or "").strip()
        ],
        "reasoning": {"effort": "low"},
    }
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/responses",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + key,
            "Accept": "application/json",
            "User-Agent": "SmartPlantIrrigationSystem/42.18.16",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=18) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        try:
            obj = json.loads(detail) if detail else None
            if isinstance(obj, dict) and isinstance(obj.get("error"), dict):
                detail = str(obj["error"].get("message") or detail)
        except Exception:
            pass
        raise RuntimeError("Groq Responses HTTP %s: %s" % (exc.code, detail[:900]))
    except urllib.error.URLError as exc:
        raise RuntimeError("Groq Responses network error: %s" % str(exc.reason or exc))


MANUS_API_BASE = "https://api.manus.ai"
MANUS_RESULT_SCHEMA = {
    "type": "object",
    "properties": {
        "reply": {"type": "string"},
        "action": {"type": ["string", "null"], "enum": ["pump_on", "pump_off", "auto_on", "auto_off", None]},
        "seconds": {"type": ["integer", "null"]},
    },
    "required": ["reply", "action", "seconds"],
    "additionalProperties": False,
}
def _manus_request(path, payload=None, query=None):
    key = manus_key()
    if not key: raise RuntimeError("Manus API key is not configured on the Smart Plant PC hub.")
    url = MANUS_API_BASE + path
    if query:
        url += "?" + urllib.parse.urlencode(query)
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST" if payload is not None else "GET", headers={
        "x-manus-api-key": key, "Accept": "application/json", "Content-Type": "application/json",
        "User-Agent": "SmartPlantIrrigationSystem/" + APP_VERSION,
    })
    with urllib.request.urlopen(req, timeout=18) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    if not isinstance(data, dict) or data.get("ok") is False:
        raise RuntimeError("Manus API returned an unsuccessful response.")
    return data
def _manus_reply_http(prompt, language, telemetry, history):
    lang = {"si": "Sinhala", "ja": "Japanese"}.get(str(language or "en").lower(), "English")
    context = "You are the SmartPlant assistant. Answer only plant, irrigation, sensor, pump, or app questions. "
    context += "Reply in " + lang + ". Use the live JSON below and never invent values. "
    context += "Return a concise reply. A control action is allowed only when the user explicitly requests it.\n"
    context += "LIVE JSON:\n" + json.dumps(telemetry, ensure_ascii=False, separators=(",", ":"))
    if isinstance(history, list):
        context += "\nRECENT CHAT:\n" + json.dumps(history[-6:], ensure_ascii=False, separators=(",", ":"))
    context += "\nUSER:\n" + str(prompt)[:4000]
    created = _manus_request("/v2/task.create", {
        "message": {"content": context}, "interactive_mode": False, "hide_in_task_list": True,
        "share_visibility": "private", "agent_profile": "manus-1.6-lite",
        "structured_output_schema": MANUS_RESULT_SCHEMA,
    })
    task_id = str(created.get("task_id") or "")
    if not task_id: raise RuntimeError("Manus did not return a task id.")
    deadline = time.monotonic() + 28
    while time.monotonic() < deadline:
        result = _manus_request("/v2/task.listMessages", query={"task_id": task_id, "order": "desc", "limit": 50})
        for event in result.get("messages", []) if isinstance(result.get("messages"), list) else []:
            if not isinstance(event, dict) or event.get("type") != "structured_output_result": continue
            extracted = event.get("structured_output_result") or {}
            if extracted.get("success") and isinstance(extracted.get("value"), dict):
                value = extracted["value"]
                action = value.get("action")
                if action not in ("pump_on", "pump_off", "auto_on", "auto_off", None): action = None
                return {"reply": str(value.get("reply") or "").strip()[:12000], "action": action, "seconds": value.get("seconds")}
        time.sleep(2)
    raise RuntimeError("Manus response timed out before structured output was ready.")
def ai_reply(message, language=None, history=None, platform="pc"):
    """Return a SmartPlant reply from Manus when configured, otherwise Groq."""
    key = ai_key()
    manus = manus_key()
    if not key and not manus:
        return None, "NO AI API KEY. Configure MANUS_API_KEY or the Groq key on the Smart Plant PC hub."
    prompt = str(message or "").strip()[:4000]
    if not prompt:
        return None, "Please enter or speak a message."

    telemetry = snapshot()
    lang = str(language or "en").lower().strip()
    language_name = {"si": "Sinhala", "ja": "Japanese"}.get(lang, "English")
    developer_name = "Geenuka" if str(platform or "pc").lower().strip() == "android" else "Tharusha"

    system_prompt = (
        "You are SmartPlant Plant AI, the voice and text assistant for the real Smart Plant Irrigation System. "
        "Answer ONLY Smart Plant topics: plants, irrigation, soil, sensors, water tank, pump, automation, device status, alerts, setup, or this app. "
        "For unrelated topics, politely say you only handle Smart Plant topics. "
        "Answer in the user's requested language. English is the default. "
        "If asked who developed or created this app, say this version was developed by " + developer_name + ". "
        "Use ONLY the supplied live controller data and diagnostic report. Never invent sensor values, hardware states, weather, or control results. "
        "Be concise and conversational because this answer may be spoken aloud. "
        "Return only the natural-language answer. Do not return JSON, code fences, or an action object. "
        "The application handles plant-control commands separately. "
        "User language: " + language_name + "."
        "\n\nLIVE CONTROLLER DATA (JSON):\n" + json.dumps(telemetry, ensure_ascii=False, separators=(",", ":")) +
        "\n\nDIAGNOSTIC REPORT (JSON):\n" + json.dumps(_ai_diagnostics(telemetry), ensure_ascii=False, separators=(",", ":"))
    )

    messages = [{"role": "system", "content": system_prompt}]
    if isinstance(history, list):
        hist = []
        for item in history[-10:]:
            if not isinstance(item, dict):
                continue
            role = "assistant" if item.get("role") == "assistant" else "user"
            h = str(item.get("text") or "").strip()[:1200]
            if not h:
                continue
            hist.append({"role": role, "content": h})
        # The frontend keeps the current user message in history for rendering.
        # Do not send that same message twice to Groq.
        if hist and hist[-1].get("role") == "user" and hist[-1].get("content") == prompt:
            hist = hist[:-1]
        messages.extend(hist[-10:])
    messages.append({"role": "user", "content": prompt})

    if manus:
        try:
            envelope = _manus_reply_http(prompt, lang, telemetry, history)
            if envelope.get("reply"):
                return envelope, ""
        except Exception as exc:
            if not key:
                return None, "Manus AI error: " + str(exc).replace("\n", " ")[:900]
    errors = []
    transports = [
        ("responses", lambda: _groq_responses_http(messages)),
        ("chat", lambda: _groq_chat_http_minimal(messages, max_completion_tokens=2048)),
        ("sdk", lambda: _groq_chat_sdk(messages, max_completion_tokens=2048, temperature=0.6)),
    ]
    for label, call in transports:
        try:
            payload = call()
            raw = extract_groq_text(payload).strip()
            if raw:
                envelope = _parse_ai_envelope(raw)
                if envelope.get("reply"):
                    return envelope, ""
            errors.append(label + ": empty final text")
        except Exception as exc:
            errors.append(label + ": " + str(exc).replace("\n", " ")[:500])

    return None, "Groq AI error: " + " | ".join(errors)[:1500]


# --------------------------------------------------------------------------
# http
# --------------------------------------------------------------------------
@app.before_request
def reject_untrusted_api_origins():
    """Block cross-site browser calls while allowing the bundled Android UI."""
    if request.path.startswith("/api/"):
        origin = (request.headers.get("Origin") or "").rstrip("/")
        allowed = {
            "https://appassets.androidplatform.net",
            "http://127.0.0.1:%d" % PORT,
            "http://localhost:%d" % PORT,
        }
        if origin and origin not in allowed:
            return jsonify({"ok": False, "error": "Untrusted request origin."}), 403
    return None
@app.after_request
def headers(resp):
    origin = (request.headers.get("Origin") or "").rstrip("/")
    if origin == "https://appassets.androidplatform.net":
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Vary"] = "Origin"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Board-Token, X-SmartPlant-Client"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "SAMEORIGIN"
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["Permissions-Policy"] = "camera=(self), microphone=(self), geolocation=()"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def preflight(_any):
    return ("", 204)


@app.get("/")
@app.get("/dashboard")
@app.route("/login", methods=["GET", "POST"])       # old bookmarks land here
def index():
    resp = make_response(render_template("dashboard.html"))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/api/state")
def api_state():
    s = snapshot()
    s["alerts"] = build_alerts(s)
    c = db()
    row = c.execute("SELECT COUNT(*) n FROM events WHERE event IN ('Control','Auto','Schedule')").fetchone()
    c.close()
    s["control_events"] = row["n"] if row else 0
    s["config_revision"] = CONFIG_REVISION
    s["ok"] = True
    return jsonify(s)


@app.post("/api/control")
def api_control():
    if not connected():
        return jsonify({"ok": False, "error": "Controller is offline. Controls unlock when the controller answers."}), 409
    d = request.get_json(silent=True) or {}
    action = d.get("action")
    if action not in ("pump_on", "pump_off", "auto_on", "auto_off"):
        return jsonify({"ok": False, "error": "Unknown action."}), 400

    with LOCK:
        old_pump = RUN["pump"]
        old_auto = RUN["auto_mode"]
    seconds = None

    if action == "pump_on":
        water = snapshot().get("water")
        if water is None:
            return jsonify({"ok": False, "error": "Water-level sensor is not reporting a valid reading."}), 409
        if water <= CFG["water_safety"]:
            return jsonify({"ok": False, "error": "Water tank is too low to run the pump."}), 400
        try:
            seconds = int(d.get("seconds")) if d.get("seconds") else None
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": "Pump seconds must be a number."}), 400
        if seconds is not None:
            seconds = int(clamp(seconds, 1, CFG["max_runtime"]))
        set_pump(True, seconds)
    elif action == "pump_off":
        set_pump(False)
    elif action == "auto_on":
        with LOCK:
            RUN["auto_mode"] = True
    else:  # auto_off
        with LOCK:
            RUN["auto_mode"] = False
            pump_was_running = bool(RUN["pump"])
        if pump_was_running:
            set_pump(False)

    ok = queue_command(action, seconds)
    if not ok:
        with LOCK:
            RUN["pump"] = old_pump
            RUN["auto_mode"] = old_auto
            if action != "pump_off":
                RUN["pump_until"] = None
            RUN["board_error"] = RUN["board_error"] or "Controller rejected the command."
        return jsonify({"ok": False, "error": RUN["board_error"]}), 502

    add_event("Control", action + (" %ds" % seconds if seconds else ""))
    with LOCK:
        result = {"ok": True, "pump": bool(RUN["pump"]), "auto_mode": bool(RUN["auto_mode"])}
    return jsonify(result)


@app.get("/api/command")
def api_command():
    # Tokens in query strings can leak through browser history and server logs.
    token = request.headers.get("X-Board-Token")
    if token != CFG["board_token"]:
        return jsonify({"ok": False, "error": "Invalid board token"}), 401
    with LOCK:
        cmd = RUN["queue"].pop(0) if RUN["queue"] else None
        return jsonify({"ok": True, "command": cmd,
                        "pump": RUN["pump"], "auto_mode": RUN["auto_mode"]})


@app.post("/api/telemetry")
def api_telemetry():
    # Tokens in query strings can leak through browser history and server logs.
    token = request.headers.get("X-Board-Token")
    if token != CFG["board_token"]:
        return jsonify({"ok": False, "error": "Invalid board token"}), 401
    ok, err = accept_telemetry(request.get_json(silent=True) or {}, source="push")
    if not ok:
        return jsonify({"ok": False, "error": err}), 400
    with LOCK:
        return jsonify({"ok": True, "accepted_at": stamp(),
                        "pump": RUN["pump"], "auto_mode": RUN["auto_mode"],
                        "command": RUN["queue"].pop(0) if RUN["queue"] else None})


@app.get("/api/settings")
def api_get_settings():
    with LOCK:
        out = {k: CFG[k] for k in CFG if k != "board_token"}
        out["io"] = dict(CFG["io"])
        out["token_set"] = CFG["board_token"] != DEFAULTS["board_token"]
        out["groq_key_set"] = bool(ai_key())
        out["groq_key_source"] = ai_key_source()
        out["weather_key_set"] = bool(weather_key())
        out["ai_control_enabled"] = bool(CFG.get("ai_control_enabled", True))
    out.update({"ok": True, "config_revision": CONFIG_REVISION,
                "telemetry_endpoint": "/api/telemetry", "command_endpoint": "/api/command"})
    return jsonify(out)


NUMERIC = {
    "soil_threshold": (0, 100, float), "moisture_target": (0, 100, float),
    "water_safety": (0, 100, float), "max_runtime": (1, 3600, int),
    "connection_timeout": (3, 300, int),
    "schedule_seconds": (1, 3600, int), "temp_min": (-20, 80, float),
    "temp_max": (-20, 80, float), "hum_min": (0, 100, float), "hum_max": (0, 100, float),
    "gas_alert": (0, 100, float), "retention_days": (1, 365, int),
}


@app.post("/api/settings")
def api_set_settings():
    d = request.get_json(silent=True) or {}
    new = {}
    try:
        for key, (lo, hi, cast) in NUMERIC.items():
            if d.get(key) is not None:
                new[key] = cast(clamp(d[key], lo, hi))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Settings must be numbers."}), 400

    merged = dict(CFG)
    merged.update(new)
    if merged["moisture_target"] < merged["soil_threshold"]:
        return jsonify({"ok": False, "error": "Stop level must be the same or higher than the start level."}), 400
    for a, b, label in (("temp_min", "temp_max", "Temperature"),
                        ("hum_min", "hum_max", "Humidity")):
        if merged[a] > merged[b]:
            return jsonify({"ok": False, "error": "%s minimum cannot be above its maximum." % label}), 400

    with LOCK:
        CFG.update(new)
        if d.get("board_name") is not None:
            CFG["board_name"] = str(d["board_name"])[:64] or DEFAULTS["board_name"]
        if d.get("board_type") is not None:
            CFG["board_type"] = str(d["board_type"])[:64]
        if d.get("link_mode") in ("push", "poll"):
            CFG["link_mode"] = d["link_mode"]
        if d.get("board_url") is not None:
            CFG["board_url"] = str(d["board_url"]).strip()[:120]
        if d.get("schedule_time"):
            t = str(d["schedule_time"])[:5]
            if len(t) == 5 and t[2] == ":" and t[:2].isdigit() and t[3:].isdigit():
                CFG["schedule_time"] = t
        if "schedule_enabled" in d:
            CFG["schedule_enabled"] = bool(d["schedule_enabled"])
        if d.get("board_token"):
            CFG["board_token"] = str(d["board_token"]).strip()[:128]
        if isinstance(d.get("io"), dict):
            for k in DEFAULTS["io"]:
                if d["io"].get(k) is not None:
                    CFG["io"][k] = str(d["io"][k]).strip()[:24]
        if "ai_enabled" in d:
            CFG["ai_enabled"] = bool(d["ai_enabled"])
        CFG["ai_model"] = "openai/gpt-oss-20b"
        if d.get("weather_location") is not None:
            CFG["weather_location"] = str(d["weather_location"]).strip()[:120]
    save_config()
    add_event("Settings", "Updated: " + ", ".join(sorted(set(d.keys()) - {"board_token"}))[:200])
    return jsonify({"ok": True})


@app.get("/api/health")
def api_health():
    return jsonify({"ok": True, "server": "online", "port": PORT, "ip": lan_ip(), "ai_ready": bool(ai_key())})



@app.get("/api/local-voice/status")
def api_local_voice_status():
    try:
        return jsonify(local_voice.status())
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:800], "api_key_required": False}), 500

@app.get("/api/update/check")
def api_update_check():
    return jsonify(check_for_update())

@app.post("/api/update/install")
def api_update_install():
    result = install_update_windows()
    return jsonify(result), (200 if result.get("ok") else 400)

@app.get("/api/local-voice/memory")
def api_local_voice_memory():
    return jsonify({"ok": True, "facts": memory_facts(), "recent": memory_recent_turns(20)})

@app.post("/api/local-voice/memory/clear")
def api_local_voice_memory_clear():
    memory_clear()
    return jsonify({"ok": True})

@app.post("/api/local-voice/chat")
def api_local_voice_chat():
    d = request.get_json(silent=True) or {}
    message = str(d.get("message") or "").strip()
    if not message:
        return jsonify({"ok": False, "error": "No message supplied."}), 400
    try:
        language = str(d.get("language") or "en").lower().strip()
        reply, info, backend = _local_ai_reply(message, language, d.get("history") or [])
        reply, action, action_result = _local_apply_control(message, reply)
        return jsonify({"ok": True, "reply": reply[:12000], "language": info.get("language"), "dialect": info.get("dialect"), "model": backend, "action": action, "action_result": action_result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc).replace("\n", " ")[:1200]}), 502

@app.post("/api/local-voice/turn")
def api_local_voice_turn():
    if "file" not in request.files:
        return jsonify({"ok": False, "error": "Upload an audio file in the 'file' field."}), 400
    f = request.files["file"]
    suffix = os.path.splitext(f.filename or "")[1].lower()
    if suffix not in (".wav", ".webm", ".mp3", ".m4a", ".ogg", ".flac"):
        suffix = ".wav"
    tmp = tempfile.NamedTemporaryFile(prefix="smartplant_local_upload_", suffix=suffix, delete=False)
    tmp.close()
    try:
        f.save(tmp.name)
        language = str(request.form.get("language") or "en").strip().lower()
        try:
            history = json.loads(request.form.get("history") or "[]")
        except ValueError:
            history = []
        try:
            spoken = local_voice.transcribe_audio(tmp.name, language=language)
        except Exception as exc:
            msg = str(exc).replace("\n", " ")[:900]
            return jsonify({"ok": False, "error": msg}), (422 if "No speech" in msg or "empty" in msg else 502)
        reply, info, backend = _local_ai_reply(spoken, language, history if isinstance(history, list) else [])
        reply, action, action_result = _local_apply_control(spoken, reply)
        return jsonify({"ok": True, "transcript": spoken, "reply": reply[:12000], "language": info.get("language"), "dialect": info.get("dialect"), "model": backend, "action": action, "action_result": action_result})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc).replace("\n", " ")[:1200]}), 502
    finally:
        try: os.unlink(tmp.name)
        except OSError: pass

@app.get("/api/ai/status")
def api_ai_status():
    return jsonify({"ok": True, "enabled": bool(CFG.get("ai_enabled")), "ai_control_enabled": bool(CFG.get("ai_control_enabled", True)), "model": ai_model(), "provider": ai_provider(),
                    "groq_key_set": bool(ai_key()), "groq_key_source": ai_key_source(),
                    "manus_key_set": bool(manus_key()),
                    "weather_key_set": bool(weather_key())})


@app.post("/api/ai/settings")
def api_ai_settings():
    d = request.get_json(silent=True) or {}
    key_update = "groq_api_key" in d
    key_value = str(d.get("groq_api_key") or "").strip() if key_update else None
    if key_update and key_value and len(key_value) < 12:
        return jsonify({"ok": False, "error": "Groq API key looks too short."}), 400
    try:
        with LOCK:
            CFG["ai_enabled"] = bool(d.get("ai_enabled", CFG.get("ai_enabled", False)))
            CFG["ai_control_enabled"] = bool(d.get("ai_control_enabled", CFG.get("ai_control_enabled", True)))
            CFG["ai_model"] = "openai/gpt-oss-20b"
            if d.get("weather_location") is not None:
                CFG["weather_location"] = str(d["weather_location"]).strip()[:120]
            if key_update:
                _save_groq_key(key_value)
        save_config()
    except Exception as exc:
        return jsonify({"ok": False, "error": "Could not save Groq key: " + str(exc)[:180]}), 500
    add_event("AI", "AI settings updated" + (" + Groq key changed" if key_update else ""))
    return jsonify({"ok": True, "enabled": bool(CFG["ai_enabled"]), "ai_control_enabled": bool(CFG.get("ai_control_enabled", True)), "model": ai_model(),
                    "groq_key_set": bool(ai_key()), "groq_key_source": ai_key_source(),
                    "weather_key_set": bool(weather_key()),
                    "weather_location": CFG.get("weather_location", ""),
                    "audio_input_device": int(CFG.get("audio_input_device", -1) or -1),
                    "audio_output_device": int(CFG.get("audio_output_device", -1) or -1)})


def _groq_models_http():
    """Verify the Groq key and configured model without depending on chat text."""
    key = ai_key()
    if not key:
        raise RuntimeError("Groq API key is not configured on the Smart Plant PC hub.")
    req = urllib.request.Request(
        "https://api.groq.com/openai/v1/models",
        method="GET",
        headers={
            "Authorization": "Bearer " + key,
            "Accept": "application/json",
            "User-Agent": "SmartPlantIrrigationSystem/42.18.11",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
        models = data.get("data") if isinstance(data, dict) else None
        if not isinstance(models, list):
            raise RuntimeError("Groq models endpoint returned an invalid response.")
        ids = {str(x.get("id")) for x in models if isinstance(x, dict)}
        target = ai_model()
        return {"reachable": True, "model_available": target in ids, "model": target}
    except urllib.error.HTTPError as exc:
        detail = ""
        try:
            detail = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        try:
            obj = json.loads(detail) if detail else None
            if isinstance(obj, dict) and isinstance(obj.get("error"), dict):
                detail = str(obj["error"].get("message") or detail)
        except Exception:
            pass
        raise RuntimeError("Groq HTTP %s: %s" % (exc.code, detail[:700]))
    except urllib.error.URLError as exc:
        raise RuntimeError("Groq network error: %s" % str(exc.reason or exc))


@app.route("/api/ai/verify", methods=["GET", "POST"])
def api_ai_verify():
    """Verify authentication, model access, and real chat inference."""
    key = ai_key()
    if not key:
        return jsonify({"ok":False,"verified":False,"model":ai_model(),"chat_test":False,"error":"Groq API key is not configured."}), 400
    try:
        check=_groq_models_http()
        if not (check.get("reachable") and check.get("model_available")):
            return jsonify({"ok":False,"verified":False,"model":ai_model(),"groq_api_reachable":bool(check.get("reachable")),"model_available":bool(check.get("model_available")),"chat_test":False,"error":"Groq API key is accepted, but the configured model is not available to this account."}), 502
        try:
            probe=_groq_responses_http([{"role":"user","content":"Reply with exactly one word: OK"}])
        except Exception:
            probe=_groq_chat_http_minimal([{"role":"user","content":"Reply with exactly one word: OK"}],max_completion_tokens=256)
        probe_text=extract_groq_text(probe).strip()
        if not probe_text:
            return jsonify({"ok":False,"verified":False,"model":ai_model(),"groq_api_reachable":True,"model_available":True,"chat_test":False,"error":"Groq authentication succeeded, but chat returned no user-facing text."}), 502
        return jsonify({"ok":True,"verified":True,"model":ai_model(),"groq_api_reachable":True,"model_available":True,"chat_test":True,"probe":probe_text[:80],"error":None})
    except Exception as e:
        return jsonify({"ok":False,"verified":False,"model":ai_model(),"groq_api_reachable":False,"chat_test":False,"error":str(e).replace("\n"," ")[:900]}), 502

@app.get("/api/ai/diagnostics")
def api_ai_diagnostics():
    """Real AI preflight: local PC hub + configured Groq key + live Groq check."""
    key = ai_key()
    result = {
        "ok": True,
        "pc_server": "online",
        "groq_key_configured": bool(key),
        "groq_key_source": ai_key_source(),
        "groq_api_reachable": False,
        "groq_api_verified": False,
        "model": ai_model(),
    }
    if not key:
        result["error"] = "Groq API key is not configured on the Smart Plant PC hub."
        return jsonify(result)
    try:
        check = _groq_models_http()
        result["groq_api_reachable"] = bool(check.get("reachable"))
        result["model_available"] = bool(check.get("model_available"))
        if not result["groq_api_reachable"] or not result["model_available"]:
            result["groq_api_verified"] = False
            result["chat_test"] = False
            result["error"] = "Groq API key authenticated, but the configured model is not available to this key/account."
            return jsonify(result)
        try:
            probe = _groq_responses_http([{"role":"user","content":"Reply with exactly one word: OK"}])
        except Exception:
            probe = _groq_chat_http_minimal([{"role":"user","content":"Reply with exactly one word: OK"}], max_completion_tokens=256)
        probe_text = extract_groq_text(probe).strip()
        result["chat_test"] = bool(probe_text)
        result["groq_api_verified"] = bool(probe_text)
        if probe_text:
            result["probe"] = probe_text[:80]
        else:
            result["error"] = "Groq key and model are reachable, but the chat endpoint returned no user-facing text."
    except Exception as exc:
        result["error"] = str(exc).replace("\n", " ")[:900]
        result["chat_test"] = False
        result["groq_api_verified"] = False
    return jsonify(result)


@app.get("/api/ai/voice/health")
def api_ai_voice_health():
    native_ok=bool(sounddevice is not None and sys.platform=="win32")
    if not native_ok:
        return jsonify({"ok":True,"native_desktop_voice":False,"microphone":"unavailable","speaker":False,"tts":bool(google_tts_available())})
    snap=native_audio_devices()
    return jsonify({"ok":True,"native_desktop_voice":bool(snap.get("ok")),"microphone":"available" if snap.get("inputs") else "none","speaker":"available" if snap.get("outputs") else "none","selected_input":snap.get("selected_input",-1),"selected_output":snap.get("selected_output",-1),"tts":bool(google_tts_available())})

@app.get("/api/ai/audio-devices")
def api_ai_audio_devices():
    return jsonify(native_audio_devices())

@app.post("/api/ai/audio-devices")
def api_ai_audio_devices_save():
    d=request.get_json(silent=True) or {}
    try:
        result=set_native_audio_devices(d.get("input_device"),d.get("output_device"))
        return jsonify(result)
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc).replace("\n"," ")[:500]}),400

@app.post("/api/ai/transcribe")
def api_ai_transcribe():
    """Transcribe one short microphone recording with Groq Whisper.
    The browser/WebView supplies the audio; the Groq key remains on the PC hub.
    """
    key = ai_key()
    if not key:
        return jsonify({"ok": False, "error": "Groq API key is not configured on the Smart Plant PC hub."}), 400
    if Groq is None:
        return jsonify({"ok": False, "error": "Groq Python SDK is missing. Reinstall the app with the latest setup.exe."}), 503
    up = request.files.get("file")
    if up is None or not up.filename:
        return jsonify({"ok": False, "error": "No microphone audio file was uploaded."}), 400
    raw = up.read()
    if not raw:
        return jsonify({"ok": False, "error": "The microphone recording is empty."}), 400
    if len(raw) > 24 * 1024 * 1024:
        return jsonify({"ok": False, "error": "Voice recording is too large."}), 413
    language = str(request.form.get("language") or "en").lower().strip()
    if language not in ("en", "si", "ja"):
        language = "en"
    try:
        client = Groq(api_key=key)
        result = client.audio.transcriptions.create(
            file=(up.filename or "smartplant-voice.webm", raw),
            model="whisper-large-v3-turbo",
            language=language,
            response_format="json",
            temperature=0.0,
            prompt="Smart Plant irrigation system, plant, soil moisture, water tank, pump, auto irrigation, sensor, temperature, humidity, developer, Tharusha, Geenuka, Sudesh."
        )
        text_value = str(getattr(result, "text", "") or "").strip()
        if not text_value:
            return jsonify({"ok": False, "error": "No speech was detected."}), 422
        return jsonify({"ok": True, "text": text_value[:4000], "model": "whisper-large-v3-turbo"})
    except Exception as e:
        return jsonify({"ok": False, "error": "Groq transcription error: " + str(e).replace("\n", " ")[:320]}), 502

@app.post("/api/ai/native-tts")
def api_ai_native_tts():
    if sys.platform != "win32":
        return jsonify({"ok":False,"error":"Native Windows audio is not available on this platform."}),400
    d=request.get_json(silent=True) or {}
    result=native_tts(d.get("text"), d.get("language","en"))
    return jsonify(result), (200 if result.get("ok") else 502)

@app.get("/api/ai/native-audio-test")
def api_ai_native_audio_test():
    return jsonify(native_audio_test())

@app.post("/api/ai/tts")
def api_ai_tts():
    d=request.get_json(silent=True) or {}
    text_value=str(d.get("text") or "").strip()[:12000]
    language=str(d.get("language") or "en").lower().strip()
    if not text_value:
        return jsonify({"ok":False,"error":"TTS text is empty."}),400
    if not google_tts_available():
        return jsonify({"ok":False,"error":"Google TTS is not installed on the PC hub. Reinstall the app with the latest setup.exe."}),503
    try:
        audio=google_tts_mp3(text_value,language)
        if not audio:
            raise RuntimeError("Google TTS returned no audio.")
        resp=make_response(audio)
        resp.headers["Content-Type"]="audio/mpeg"
        resp.headers["Cache-Control"]="no-store"
        resp.headers["X-SmartPlant-TTS-Engine"]="Google TTS"
        resp.headers["X-SmartPlant-TTS-Language"]=google_tts_lang(language)
        return resp
    except Exception as exc:
        return jsonify({"ok":False,"error":"Google TTS error: %s" % str(exc)[:500]}),502

@app.get("/api/ai/health")
def api_ai_health():
    key_ok=bool(ai_key() or manus_key())
    tts_ok=bool(google_tts_available())
    return jsonify({
        "ok": True,
        "ai_enabled": bool(CFG.get("ai_enabled")),
        "groq_key_configured": key_ok,
        "chat_endpoint": "/api/ai/chat",
        "tts_available": tts_ok,
        "native_windows_sapi": False,
        "model": ai_model(),
        "provider": ai_provider(),
        "manus_key_configured": bool(manus_key()),
    })


@app.get("/api/ai/tts/status")
def api_ai_tts_status():
    return jsonify({
        "ok":True,
        "available":google_tts_available(),
        "engine":"Google TTS",
        "google_languages":GOOGLE_TTS_LANGS
    })


@app.post("/api/ai/chat")
def api_ai_chat():
    if not bool(CFG.get("ai_enabled")):
        return jsonify({"ok": False, "error": "AI Assistant is disabled. Enable it in Settings."}), 409
    d = request.get_json(silent=True) or {}
    user_message = str(d.get("message") or "").strip()
    envelope, err = ai_reply(user_message, d.get("language"), d.get("history"), d.get("platform", "pc"))
    if err:
        return jsonify({"ok": False, "error": err}), 502
    if envelope is not None and envelope.get("action") is None:
        fallback_action = _explicit_control_fallback(user_message)
        if fallback_action is not None:
            envelope["action"] = fallback_action
    action_result = _execute_ai_action(envelope.get("action")) if envelope else {"executed": False, "reason": "no_ai_response"}
    final_reply = str(envelope.get("reply") or "").strip()
    if envelope.get("action") is not None:
        if action_result.get("executed"):
            final_reply += "\n\n✓ Control applied: " + action_result["action"] + (" for %ds." % action_result["seconds"] if action_result.get("seconds") else ".")
        else:
            final_reply += "\n\n⚠ Control not applied: " + str(action_result.get("reason") or "unknown control error")
    return jsonify({"ok": True, "reply": final_reply, "model": ai_model(), "action": envelope.get("action"), "action_result": action_result})


@app.post("/api/board/scan")
def api_board_scan():
    with LOCK:
        if RUN["scan"].get("active"):
            return jsonify({"ok": True, "started": False, "already_running": True}), 200

    # Calculate the scan plan before starting the worker so the UI immediately
    # knows the real total instead of displaying a confusing 0 / 0 state.
    try:
        total = len(build_scan_targets())
    except Exception:
        total = 0

    with LOCK:
        RUN["scan"] = {
            "active": True,
            "checked": 0,
            "total": total,
            "target": "Preparing full LAN sweep...",
            "found": "",
            "error": "",
        }
    SCAN_STOP.clear()
    threading.Thread(target=_manual_scan_worker, daemon=True, name="SmartPlantManualScan").start()
    return jsonify({"ok": True, "started": True, "total": total})


@app.get("/api/board/scan/status")
def api_board_scan_status():
    with LOCK:
        return jsonify({"ok": True, **dict(RUN["scan"])})


@app.post("/api/board/scan/stop")
def api_board_scan_stop():
    # Let the worker own the final active=False transition. That prevents a
    # fast Stop -> Rescan click from starting two discovery workers at once.
    SCAN_STOP.set()
    _set_scan_state(error="Stopping scan...", found="")
    return jsonify({"ok": True, "stopping": True})


@app.post("/api/board/test")
def api_board_test():
    if not board_base():
        return jsonify({"ok": False, "error": "Enter the board address first, or press Find my board."}), 400
    data, err = board_get("/api/state")
    if not data:
        return jsonify({"ok": False, "error": err or "No answer from the board."}), 502
    ok, msg = accept_telemetry(data, source="poll")
    if not ok:
        return jsonify({"ok": False, "error": msg}), 502
    available = [k for k in ("soil", "temperature", "humidity", "water", "gas", "water_temp") if data.get(k) is not None]
    detail = "Controller answered" if not available else "Controller answered; real readings: " + ", ".join(available)
    return jsonify({"ok": True, "detail": detail})


# --------------------------------------------------------------------------
# Panel: neon "hardware monitor" style live view (PC second-screen window + phone app)
# --------------------------------------------------------------------------
PANEL_PREFS_PATH = DATA_DIR / "panel_prefs.json"
PANEL = {
    "want": False,        # what the user asked for (on/off)
    "open": False,        # set by the desktop launcher when the panel window really exists
    "supported": False,   # True only inside the desktop launcher (it owns the window)
    "fullscreen": True,
    "monitor": -1,        # -1 = auto (smallest extra screen if any), else screen index
    "autostart": False,   # open the panel window when the PC app starts
    "rev": 0,             # bumped on every change so the launcher notices
}


def load_panel_prefs():
    try:
        d = json.loads(PANEL_PREFS_PATH.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    PANEL["fullscreen"] = bool(d.get("fullscreen", True))
    PANEL["autostart"] = bool(d.get("autostart", False))
    try:
        PANEL["monitor"] = int(d.get("monitor", -1))
    except (TypeError, ValueError):
        PANEL["monitor"] = -1
    PANEL["want"] = PANEL["autostart"]


def save_panel_prefs():
    try:
        PANEL_PREFS_PATH.write_text(json.dumps({
            "fullscreen": PANEL["fullscreen"], "autostart": PANEL["autostart"], "monitor": PANEL["monitor"],
        }), encoding="utf-8")
    except Exception as exc:
        print("[WARN] could not save panel prefs:", exc)


def panel_sysinfo():
    """CPU / RAM of this PC for the panel tile. None when psutil is unavailable."""
    try:
        import psutil
        return {"cpu": psutil.cpu_percent(interval=None), "ram": psutil.virtual_memory().percent}
    except Exception:
        return None


def panel_status():
    with LOCK:
        d = {k: PANEL[k] for k in ("want", "open", "supported", "fullscreen", "monitor", "autostart")}
    d["ok"] = True
    d["sys"] = panel_sysinfo()
    return d


@app.get("/panel")
@app.get("/panel.html")
def panel_page():
    resp = make_response(render_template("panel.html"))
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.get("/api/panel")
def api_panel_get():
    return jsonify(panel_status())


@app.post("/api/panel")
def api_panel_set():
    d = request.get_json(silent=True) or {}
    action = str(d.get("action", "")).lower()
    with LOCK:
        if action in ("on", "open"):
            PANEL["want"] = True
        elif action in ("off", "close"):
            PANEL["want"] = False
        elif action == "toggle":
            PANEL["want"] = not PANEL["want"]
        elif action == "fullscreen":
            PANEL["fullscreen"] = not PANEL["fullscreen"]
        elif action != "settings":
            return jsonify({"ok": False, "error": "Unknown panel action."}), 400
        if "fullscreen" in d and action == "settings":
            PANEL["fullscreen"] = bool(d["fullscreen"])
        if "autostart" in d:
            PANEL["autostart"] = bool(d["autostart"])
        if "monitor" in d:
            try:
                PANEL["monitor"] = max(-1, min(8, int(d["monitor"])))
            except (TypeError, ValueError):
                pass
        PANEL["rev"] += 1
    save_panel_prefs()
    out = panel_status()
    if action in ("on", "open", "toggle") and not out["supported"] and PANEL["want"]:
        out["note"] = "Panel window needs the Smart Plant desktop app. Open /panel in a browser instead."
    return jsonify(out)


@app.get("/api/server-info")
def api_server_info():
    return jsonify({
        "ok": True,
        "host": "0.0.0.0",
        "ip": lan_ip(),
        "port": PORT,
        "dashboard": "http://%s:%d/dashboard" % (lan_ip(), PORT),
        "uptime": human_uptime(time.time() - START_TIME),
        "ai_model": ai_model(),
        "groq_key_set": bool(ai_key()),
        "data_file": str(DB_PATH),
    })


def parse_minutes(args):
    try:
        m = int(args.get("minutes", 60))
    except (TypeError, ValueError):
        m = 60
    return max(1, min(m, 525600))


@app.get("/api/history")
def api_history():
    minutes = parse_minutes(request.args)
    cutoff = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    c = db()
    rows = [dict(r) for r in c.execute(
        "SELECT * FROM sensor_history WHERE timestamp >= ? ORDER BY id DESC LIMIT 1500", (cutoff,))]
    events = [dict(r) for r in c.execute(
        "SELECT * FROM events WHERE timestamp >= ? ORDER BY id DESC LIMIT 300", (cutoff,))]
    c.close()
    return jsonify({"ok": True, "minutes": minutes, "rows": rows, "events": events})


@app.post("/api/history/clear")
def api_history_clear():
    c = db()
    c.execute("DELETE FROM sensor_history")
    c.execute("DELETE FROM events")
    c.commit()
    c.close()
    add_event("Server", "Stored history cleared by the user")
    return jsonify({"ok": True})


@app.get("/api/analytics")
def api_analytics():
    minutes = parse_minutes(request.args)
    cutoff = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    keys = ("soil", "temperature", "humidity", "water", "gas", "water_temp")
    c = db()
    agg = c.execute(
        "SELECT COUNT(*) n, " + ", ".join(
            "AVG(%s) a_%s, MIN(%s) lo_%s, MAX(%s) hi_%s" % (k, k, k, k, k, k) for k in keys
        ) + " FROM sensor_history WHERE timestamp >= ?", (cutoff,)).fetchone()
    cycles = c.execute(
        "SELECT COUNT(*) n FROM events WHERE timestamp >= ? AND ("
        "  details LIKE '%pump_on%' OR (event IN ('Auto','Schedule') AND details LIKE 'Pump on%')"
        "  OR (event = 'Schedule' AND details LIKE 'Scheduled run%'))", (cutoff,)).fetchone()
    c.close()
    rnd = lambda v: None if v is None else round(v, 2)
    return jsonify({
        "ok": True, "minutes": minutes, "samples": agg["n"] or 0,
        "pump_cycles": cycles["n"] if cycles else None,
        "averages": {k: rnd(agg["a_" + k]) for k in keys},
        "extremes": {k: {"min": rnd(agg["lo_" + k]), "max": rnd(agg["hi_" + k])} for k in keys},
    })


@app.get("/api/export")
def api_export():
    minutes = parse_minutes(request.args)
    cutoff = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    c = db()
    rows = c.execute("SELECT * FROM sensor_history WHERE timestamp >= ? ORDER BY id", (cutoff,)).fetchall()
    c.close()
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["id", "timestamp", "soil_percent", "temperature_c", "humidity_percent",
                "water_percent", "gas_level_percent", "water_temp_c", "pump", "auto_mode"])
    for r in rows:
        w.writerow(list(r))
    resp = make_response(out.getvalue())
    resp.headers["Content-Type"] = "text/csv; charset=utf-8"
    resp.headers["Content-Disposition"] = \
        "attachment; filename=smartplant_history_%s.csv" % datetime.now().strftime("%Y%m%d_%H%M")
    return resp


@app.get("/api/plants")
def api_plants():
    c = db()
    rows = [dict(r) for r in c.execute("SELECT * FROM plants ORDER BY id")]
    c.close()
    return jsonify(rows)


def plant_payload(d):
    name = str(d.get("name", "")).strip()[:48]
    if not name:
        return None, "Give the plant a name."
    try:
        mn = clamp(d.get("moisture_min", 30), 0, 100)
        tg = clamp(d.get("moisture_target", 60), 0, 100)
    except (TypeError, ValueError):
        return None, "Moisture values must be between 0 and 100."
    if tg < mn:
        return None, "Stop level must be the same or higher than the water-below level."
    return (name, str(d.get("plant_type", "Custom")).strip()[:48] or "Custom",
            str(d.get("zone", "Zone 1")).strip()[:24] or "Zone 1",
            mn, tg, str(d.get("notes", "")).strip()[:160]), ""


@app.post("/api/plants")
def api_plant_add():
    vals, err = plant_payload(request.get_json(silent=True) or {})
    if err:
        return jsonify({"ok": False, "error": err}), 400
    c = db()
    c.execute("INSERT INTO plants(name,plant_type,zone,moisture_min,moisture_target,notes) "
              "VALUES(?,?,?,?,?,?)", vals)
    c.commit()
    c.close()
    add_event("Plant", "Added %s" % vals[0])
    return jsonify({"ok": True})


@app.put("/api/plants/<int:pid>")
def api_plant_edit(pid):
    vals, err = plant_payload(request.get_json(silent=True) or {})
    if err:
        return jsonify({"ok": False, "error": err}), 400
    c = db()
    if not c.execute("SELECT 1 FROM plants WHERE id=?", (pid,)).fetchone():
        c.close()
        return jsonify({"ok": False, "error": "Plant not found."}), 404
    c.execute("UPDATE plants SET name=?,plant_type=?,zone=?,moisture_min=?,moisture_target=?,notes=? "
              "WHERE id=?", vals + (pid,))
    c.commit()
    c.close()
    add_event("Plant", "Updated %s" % vals[0])
    return jsonify({"ok": True})


@app.delete("/api/plants/<int:pid>")
def api_plant_delete(pid):
    c = db()
    row = c.execute("SELECT name FROM plants WHERE id=?", (pid,)).fetchone()
    if not row:
        c.close()
        return jsonify({"ok": False, "error": "Plant not found."}), 404
    c.execute("DELETE FROM plants WHERE id=?", (pid,))
    c.commit()
    c.close()
    add_event("Plant", "Deleted %s" % row["name"])
    return jsonify({"ok": True})


# --------------------------------------------------------------------------
def bootstrap():
    init_db()
    load_config()
    load_panel_prefs()
    threading.Thread(target=worker, name="smartplant-worker", daemon=True).start()
    threading.Thread(target=pc_discovery_loop, name="smartplant-pc-discovery", daemon=True).start()


bootstrap()

if __name__ == "__main__":
    print("Smart Plant server on http://%s:%d  (and http://127.0.0.1:%d)" % (lan_ip(), PORT, PORT))
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
