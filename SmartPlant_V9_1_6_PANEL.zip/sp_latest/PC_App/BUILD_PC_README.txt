SMART PLANT - PC FINAL BUILD
============================

Run only:
  PC_App\BUILD_PC_FINAL.bat

The BAT creates an isolated .pc_build_venv automatically, installs the PC
requirements, runs the project-anchored PyInstaller build, builds the custom
Setup.exe, writes SHA256SUMS.txt, and keeps the full log open on failure.

Outputs:
  PC_App\dist\SmartPlantIrrigationSystem.exe
  Setup_Output\SmartPlantIrrigationSystem_Setup.exe
  Setup_Output\SmartPlantIrrigationSystem.exe
  Setup_Output\SHA256SUMS.txt

Requirements:
  Windows 10/11
  Python 3.11-3.13 on PATH
  Internet access for the first dependency install

No Inno Setup is required for this build path.

Important:
  The PyInstaller spec uses absolute paths anchored to the spec file. The
  build no longer depends on the current working directory, so VERSION.txt,
  templates, static files and app_icon.ico resolve correctly.
