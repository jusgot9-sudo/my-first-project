"""Local-first Smart Plant voice pipeline.

    audio -> Whisper STT -> language / dialect detection -> LLM (Ollama) -> TTS

* STT   : openai-whisper. SMARTPLANT_WHISPER_MODEL may be a model name
          (tiny/base/small/medium/large-v3) or a path to a fine-tuned Sinhala
          Whisper checkpoint (.pt) in openai-whisper format.
* Dialect: Sinhala script + romanised Sinhala ("Singlish") + English detection,
          optional `langdetect`, and an editable dialect lexicon.
* LLM   : local Ollama HTTP API (no API key).
* TTS   : Coqui (optional, SMARTPLANT_COQUI_MODEL) -> pyttsx3 voice for the
          language. If no voice exists for the language a NoLocalVoice error is
          raised so the caller can fall back (app.py falls back to Google TTS).
"""
from __future__ import annotations

import io
import json
import os
import re
import tempfile
import threading
import wave
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parent
MODEL_NAME = os.getenv("SMARTPLANT_WHISPER_MODEL", "small")
OLLAMA_MODEL = os.getenv("SMARTPLANT_OLLAMA_MODEL", "qwen2.5:7b")
OLLAMA_URL = os.getenv("SMARTPLANT_OLLAMA_URL", "http://127.0.0.1:11434")
COQUI_MODEL = os.getenv("SMARTPLANT_COQUI_MODEL", "").strip()

STT_PROMPT = (
    "Smart Plant irrigation system, plant, soil moisture, water tank, pump, "
    "auto irrigation, sensor, temperature, humidity, pump eka on karanna, "
    "watura, gaha, mala, motor eka."
)

_whisper_model = None
_whisper_lock = threading.Lock()
_transcribe_lock = threading.Lock()
_tts_lock = threading.Lock()


class NoLocalVoice(RuntimeError):
    """Raised when no installed local TTS voice supports the language."""


# --------------------------------------------------------------------------
# STT
# --------------------------------------------------------------------------
def _load_whisper():
    global _whisper_model
    if _whisper_model is not None:
        return _whisper_model
    with _whisper_lock:
        if _whisper_model is None:
            try:
                import whisper  # type: ignore
            except Exception as exc:
                raise RuntimeError(
                    "Local Whisper is not installed. Run PC_App\\pip install -r requirements-local-ai.txt."
                ) from exc
            try:
                _whisper_model = whisper.load_model(MODEL_NAME)
            except Exception as exc:
                raise RuntimeError(
                    "Could not load Whisper model '%s': %s" % (MODEL_NAME, str(exc)[:300])
                ) from exc
    return _whisper_model


def _read_audio(audio_path: str):
    import numpy as np

    try:
        with wave.open(str(audio_path), "rb") as wf:
            channels = wf.getnchannels()
            width = wf.getsampwidth()
            rate = wf.getframerate()
            frames = wf.readframes(wf.getnframes())
        if width != 2:
            raise wave.Error("only 16-bit PCM supported")
        audio = np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0
        if channels > 1:
            audio = audio[: (audio.size // channels) * channels].reshape(-1, channels).mean(axis=1)
        if audio.size and rate != 16000:
            target = int(round(audio.size * 16000 / rate))
            if target > 1:
                x_old = np.linspace(0.0, 1.0, num=audio.size, endpoint=False)
                x_new = np.linspace(0.0, 1.0, num=target, endpoint=False)
                audio = np.interp(x_new, x_old, audio).astype(np.float32)
        return audio
    except (wave.Error, EOFError):
        # webm/mp3/m4a etc. need ffmpeg through whisper's own loader.
        import whisper  # type: ignore

        try:
            return whisper.load_audio(str(audio_path))
        except Exception as exc:
            raise RuntimeError(
                "Unsupported audio format. Send a 16-bit WAV, or install ffmpeg."
            ) from exc


def _pick_si_en(model, audio):
    try:
        import whisper  # type: ignore

        seg = whisper.pad_or_trim(audio)
        mel = whisper.log_mel_spectrogram(seg, n_mels=getattr(model.dims, "n_mels", 80)).to(model.device)
        with _transcribe_lock:
            _, probs = model.detect_language(mel)
        return "si" if probs.get("si", 0.0) > probs.get("en", 0.0) * 0.6 else "en"
    except Exception:
        return None


def transcribe_audio(audio_path: str, language: str = "") -> str:
    audio = _read_audio(audio_path)
    if audio.size == 0:
        raise RuntimeError("The audio recording was empty.")
    # Too quiet / too short audio makes Whisper hallucinate text.
    import numpy as np

    if audio.size < 1600 or float(np.sqrt(np.mean(np.square(audio)))) < 0.002:
        raise RuntimeError("No speech was detected in the recording.")
    model = _load_whisper()
    kwargs: Dict[str, Any] = {
        "fp16": False,
        "temperature": 0.0,
        "condition_on_previous_text": False,
        "verbose": False,
        "initial_prompt": STT_PROMPT,
    }
    lang = (language or "").strip().lower()
    if lang == "ja":
        kwargs["language"] = "ja"
    else:
        # Sinhala speakers often use the English UI: pick Sinhala vs English from the audio itself.
        kwargs["language"] = _pick_si_en(model, audio) or (lang if lang in ("si", "en") else None)
        if kwargs["language"] is None:
            del kwargs["language"]
    with _transcribe_lock:  # Whisper is not thread-safe
        result = model.transcribe(audio, **kwargs)
    text = str((result or {}).get("text") or "").strip()
    if not text:
        raise RuntimeError("No speech was detected in the recording.")
    return text[:4000]


# --------------------------------------------------------------------------
# Language + dialect detection
# --------------------------------------------------------------------------
# Romanised Sinhala ("Singlish") marker words: machan, mata, eka, karanna ...
ROMAN_SINHALA = {
    "mata", "mage", "mama", "oya", "oyage", "api", "ape", "eka", "ekak", "oka",
    "okak", "meka", "karanna", "karamu", "karala", "kara", "danna", "dana",
    "dapan", "denna", "hadanna", "hadamu", "hadala", "balanna", "kiyanna",
    "kiyala", "ona", "oni", "one", "ne", "nae", "naha", "nathi", "natuwa",
    "tiyenawa", "thiyenawa", "wage", "wagema", "hari", "harima", "hariyata",
    "mokakda", "mokada", "kohomada", "kohomada?", "ayye", "aiye", "machan",
    "macha", "machang", "bro", "bn", "malli", "akka", "nangi", "ban", "bang",
    "yanna", "enna", "wada", "wedak", "watura", "wathura", "gaha", "mala",
    "pompaya", "motor", "dhanna", "nawattanna", "nawaththanna", "arinna",
    "wahanna", "ekata", "eke", "ekath", "nam", "nathnam", "da", "dha", "thama",
    "thiyanawa", "inne", "innawa", "giya", "gihin", "awa", "awith", "puluwan",
    "baha", "bari", "poddak", "godak", "godaak", "lassanai", "hodai", "narakai",
    "mokak", "mokakda", "kiyada", "kiyanawa", "wenawa", "weyi", "wela", "una",
    "unath", "nisa", "hinda", "eth", "ethakota", "dan", "dang", "ada", "heta",
}

DIALECT_LEXICON = {
    "colombo": {"මචං", "බං", "අඩේ", "මොකක්ද", "කරමු", "හරිද",
                "machan", "macha", "machang", "bro", "ban", "bang", "adei", "ado"},
    "kandy": {"අපේ", "හෙටත්", "එහෙමයි", "නේදෝ", "ape", "hetath", "nedo", "ehemai"},
    "southern": {"අනේ", "මල්ලී", "බොල", "ඇයිකෝ", "bola", "aiko", "malli", "ane", "bolla"},
}

_WORD_RE = re.compile(r"[\u0D80-\u0DFF]+|[A-Za-z']+")


def detect_language_and_dialect(text: str) -> Dict[str, Any]:
    """Return {"language": si|en|mixed|singlish, "dialect": ..., "script": ...}.

    language:
      si       - Sinhala script only
      en       - English
      singlish - romanised Sinhala (Latin letters)
      mixed    - Sinhala script + Latin, or English + romanised Sinhala
    """
    value = str(text or "").strip()
    if not value:
        return {"language": "en", "dialect": "unknown", "script": "none"}
    chars = [c for c in value if not c.isspace()]
    si_chars = sum("\u0D80" <= c <= "\u0DFF" for c in chars)
    latin_chars = sum(("a" <= c.lower() <= "z") for c in chars)
    words = [w.lower() for w in _WORD_RE.findall(value)]
    latin_words = [w for w in words if w.isascii()]
    roman_hits = sum(1 for w in latin_words if w in ROMAN_SINHALA)

    if si_chars and latin_chars:
        language, script = "mixed", "mixed"
    elif si_chars:
        language, script = "si", "sinhala"
    else:
        script = "latin"
        ratio = roman_hits / max(1, len(latin_words))
        if roman_hits >= 2 and ratio >= 0.4:
            language = "singlish"
        elif roman_hits >= 1 and ratio >= 0.15:
            language = "mixed"
        else:
            language = "en"
            try:  # optional second opinion for plain English
                from langdetect import detect  # type: ignore

                if len(latin_words) >= 4 and detect(value) not in ("en",):
                    language = "mixed" if roman_hits else "en"
            except Exception:
                pass

    best, dialect = 0, "unknown"
    wordset = set(words)
    for label, lex in DIALECT_LEXICON.items():
        score = sum(1 for w in lex if w.lower() in wordset)
        if score > best:
            best, dialect = score, label
    return {"language": language, "dialect": dialect, "script": script}


# --------------------------------------------------------------------------
# LLM (Ollama)
# --------------------------------------------------------------------------
def _http_json(url: str, payload: Optional[dict] = None, timeout: float = 30.0) -> dict:
    import urllib.request

    data = None
    headers = {"Accept": "application/json"}
    method = "GET"
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
        method = "POST"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8", errors="replace"))
    except Exception as exc:
        raise RuntimeError(
            "Ollama is not reachable at %s. Start Ollama (run 'ollama serve') and "
            "pull the model with: ollama pull %s  (%s)" % (OLLAMA_URL, OLLAMA_MODEL, str(exc)[:160])
        ) from exc


def ollama_models() -> List[str]:
    result = _http_json(OLLAMA_URL.rstrip("/") + "/api/tags", None, timeout=3.0)
    models = result.get("models") if isinstance(result, dict) else None
    if not isinstance(models, list):
        return []
    return [str(m.get("name") or "") for m in models if isinstance(m, dict)]


def _model_installed(names: List[str]) -> bool:
    want = OLLAMA_MODEL.strip()
    if ":" in want:
        return want in names
    return any(n == want or n.split(":")[0] == want for n in names)


def ollama_available() -> bool:
    try:
        return _model_installed(ollama_models())
    except Exception:
        return False


_LANG_NAMES = {"si": "Sinhala (සිංහල script)", "en": "English", "ja": "Japanese"}


def _reply_language_rule(language_info: Dict[str, Any], ui_language: str) -> str:
    detected = str(language_info.get("language") or "en")
    ui = (ui_language or "").lower()
    if detected in ("si", "singlish", "mixed"):
        return ("The user speaks Sinhala (possibly romanised 'Singlish' or mixed with English). "
                "Reply in simple, friendly Sinhala script (සිංහල). Keep technical words like "
                "pump, sensor, soil moisture in English.")
    if ui in _LANG_NAMES and ui != "en" and detected == "en" and ui == "si":
        return "Reply in simple Sinhala script (සිංහල), keeping technical words in English."
    if ui == "ja":
        return "Reply in Japanese."
    return "Reply in English."


def ollama_chat(message: str, language_info: Dict[str, Any], history: Optional[List[dict]] = None,
                live_context: Optional[dict] = None, ui_language: str = "",
                memory: Optional[List[str]] = None) -> str:
    system = (
        "You are the local SmartPlant irrigation assistant. You run without cloud APIs. "
        "Answer only about plants, irrigation, soil, sensors, water tank, pump, automation, "
        "diagnostics and this app; politely refuse unrelated topics. "
        + _reply_language_rule(language_info, ui_language) + " "
        "Keep replies short (1-3 sentences) because they are spoken aloud. "
        "Never invent live sensor values or device states; use only the LIVE CONTROLLER DATA. "
        "Never claim you switched the pump or auto mode yourself - the app does that separately. "
        "Detected language: %s; dialect: %s." % (language_info.get("language"), language_info.get("dialect"))
    )
    if live_context:
        system += "\nLIVE CONTROLLER DATA:\n" + json.dumps(live_context, ensure_ascii=False, separators=(",", ":"), default=str)
    if memory:
        system += ("\nLONG-TERM MEMORY (facts the user asked you to remember; use them naturally, "
                   "never invent others):\n- " + "\n- ".join(str(m)[:300] for m in memory[:30]))
    prompt = str(message or "").strip()[:4000]
    messages: List[dict] = [{"role": "system", "content": system}]
    hist: List[dict] = []
    for item in (history or [])[-10:]:
        if not isinstance(item, dict):
            continue
        role = "assistant" if item.get("role") == "assistant" else "user"
        text = str(item.get("text") or item.get("content") or "").strip()
        if text:
            hist.append({"role": role, "content": text[:1200]})
    # The UI already stores the current user message in history - avoid sending it twice.
    if hist and hist[-1]["role"] == "user" and hist[-1]["content"] == prompt[:1200]:
        hist = hist[:-1]
    messages.extend(hist[-8:])
    messages.append({"role": "user", "content": prompt})
    payload = {"model": OLLAMA_MODEL, "messages": messages, "stream": False,
               "options": {"temperature": 0.3, "num_predict": 400}}
    result = _http_json(OLLAMA_URL.rstrip("/") + "/api/chat", payload, timeout=120.0)
    if isinstance(result, dict) and result.get("error"):
        raise RuntimeError("Ollama error: %s" % str(result["error"])[:300])
    try:
        reply = str(result["message"]["content"]).strip()
    except Exception as exc:
        raise RuntimeError("Local Ollama returned no assistant text.") from exc
    reply = re.sub(r"<think>.*?</think>", "", reply, flags=re.S).strip()
    if not reply:
        raise RuntimeError("Local Ollama returned an empty assistant reply.")
    return reply[:12000]


# --------------------------------------------------------------------------
# TTS
# --------------------------------------------------------------------------
_coqui = None


def synthesize_wav(text: str, language: str = "en") -> Optional[bytes]:
    """Return WAV bytes from Coqui TTS if SMARTPLANT_COQUI_MODEL is set, else None."""
    global _coqui
    if not COQUI_MODEL:
        return None
    try:
        if _coqui is None:
            from TTS.api import TTS  # type: ignore

            _coqui = TTS(COQUI_MODEL)
        fd, path = tempfile.mkstemp(prefix="smartplant_coqui_", suffix=".wav")
        os.close(fd)
        try:
            _coqui.tts_to_file(text=text, file_path=path)
            return Path(path).read_bytes()
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass
    except Exception as exc:
        raise RuntimeError("Coqui TTS failed: %s" % str(exc)[:300]) from exc


def _voice_matches(voice: Any, wanted: str) -> bool:
    blob = " ".join(str(x or "") for x in [getattr(voice, "id", ""), getattr(voice, "name", ""),
                                            getattr(voice, "languages", "")]).lower()
    keys = {"si": ("sinhala", "si-lk", "si_lk", "si-", "sinhalese"),
            "en": ("english", "en-us", "en-gb", "en_", "en-"),
            "ja": ("japanese", "ja-jp", "ja_", "ja-")}.get(wanted, (wanted,))
    return any(k in blob for k in keys)


def _pyttsx3_speak(text: str, language: str = "en") -> str:
    try:
        import pyttsx3  # type: ignore
    except Exception as exc:
        raise RuntimeError("Local TTS is not installed. Run PC_App\\pip install -r requirements-local-ai.txt.") from exc
    with _tts_lock:
        com = None
        try:  # pyttsx3/SAPI needs COM initialised in worker threads on Windows
            import pythoncom  # type: ignore

            pythoncom.CoInitialize()
            com = pythoncom
        except Exception:
            pass
        engine = None
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", 175)
            engine.setProperty("volume", 1.0)
            voices = engine.getProperty("voices") or []
            wanted = language if language in ("si", "en", "ja") else "en"
            selected = next((v for v in voices if _voice_matches(v, wanted)), None)
            if selected is None and wanted != "en":
                raise NoLocalVoice("No installed local voice supports '%s'." % wanted)
            if selected is not None:
                engine.setProperty("voice", selected.id)
            engine.say(text)
            engine.runAndWait()
        finally:
            try:
                if engine is not None:
                    engine.stop()
            except Exception:
                pass
            if com is not None:
                try:
                    com.CoUninitialize()
                except Exception:
                    pass
    return "pyttsx3-local"


def local_tts(text: str, language: str = "en") -> str:
    clean = re.sub(r"\s+", " ", str(text or "")).strip()
    if not clean:
        raise RuntimeError("No text was supplied to local TTS.")
    return _pyttsx3_speak(clean[:2000], language)


# --------------------------------------------------------------------------
def status() -> dict:
    whisper_ok, whisper_error = False, None
    try:
        import whisper  # type: ignore  # noqa: F401

        whisper_ok = True
    except Exception as exc:
        whisper_error = str(exc)
    tts_ok = False
    try:
        import pyttsx3  # type: ignore  # noqa: F401

        tts_ok = True
    except Exception:
        pass
    ollama_error, ollama, models = None, False, []
    try:
        models = ollama_models()
        ollama = _model_installed(models)
        if not ollama:
            ollama_error = "Model '%s' not installed. Run: ollama pull %s" % (OLLAMA_MODEL, OLLAMA_MODEL)
    except Exception as exc:
        ollama_error = str(exc)
    problems = []
    if not whisper_ok:
        problems.append("Whisper missing")
    if not tts_ok and not COQUI_MODEL:
        problems.append("TTS missing")
    if ollama_error:
        problems.append(ollama_error)
    return {
        "ok": bool(whisper_ok and (tts_ok or COQUI_MODEL) and ollama),
        "error": "; ".join(problems),
        "whisper_installed": whisper_ok,
        "whisper_model": MODEL_NAME,
        "whisper_error": whisper_error,
        "dialect_detector": "sinhala-script + romanised-singlish lexicon" ,
        "ollama_url": OLLAMA_URL,
        "ollama_model": OLLAMA_MODEL,
        "ollama_available": ollama,
        "ollama_error": ollama_error,
        "ollama_models": models,
        "tts_engine": "coqui" if COQUI_MODEL else "pyttsx3-local",
        "tts_installed": bool(tts_ok or COQUI_MODEL),
        "api_key_required": False,
    }
