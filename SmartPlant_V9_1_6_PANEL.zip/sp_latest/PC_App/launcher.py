"""Smart Plant System native Windows desktop entry point."""
import socket
import threading
import time
import os
import sys
import subprocess

import webview

from app import app, PORT, lan_ip, DB_PATH, PANEL, LOCK, save_panel_prefs, native_voice_chat, native_local_voice_chat, native_local_tts, native_tts, native_audio_test, native_audio_devices, set_native_audio_devices, open_windows_microphone_settings, open_windows_sound_settings


def wait_for_server(host="127.0.0.1", port=PORT, timeout=15.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.2)
    return False


def run_server():
    app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True, use_reloader=False)



def ensure_windows_firewall():
    """Best-effort private-LAN firewall rules (works only when run as admin; the installer
    already adds them). Never blocks app startup."""
    if sys.platform != "win32":
        return False
    try:
        rules = [("Smart Plant TCP 5000", "TCP", "5000"), ("Smart Plant UDP 4210", "UDP", "4210"),
                 ("Smart Plant UDP 4211", "UDP", "4211")]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        for name, proto, port in rules:
            exists = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule", "name=" + name],
                                    capture_output=True, creationflags=flags).returncode == 0
            if not exists:
                subprocess.Popen(["netsh", "advfirewall", "firewall", "add", "rule", "name=" + name,
                                  "dir=in", "action=allow", "protocol=" + proto, "localport=" + port,
                                  "profile=domain,private"], creationflags=flags)
        return True
    except Exception as exc:
        print("[WARN] Firewall setup skipped:", exc)
        return False


def _resource(name):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


def setup_tray(window):
    """Close (X) hides the app to the Windows system tray; right-click tray icon -> Open / Exit."""
    try:
        import pystray
        from PIL import Image
    except Exception as exc:
        print("[WARN] Tray disabled (pip install pystray pillow):", exc)
        return None
    state = {"quit": False}

    def show(icon=None, item=None):
        window.show()
        window.restore()

    def quit_app(icon, item):
        state["quit"] = True
        icon.stop()
        try:
            window.destroy()
        finally:
            os._exit(0)

    def on_closing():
        if state["quit"]:
            return True
        window.hide()
        return False  # cancel close -> keep running in the tray

    window.events.closing += on_closing
    icon = pystray.Icon("SmartPlant", Image.open(_resource("app_icon.ico")), "Smart Plant Irrigation System",
                        menu=pystray.Menu(pystray.MenuItem("Open Smart Plant", show, default=True),
                                          pystray.MenuItem("Panel on / off", panel_manager.toggle),
                                          pystray.MenuItem("Exit", quit_app)))
    icon.run_detached()
    return icon


class PanelManager:
    """Owns the second 'Panel' window (neon HUD). The web API (/api/panel) only flips PANEL['want'];
    this thread opens / closes / re-sizes the real window so the PC UI, the tray and the phone all control it."""

    def __init__(self):
        self.window = None
        self.pref_seen = None
        self.mon_applied = None

    def _pick_screen(self):
        screens = list(getattr(webview, "screens", None) or [])
        if len(screens) < 2:
            return None, screens
        idx = PANEL["monitor"]
        if 0 <= idx < len(screens):
            return screens[idx], screens
        extra = screens[1:]   # first entry is the primary monitor; prefer the smallest other one (USB mini display)
        return min(extra, key=lambda sc: sc.width * sc.height), screens

    def open(self):
        screen, screens = self._pick_screen()
        fullscreen = bool(PANEL["fullscreen"])
        kwargs = dict(
            title="Smart Plant Panel",
            url="http://127.0.0.1:%d/panel?pc=1" % PORT,
            width=960, height=600, min_size=(480, 300), resizable=True,
            background_color="#04070a", confirm_close=False,
        )
        if screen is not None:
            kwargs["screen"] = screen
            kwargs["fullscreen"] = fullscreen
            kwargs["frameless"] = fullscreen
        else:
            kwargs["fullscreen"] = False   # single monitor: never cover the main app, use a normal window
        try:
            self.window = webview.create_window(**kwargs)
        except TypeError:   # very old pywebview without screen= support
            kwargs.pop("screen", None)
            self.window = webview.create_window(**kwargs)
        self.window.events.closed += self._on_closed
        self.pref_seen = PANEL["fullscreen"]
        self.mon_applied = PANEL["monitor"]
        with LOCK:
            PANEL["open"] = True

    def close(self):
        w, self.window = self.window, None
        with LOCK:
            PANEL["open"] = False
        if w is not None:
            try:
                w.events.closed -= self._on_closed
            except Exception:
                pass
            try:
                w.destroy()
            except Exception as exc:
                print("[WARN] panel close:", exc)

    def _on_closed(self):
        """User closed the panel window itself (Alt+F4 / X): that means 'off'."""
        if self.window is None:   # we closed it ourselves (off / rebuild) - nothing to do
            return
        self.window = None
        with LOCK:
            PANEL["open"] = False
            PANEL["want"] = False
            PANEL["rev"] += 1

    def toggle(self, icon=None, item=None):
        with LOCK:
            PANEL["want"] = not PANEL["want"]
            PANEL["rev"] += 1

    def loop(self):
        while True:
            time.sleep(0.5)
            try:
                want = PANEL["want"]
                if want and self.window is None:
                    self.open()
                elif not want and self.window is not None:
                    self.close()
                elif want and self.window is not None:
                    multi = len(getattr(webview, "screens", None) or []) >= 2
                    if self.mon_applied != PANEL["monitor"] or (multi and self.pref_seen != PANEL["fullscreen"]):
                        # monitor or fullscreen/frameless changed on a multi-screen PC -> rebuild the window
                        self.close()
                        PANEL["want"] = True
                        self.open()
                    elif self.pref_seen != PANEL["fullscreen"]:
                        # single monitor: only a user-pressed fullscreen button toggles it
                        self.window.toggle_fullscreen()
                        self.pref_seen = PANEL["fullscreen"]
            except Exception as exc:
                print("[WARN] panel manager:", exc)


panel_manager = PanelManager()


class DesktopBridge:
    """Exposed to the dashboard as window.pywebview.api.* for native window controls."""

    def __init__(self, window):
        self._window = window

    def toggle_fullscreen(self):
        self._window.toggle_fullscreen()
        return True

    def minimize(self):
        self._window.minimize()
        return True

    def panel_toggle(self):
        panel_manager.toggle()
        return PANEL["want"]

    def native_voice_chat(self, language="en", seconds=8, history=None):
        return native_voice_chat(language=language, platform="pc", seconds=seconds, history=history or [])

    def native_local_voice_chat(self, language="en", seconds=8, history=None):
        return native_local_voice_chat(language=language, seconds=seconds, history=history or [])

    def native_local_tts(self, text, language="en"):
        return native_local_tts(text, language)

    def native_tts(self, text, language="en"):
        return native_tts(text, language)

    def native_audio_test(self):
        return native_audio_test()

    def audio_devices(self):
        return native_audio_devices()

    def set_audio_devices(self, input_device=-1, output_device=-1):
        return set_native_audio_devices(input_device=input_device, output_device=output_device)

    def open_microphone_settings(self):
        return open_windows_microphone_settings()

    def open_sound_settings(self):
        return open_windows_sound_settings()


if __name__ == "__main__":
    print("Developed by Tharusha")
    print("Phone app / LAN API: http://%s:%d" % (lan_ip(), PORT))
    print("Data file: %s" % DB_PATH)

    ensure_windows_firewall()

    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()

    if not wait_for_server():
        raise RuntimeError("Smart Plant server did not start on port %d" % PORT)

    window = webview.create_window(
        "Smart Plant Irrigation System",
        "http://127.0.0.1:%d" % PORT,
        width=1440,
        height=900,
        min_size=(1100, 700),
        resizable=True,
        confirm_close=False,
        background_color="#05080d",
        maximized=True,
    )
    bridge = DesktopBridge(window)
    PANEL["supported"] = True
    threading.Thread(target=panel_manager.loop, name="smartplant-panel", daemon=True).start()
    setup_tray(window)
    window.expose(bridge.toggle_fullscreen, bridge.minimize, bridge.panel_toggle, bridge.native_voice_chat, bridge.native_local_voice_chat, bridge.native_local_tts, bridge.native_tts, bridge.native_audio_test, bridge.audio_devices, bridge.set_audio_devices, bridge.open_microphone_settings, bridge.open_sound_settings)
    webview.start(debug=False)


