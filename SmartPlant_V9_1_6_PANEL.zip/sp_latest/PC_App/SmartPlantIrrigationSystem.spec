# -*- mode: python ; coding: utf-8 -*-
"""Smart Plant Irrigation System - Windows PyInstaller spec.
All resource paths are anchored to this .spec file, never to the caller's CWD.
"""
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

# NOTE: PyInstaller does not define __file__ inside .spec files; SPECPATH is the spec folder.
SPEC_DIR = Path(SPECPATH).resolve()
ROOT = SPEC_DIR.parent
PC = SPEC_DIR


def add_data(src: Path, dest: str):
    if not src.exists():
        raise FileNotFoundError(f"Required PyInstaller data path is missing: {src}")
    return (str(src), dest)


datas = [
    add_data(PC / "templates", "templates"),
    add_data(PC / "static", "static"),
    add_data(PC / "app_icon.ico", "."),
    add_data(ROOT / "VERSION.txt", "."),
]
binaries = []
hiddenimports = [
    "flask",
    "sounddevice",
    "_sounddevice",
    "local_voice_engine",
    "pyttsx3.drivers",
    "pyttsx3.drivers.sapi5",
    "pystray",
    "pystray._win32",
    "PIL.Image",
    "win32com",
    "win32com.client",
    "pythoncom",
    "pywintypes",
    "comtypes",
    "clr",
]

# Package resources needed at runtime. Keep each collect_all isolated so one
# optional package cannot invalidate the entire build.
for package in ("webview", "sounddevice", "gtts", "groq", "pygame", "clr_loader", "pythonnet", "proxy_tools", "bottle"):
    try:
        pkg_datas, pkg_bins, pkg_hidden = collect_all(package)
        datas += pkg_datas
        binaries += pkg_bins
        hiddenimports += pkg_hidden
    except Exception:
        pass

analysis = Analysis(
    [str(PC / "launcher.py")],
    pathex=[str(PC), str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["torch", "whisper", "tensorflow", "matplotlib", "scipy", "pandas", "IPython"],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(analysis.pure)

exe = EXE(
    pyz,
    analysis.scripts,
    analysis.binaries,
    analysis.datas,
    [],
    name="SmartPlantIrrigationSystem",
    icon=str(PC / "app_icon.ico"),
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
