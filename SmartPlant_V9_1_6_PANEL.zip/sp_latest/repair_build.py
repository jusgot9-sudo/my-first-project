"""Safe, repeatable repairs used by BUILD_SETUP_5X_CHECK_AND_FIX.bat.
Does not rewrite application logic or secrets; it only repairs known build hygiene issues.
"""
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent
errors = []

# Remove generated Python caches that can confuse copied installer payloads.
for cache in ROOT.rglob("__pycache__"):
    if cache.is_dir():
        shutil.rmtree(cache, ignore_errors=True)

# Keep the duplicated front-end JavaScript byte-for-byte identical.
android_js = ROOT / "Android_App/app/src/main/assets/ui/js/app.js"
pc_js = ROOT / "PC_App/static/js/app.js"
if android_js.exists() and pc_js.exists() and android_js.read_bytes() != pc_js.read_bytes():
    pc_js.write_bytes(android_js.read_bytes())

# Keep the Panel (HUD) files identical on PC and Android.
for rel_pc, rel_an in (("PC_App/templates/panel.html", "Android_App/app/src/main/assets/ui/panel.html"),
                       ("PC_App/static/css/panel.css", "Android_App/app/src/main/assets/ui/css/panel.css"),
                       ("PC_App/static/js/panel.js", "Android_App/app/src/main/assets/ui/js/panel.js")):
    src, dst = ROOT / rel_pc, ROOT / rel_an
    if src.exists() and dst.parent.exists() and (not dst.exists() or src.read_bytes() != dst.read_bytes()):
        dst.write_bytes(src.read_bytes())

# Android theme.css = PC theme.css (canonical, newest) + the Android-only native-app block.
android_css = ROOT / "Android_App/app/src/main/assets/ui/css/theme.css"
pc_css = ROOT / "PC_App/static/css/theme.css"
ANDROID_BLOCK = "/* ===== V9.1 native-app feel (Android) ===== */"
if android_css.exists() and pc_css.exists():
    old = android_css.read_text(encoding="utf-8")
    i = old.rfind(ANDROID_BLOCK)
    block = old[i:].split("\n\n", 1)[0] + "\n" if i != -1 else ""
    pc_text = pc_css.read_text(encoding="utf-8").rstrip("\n") + "\n"
    android_css.write_text(pc_text + ("\n" + block if block else ""), encoding="utf-8")

# Keep the Android version fallback non-null for local Gradle builds.
gradle = ROOT / "Android_App/app/build.gradle"
if gradle.exists():
    text = gradle.read_text(encoding="utf-8")
    old = 'versionName (System.getenv("SP_VERSION_NAME") ?: "9.0.0")'
    new = 'versionName (localVersionName ? localVersionName : "9.1.3")'
    if old in text:
        text = text.replace(old, new)
    if "def localVersionName = System.getenv('SP_VERSION_NAME')" not in text:
        text = text.replace("    compileSdk 35\n", "    compileSdk 35\n\n    def localVersionCode = System.getenv('SP_VERSION_CODE')\n    def localVersionName = System.getenv('SP_VERSION_NAME')\n", 1)
    text = text.replace('versionCode (System.getenv("SP_VERSION_CODE") ?: "13").toInteger()', 'versionCode (localVersionCode ? localVersionCode.toInteger() : 13)')
    gradle.write_text(text, encoding="utf-8")

# Fail only on missing source files that the build genuinely requires.
required = [
    "VERSION.txt", "build.py", "PC_App/app.py", "PC_App/launcher.py",
    "PC_App/SmartPlantIrrigationSystem.spec", "PC_App/templates/dashboard.html",
    "PC_App/static/css/theme.css", "PC_App/static/js/app.js",
    "PC_App/templates/panel.html", "PC_App/static/css/panel.css", "PC_App/static/js/panel.js",
    "Android_App/app/src/main/assets/ui/index.html",
    "Android_App/app/src/main/assets/ui/css/theme.css",
    "Android_App/app/src/main/assets/ui/js/app.js", "Installer/installer.py",
]
for rel in required:
    if not (ROOT / rel).is_file():
        errors.append(f"missing required file: {rel}")

if errors:
    print("REPAIR FAILED")
    for error in errors:
        print(error)
    sys.exit(1)
print("SAFE REPAIR PASS")
