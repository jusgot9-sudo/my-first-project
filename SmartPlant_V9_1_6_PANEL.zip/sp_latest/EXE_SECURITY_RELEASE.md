# SmartPlant EXE security and release hardening

The installer build now creates `Setup_Output/SHA256SUMS.txt` for every `.exe`/`.apk` artifact. Compare the published checksum with the downloaded file before installing.

When building on Windows, configure these environment variables to enable Authenticode signing of both the inner SmartPlant executable and the outer setup executable:

```powershell
$env:SMARTPLANT_SIGN_PFX = 'C:\secure\smartplant-release.pfx'
$env:SMARTPLANT_SIGN_PASSWORD = 'use-your-secret-store-or-ci-secret'
python build.py
```

The build uses SHA-256 signing and a public timestamp service, then runs `signtool verify`. Never commit the PFX file or password. For GitHub Actions, store them as encrypted secrets and write the PFX only during the Windows job.

Tagged Android releases now require the encrypted `ANDROID_KEYSTORE_BASE64` GitHub secret and use the production `release` variant. The workflow refuses to publish a tag APK when that key is missing; non-tag test runs may still use the debug variant. Android app backup is disabled so local AI/connection preferences are not copied into device backups.

Absolute protection against reverse engineering is not possible for a desktop executable. PyInstaller packages Python bytecode, so treat the EXE as distributable code: keep API keys out of source, keep secrets in protected user storage, use a private network, sign release binaries, verify checksums, and publish only from a protected GitHub branch/release workflow.

The server-side fixes are documented in `SECURITY_AUDIT_V9.1.1.md`. Do not expose port 5000 to the public internet.
