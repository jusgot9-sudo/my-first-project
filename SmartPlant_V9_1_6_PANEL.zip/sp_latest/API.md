# Smart Plant V36 API Contract

Phone -> Same Wi-Fi -> ESP32
PC    -> Same Wi-Fi -> ESP32

The phone and PC talk directly to the ESP32 over the same Wi-Fi network. The PC Flask API is local desktop functionality; it is not a required relay between the phone and the ESP32.

## ESP32

`GET /api/state` — live controller + sensor state

`GET /api/health` — Wi-Fi/UNO health

`POST /api/control` — `pump_on`, `pump_off`, `auto_on`, `auto_off`

UDP discovery: port `4210`, request `SMARTPLANT_DISCOVER_V2`.

## Sensor fields

`soil`, `temperature`, `humidity`, `water`, `gas`, `water_temp`. Invalid/unavailable readings are JSON `null`. No fake values are generated.

## Relay

ESP32 UART2 GPIO17/16 talks to Arduino UNO D10/D11. UNO D7 controls the relay.


## AI Assistant API (V36)

### GET `/api/ai/status`
Returns whether AI and AI plant control are enabled, the selected model, and whether API keys are configured. Secret values are never returned.

### POST `/api/ai/settings`
Accepts `ai_enabled`, `ai_model`, `groq_api_key`, `openweather_api_key`, `weather_location`. Use `clear_groq_api_key: true` or `clear_openweather_api_key: true` to clear a stored key. Leaving a key field blank keeps the existing key.

### POST `/api/ai/chat`
Accepts `message`, `language`, and optional `history`. The PC backend adds the current live controller snapshot to the AI instructions. Android can call Groq directly through the native bridge and supplies the live snapshot too.

No real API key is stored in the project source.

## AI plant-control execution (V36)
The AI Assistant is an intent layer over the same `/api/control` contract. A validated AI action can be `pump_on`, `pump_off`, `auto_on`, or `auto_off`. The PC executes it server-side; Android executes it against the directly discovered ESP32. The controller safety rules remain authoritative.

## Panel (V9.1.6)
`GET /panel` — HUD page (add `?pc=1` for the PC panel window, `?embed=1&api=<base>` inside the phone app).

`GET /api/panel` — `{want, open, supported, fullscreen, monitor, autostart, sys:{cpu,ram}}`. `supported` is true only inside the desktop app (it owns the window).

`POST /api/panel` — `{"action":"on|off|toggle|fullscreen|settings"}`; `settings` also accepts `fullscreen`, `autostart`, `monitor` (-1 = auto).
