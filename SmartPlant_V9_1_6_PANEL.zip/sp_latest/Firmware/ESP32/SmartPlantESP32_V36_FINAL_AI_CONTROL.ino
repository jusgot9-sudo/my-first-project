#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include <DHT.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <ESPmDNS.h>
#include <WiFiUdp.h>
#include <math.h>

// ============================================================================
// SMART PLANT IRRIGATION SYSTEM
// ESP32 = MAIN NETWORK + SENSOR CONTROLLER
// Arduino UNO = RELAY BRIDGE (D7)
//
// NETWORK ARCHITECTURE (FINAL)
//   Phone -> SAME Wi-Fi -> ESP32
//   PC    -> SAME Wi-Fi -> ESP32
//
// No PC server is required between the phone/PC and the ESP32.
// ESP32 exposes HTTP API on port 80 and UDP discovery on port 4210.
// ============================================================================

const char* PROJECT_NAME = "Smart Plant Irrigation System";
const char* DEVELOPER    = "Tharusha";
const char* BOARD_NAME   = "Smart Plant ESP32";
const char* FIRMWARE     = "4.1-ALL-SENSORS-UNO-D7-DIRECT-WIFI";
const char* BUILD_TAG    = "STA-DHCP-UDP4210-HTTP80-UART2-UNO-D7";

// ============================================================================
// WIFI
// ============================================================================
// IMPORTANT: replace these two values with your real router credentials.
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// DHCP is preferred: PC and Android discover the current ESP32 IP automatically.
#define USE_STATIC_IP 0

IPAddress STATIC_IP      (192, 168, 1, 64);
IPAddress STATIC_GATEWAY (192, 168, 1, 1);
IPAddress STATIC_SUBNET  (255, 255, 255, 0);
IPAddress STATIC_DNS1    (8, 8, 8, 8);
IPAddress STATIC_DNS2    (1, 1, 1, 1);

const char* MDNS_HOSTNAME = "smartplant";

// ============================================================================
// UDP AUTO DISCOVERY
// ============================================================================
const uint16_t DISCOVERY_PORT = 4210;
const char* DISCOVERY_REQUEST = "SMARTPLANT_DISCOVER_V2";

// ============================================================================
// SENSOR ENABLES
// Set to 1 because this final sketch is the ALL-SENSORS version.
// A sensor that returns an invalid reading is reported as null / --.
// No synthetic/fake sensor values are generated.
// ============================================================================
#define ENABLE_SOIL_SENSOR    1
#define ENABLE_WATER_SENSOR   1
#define ENABLE_MQ2_SENSOR     1
#define ENABLE_DHT11_SENSOR   1
#define ENABLE_DS18B20_SENSOR 1

// MQ-2 needs heater warm-up before the reading is considered valid.
const unsigned long MQ2_WARMUP_MS = 60000UL;

// Pump safety.
const uint16_t MAX_PUMP_SECONDS = 600; // 10 minutes hard maximum
const float MIN_WATER_FOR_PUMP  = 20.0f;
const float AUTO_START_SOIL     = 30.0f;
const float AUTO_STOP_SOIL      = 60.0f;

// ============================================================================
// ESP32 GPIO MAP - DevKit 38 pin
// ============================================================================
const int PIN_DHT       = 4;
const int PIN_SOIL      = 34;  // ADC1
const int PIN_WATER     = 35;  // ADC1
const int PIN_MQ2       = 32;  // ADC1
const int PIN_DS18B20   = 33;

// ESP32 UART2 <-> UNO SoftwareSerial
// ESP32 TX2 GPIO17 -> UNO D10 (RX)
// ESP32 RX2 GPIO16 <- UNO D11 (TX) through a 5V->3.3V divider/level shifter.
const int PIN_UNO_TX = 17;
const int PIN_UNO_RX = 16;
const unsigned long UNO_BAUD = 9600;

// ============================================================================
// CALIBRATION START VALUES
// Recalibrate these with the real sensors for best accuracy.
// ============================================================================
const int SOIL_DRY_RAW    = 3200;
const int SOIL_WET_RAW    = 1400;
const int WATER_EMPTY_RAW = 1500;
const int WATER_FULL_RAW  = 3000;
const int MQ2_CLEAN_RAW   = 500;
const int MQ2_ALERT_RAW   = 2500;

// ============================================================================
// OBJECTS
// ============================================================================
DHT dht(PIN_DHT, DHT11);
OneWire oneWire(PIN_DS18B20);
DallasTemperature ds18b20(&oneWire);
WebServer server(80);
WiFiUDP discoveryUdp;
HardwareSerial UnoSerial(2);

// ============================================================================
// STATE
// ============================================================================
bool pumpOn = false;          // updated from UNO acknowledgement
bool autoMode = true;
bool pumpCommandPending = false;
bool unoOnline = false;

bool dhtReady = false;
bool ds18b20Ready = false;
bool discoveryStarted = false;
bool mdnsStarted = false;
unsigned long lastMdnsAttemptMs = 0;
bool webServerStarted = false;

float soilPct      = NAN;
float temperatureC = NAN;
float humidityPct  = NAN;
float waterPct     = NAN;
float gasLevelPct  = NAN;
float waterTempC   = NAN;

int soilRaw  = 0;
int waterRaw = 0;
int mq2Raw   = 0;

bool waterTempValid = false;
int ds18b20DeviceCount = 0;

unsigned long bootMs = 0;
unsigned long pumpStartedMs = 0;
unsigned long pumpUntilMs = 0;
unsigned long lastSensorMs = 0;
unsigned long lastDhtMs = 0;
unsigned long lastDsRequestMs = 0;
unsigned long dsConversionStartedMs = 0;
unsigned long lastDsScanMs = 0;
unsigned long lastWiFiCheckMs = 0;
unsigned long lastDiscoveryRestartMs = 0;
unsigned long lastUnoStatusMs = 0;
unsigned long lastUnoHeartbeatMs = 0;
unsigned long lastAutoMs = 0;
unsigned long lastLogMs = 0;
unsigned long mq2WarmupStartedMs = 0;

bool dsConversionPending = false;

// ============================================================================
// HELPERS
// ============================================================================
float mapFloat(float x, float inMin, float inMax, float outMin, float outMax) {
  if (fabsf(inMax - inMin) < 0.0001f) return outMin;
  return (x - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;
}

float soilFromRaw(int raw) {
  return constrain(mapFloat(raw, SOIL_DRY_RAW, SOIL_WET_RAW, 0.0f, 100.0f), 0.0f, 100.0f);
}

float waterFromRaw(int raw) {
  return constrain(mapFloat(raw, WATER_EMPTY_RAW, WATER_FULL_RAW, 0.0f, 100.0f), 0.0f, 100.0f);
}

float gasFromRaw(int raw) {
  return constrain(mapFloat(raw, MQ2_CLEAN_RAW, MQ2_ALERT_RAW, 0.0f, 100.0f), 0.0f, 100.0f);
}

int readAveragedADC(int pin, uint8_t samples = 8) {
  long total = 0;
  for (uint8_t i = 0; i < samples; ++i) {
    total += analogRead(pin);
    delayMicroseconds(500);
  }
  return (int)(total / samples);
}

// Rail values usually indicate an open/shorted ADC input rather than a valid
// calibrated sensor value. This is not a perfect electrical presence detector;
// correct wiring is still required for analog sensors.
bool adcValueLooksValid(int raw) {
  return raw > 3 && raw < 4092;
}

bool pumpSafetyAllowsOn() {
#if ENABLE_WATER_SENSOR
  return !isnan(waterPct) && waterPct > MIN_WATER_FOR_PUMP;
#else
  return false;
#endif
}

// ============================================================================
// RESET REASON
// ============================================================================
const char* getResetReason() {
  switch (esp_reset_reason()) {
    case ESP_RST_POWERON:      return "POWER ON";
    case ESP_RST_EXT:          return "EXTERNAL RESET";
    case ESP_RST_SW:           return "SOFTWARE RESET";
    case ESP_RST_PANIC:        return "PANIC / CRASH";
    case ESP_RST_INT_WDT:      return "INTERRUPT WATCHDOG";
    case ESP_RST_TASK_WDT:     return "TASK WATCHDOG";
    case ESP_RST_WDT:          return "WATCHDOG";
    case ESP_RST_DEEPSLEEP:    return "DEEP SLEEP";
    case ESP_RST_BROWNOUT:     return "BROWNOUT / POWER";
    case ESP_RST_SDIO:         return "SDIO RESET";
    default:                   return "UNKNOWN";
  }
}

// ============================================================================
// ESP32 <-> UNO SERIAL
// ============================================================================
void sendUnoCommand(const char* command) {
  UnoSerial.print(command);
  UnoSerial.print('\n');
  Serial.print("[UNO TX] ");
  Serial.println(command);
}

void serviceUnoSerial() {
  static String line;

  while (UnoSerial.available() > 0) {
    char c = (char)UnoSerial.read();
    if (c == '\r') continue;

    if (c == '\n') {
      line.trim();
      if (line.length() > 0) {
        Serial.print("[UNO RX] ");
        Serial.println(line);

        if (line == "READY" || line == "HEARTBEAT" || line.startsWith("UNO_STATUS")) {
          unoOnline = true;
          lastUnoHeartbeatMs = millis();
          int eq = line.indexOf("pump=");
          if (line.startsWith("UNO_STATUS") && eq >= 0) {
            String v = line.substring(eq + 5);
            v.trim();
            pumpOn = v.startsWith("ON");
            pumpCommandPending = false;
          }
        }

        if (line == "RELAY=ON" || line == "OK RELAY_ON") {
          pumpOn = true;
          pumpCommandPending = false;
          unoOnline = true;
          lastUnoHeartbeatMs = millis();
          if (pumpStartedMs == 0) pumpStartedMs = millis();
        }

        if (line == "RELAY=OFF" || line == "OK RELAY_OFF") {
          pumpOn = false;
          pumpCommandPending = false;
          unoOnline = true;
          lastUnoHeartbeatMs = millis();
          pumpStartedMs = 0;
          pumpUntilMs = 0;
        }
      }
      line = "";
    } else if (line.length() < 120) {
      line += c;
    } else {
      line = "";
    }
  }

  if (unoOnline && millis() - lastUnoHeartbeatMs > 12000UL) {
    unoOnline = false;
    pumpOn = false;
    pumpCommandPending = false;
    pumpStartedMs = 0;
    pumpUntilMs = 0;
  }

  if (millis() - lastUnoStatusMs >= 7000UL) {
    lastUnoStatusMs = millis();
    sendUnoCommand("STATUS");
  }
}

bool sendPumpCommand(bool on, uint16_t seconds = 0) {
  if (!unoOnline) {
    sendUnoCommand("STATUS");
    return false;
  }

  if (on && pumpCommandPending) return true;

  if (!on) {
    pumpUntilMs = 0;
    pumpCommandPending = false;
    sendUnoCommand("PUMP_OFF");
    return true;
  }

  if (!pumpSafetyAllowsOn()) {
    Serial.println("[SAFETY] Pump blocked: water sensor invalid/low.");
    return false;
  }

  seconds = (uint16_t)constrain((int)seconds, 1, (int)MAX_PUMP_SECONDS);
  pumpUntilMs = millis() + ((unsigned long)seconds * 1000UL);

  String command = "PUMP_ON ";
  command += seconds;
  sendUnoCommand(command.c_str());
  pumpCommandPending = true;
  return true;
}

void servicePumpTimer() {
  if (!pumpOn) return;

  // Hard safety cap even if UNO is not answering.
  if (pumpStartedMs > 0 && millis() - pumpStartedMs >= (MAX_PUMP_SECONDS * 1000UL)) {
    sendUnoCommand("PUMP_OFF");
    pumpOn = false;
    pumpUntilMs = 0;
    pumpStartedMs = 0;
    return;
  }

  if (pumpUntilMs != 0 && (long)(millis() - pumpUntilMs) >= 0) {
    sendUnoCommand("PUMP_OFF");
  }

#if ENABLE_WATER_SENSOR
  if (!pumpSafetyAllowsOn()) {
    sendUnoCommand("PUMP_OFF");
  }
#endif
}

// ============================================================================
// SENSOR SERVICE
// ============================================================================
void scanDS18B20() {
#if ENABLE_DS18B20_SENSOR
  if (!ds18b20Ready) return;
  int count = ds18b20.getDeviceCount();
  if (count != ds18b20DeviceCount) {
    ds18b20DeviceCount = count;
    Serial.print("[DS18B20] Devices: ");
    Serial.println(ds18b20DeviceCount);
  }
#else
  ds18b20DeviceCount = 0;
#endif
}

void serviceDS18B20() {
#if ENABLE_DS18B20_SENSOR
  if (!ds18b20Ready) return;

  const unsigned long now = millis();

  if (now - lastDsScanMs >= 5000UL) {
    lastDsScanMs = now;
    scanDS18B20();
  }

  if (dsConversionPending && now - dsConversionStartedMs >= 750UL) {
    float value = ds18b20.getTempCByIndex(0);
    if (value != DEVICE_DISCONNECTED_C && value > -55.0f && value < 125.0f) {
      waterTempC = value;
      waterTempValid = true;
    } else {
      waterTempC = NAN;
      waterTempValid = false;
    }
    dsConversionPending = false;
  }

  if (!dsConversionPending && ds18b20DeviceCount > 0 && now - lastDsRequestMs >= 1000UL) {
    lastDsRequestMs = now;
    ds18b20.requestTemperatures();
    dsConversionStartedMs = now;
    dsConversionPending = true;
  }
#else
  waterTempC = NAN;
  waterTempValid = false;
  ds18b20DeviceCount = 0;
#endif
}

void readDHTSensor() {
#if ENABLE_DHT11_SENSOR
  if (!dhtReady) return;
  const unsigned long now = millis();
  if (now - lastDhtMs < 2200UL) return;
  lastDhtMs = now;

  float t = dht.readTemperature();
  float h = dht.readHumidity();

  if (!isnan(t) && t > -40.0f && t < 85.0f) temperatureC = t;
  else temperatureC = NAN;

  if (!isnan(h) && h >= 0.0f && h <= 100.0f) humidityPct = h;
  else humidityPct = NAN;
#else
  temperatureC = NAN;
  humidityPct = NAN;
#endif
}

void readAnalogSensors() {
#if ENABLE_SOIL_SENSOR
  soilRaw = readAveragedADC(PIN_SOIL);
  soilPct = adcValueLooksValid(soilRaw) ? soilFromRaw(soilRaw) : NAN;
#else
  soilRaw = 0;
  soilPct = NAN;
#endif

#if ENABLE_WATER_SENSOR
  waterRaw = readAveragedADC(PIN_WATER);
  waterPct = adcValueLooksValid(waterRaw) ? waterFromRaw(waterRaw) : NAN;
#else
  waterRaw = 0;
  waterPct = NAN;
#endif

#if ENABLE_MQ2_SENSOR
  mq2Raw = readAveragedADC(PIN_MQ2);
  if (millis() - mq2WarmupStartedMs < MQ2_WARMUP_MS) {
    gasLevelPct = NAN;
  } else {
    gasLevelPct = adcValueLooksValid(mq2Raw) ? gasFromRaw(mq2Raw) : NAN;
  }
#else
  mq2Raw = 0;
  gasLevelPct = NAN;
#endif
}

void readAllSensors() {
  readAnalogSensors();
  readDHTSensor();
  serviceDS18B20();
}

// ============================================================================
// AUTO IRRIGATION
// ============================================================================
void serviceAutoIrrigation() {
  if (!autoMode) return;
  if (millis() - lastAutoMs < 1000UL) return;
  lastAutoMs = millis();

  if (isnan(soilPct) || isnan(waterPct) || !unoOnline) {
    if (pumpOn) sendUnoCommand("PUMP_OFF");
    return;
  }

  if (waterPct <= MIN_WATER_FOR_PUMP) {
    if (pumpOn) sendUnoCommand("PUMP_OFF");
    return;
  }

  if (!pumpOn && !pumpCommandPending && soilPct < AUTO_START_SOIL) {
    // Auto run is also capped at 10 minutes. Soil >= AUTO_STOP_SOIL stops it earlier.
    sendPumpCommand(true, MAX_PUMP_SECONDS);
    return;
  }

  if (pumpOn && soilPct >= AUTO_STOP_SOIL) {
    pumpCommandPending = false;
    sendUnoCommand("PUMP_OFF");
  }
}

// ============================================================================
// JSON STATE
// ============================================================================
String jsonState() {
  JsonDocument doc;

  doc["ok"] = true;
  doc["project"] = PROJECT_NAME;
  doc["developer"] = DEVELOPER;
  doc["board_name"] = BOARD_NAME;
  doc["board_type"] = "ESP32 DevKit 38-pin + Arduino UNO relay D7";
  doc["firmware"] = FIRMWARE;
  doc["build_tag"] = BUILD_TAG;

  if (isnan(soilPct)) doc["soil"] = nullptr; else doc["soil"] = soilPct;
  if (isnan(temperatureC)) doc["temperature"] = nullptr; else doc["temperature"] = temperatureC;
  if (isnan(humidityPct)) doc["humidity"] = nullptr; else doc["humidity"] = humidityPct;
  if (isnan(waterPct)) doc["water"] = nullptr; else doc["water"] = waterPct;
  if (isnan(gasLevelPct)) { doc["gas"] = nullptr; doc["air_quality"] = nullptr; }
  else { doc["gas"] = gasLevelPct; doc["air_quality"] = gasLevelPct; }
  if (waterTempValid) doc["water_temp"] = waterTempC; else doc["water_temp"] = nullptr;
  if (isnan(waterPct)) doc["water_level"] = nullptr; else doc["water_level"] = waterPct;

  doc["soil_raw"] = soilRaw;
  doc["water_raw"] = waterRaw;
  doc["mq2_raw"] = mq2Raw;
  doc["ds18b20_devices"] = ds18b20DeviceCount;

  doc["pump"] = pumpOn;
  doc["pump_command_pending"] = pumpCommandPending;
  doc["auto_mode"] = autoMode;
  doc["uno_ready"] = unoOnline;
  doc["relay_mcu"] = "Arduino UNO";
  doc["relay_pin"] = "D7";
  doc["relay_active_low"] = true;

  unsigned long remaining = 0;
  if (pumpOn && pumpUntilMs != 0 && (long)(pumpUntilMs - millis()) > 0) {
    remaining = pumpUntilMs - millis();
  }
  doc["pump_seconds"] = (remaining + 999UL) / 1000UL;
  doc["max_pump_seconds"] = MAX_PUMP_SECONDS;
  doc["water_safety_min_pct"] = MIN_WATER_FOR_PUMP;

  bool wifiConnected = WiFi.status() == WL_CONNECTED;
  doc["wifi"] = wifiConnected;
  doc["connected"] = wifiConnected;
  doc["board_online"] = wifiConnected;
  doc["last_seen"] = wifiConnected ? "live" : "offline";
  doc["controller_transport"] = "WiFi STA";
  doc["wifi_mode"] = "STA_ONLY";

  if (wifiConnected) {
    doc["ip"] = WiFi.localIP().toString();
    doc["gateway"] = WiFi.gatewayIP().toString();
    doc["subnet"] = WiFi.subnetMask().toString();
    doc["ssid"] = WiFi.SSID();
    doc["rssi"] = WiFi.RSSI();
  } else {
    doc["ip"] = "";
    doc["gateway"] = "";
    doc["subnet"] = "";
    doc["ssid"] = "";
    doc["rssi"] = 0;
  }

  unsigned long mq2WarmupSec = (millis() - mq2WarmupStartedMs) / 1000UL;
  if (mq2WarmupSec > 60UL) mq2WarmupSec = 60UL;
  doc["mq2_warmup_sec"] = mq2WarmupSec;
  doc["mq2_ready"] = (mq2WarmupSec >= 60UL);

  // Explicit physical-channel state. These describe the configured channels;
  // invalid readings still remain null instead of being replaced with fake data.
  doc["sensors"]["soil"]["enabled"] = ENABLE_SOIL_SENSOR;
  doc["sensors"]["soil"]["valid"] = !isnan(soilPct);
  doc["sensors"]["water"]["enabled"] = ENABLE_WATER_SENSOR;
  doc["sensors"]["water"]["valid"] = !isnan(waterPct);
  doc["sensors"]["mq2"]["enabled"] = ENABLE_MQ2_SENSOR;
  doc["sensors"]["mq2"]["valid"] = !isnan(gasLevelPct);
  doc["sensors"]["dht11"]["enabled"] = ENABLE_DHT11_SENSOR;
  doc["sensors"]["dht11"]["valid"] = !isnan(temperatureC) && !isnan(humidityPct);
  doc["sensors"]["ds18b20"]["enabled"] = ENABLE_DS18B20_SENSOR;
  doc["sensors"]["ds18b20"]["valid"] = waterTempValid;

  String output;
  serializeJson(doc, output);
  return output;
}

// ============================================================================
// HTTP / CORS
// ============================================================================
void sendCORS() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type, X-Board-Token");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Cache-Control", "no-store");
}

void handleRoot() {
  sendCORS();
  String msg;
  msg.reserve(700);
  msg += "Smart Plant ESP32 online\n";
  msg += "Project: " + String(PROJECT_NAME) + "\n";
  msg += "Developer: " + String(DEVELOPER) + "\n";
  msg += "Board: " + String(BOARD_NAME) + "\n";
  msg += "Firmware: " + String(FIRMWARE) + "\n";
  msg += "Network: Phone/PC -> Same Wi-Fi -> ESP32\n";
  if (WiFi.status() == WL_CONNECTED) {
    msg += "IP: " + WiFi.localIP().toString() + "\n";
  }
  msg += "API: /api/state  /api/control  /api/health\n";
  server.send(200, "text/plain; charset=utf-8", msg);
}

void handleState() {
  sendCORS();
  server.send(200, "application/json; charset=utf-8", jsonState());
}

void handleHealth() {
  sendCORS();
  JsonDocument doc;
  doc["ok"] = true;
  bool wifiConnected = WiFi.status() == WL_CONNECTED;
  doc["board_connected"] = wifiConnected;
  doc["wifi"] = wifiConnected;
  doc["uno_ready"] = unoOnline;
  doc["ip"] = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : "";
  doc["name"] = BOARD_NAME;
  doc["firmware"] = FIRMWARE;
  String out;
  serializeJson(doc, out);
  server.send(200, "application/json; charset=utf-8", out);
}

void handleControl() {
  sendCORS();

  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"ok\":false,\"error\":\"JSON body required\"}");
    return;
  }

  JsonDocument doc;
  DeserializationError error = deserializeJson(doc, server.arg("plain"));
  if (error) {
    server.send(400, "application/json", "{\"ok\":false,\"error\":\"Invalid JSON\"}");
    return;
  }

  const char* action = doc["action"] | "";

  if (strcmp(action, "pump_on") == 0) {
    if (!unoOnline) {
      sendUnoCommand("STATUS");
      server.send(503, "application/json", "{\"ok\":false,\"error\":\"UNO relay bridge not connected\"}");
      return;
    }

    if (!pumpSafetyAllowsOn()) {
      server.send(409, "application/json", "{\"ok\":false,\"error\":\"Pump blocked: water level is low or unavailable\"}");
      return;
    }

    int seconds = doc["seconds"] | 60;
    if (seconds <= 0) seconds = 60;
    if (seconds > (int)MAX_PUMP_SECONDS) seconds = MAX_PUMP_SECONDS;

    if (!sendPumpCommand(true, (uint16_t)seconds)) {
      server.send(503, "application/json", "{\"ok\":false,\"error\":\"Pump command could not be sent\"}");
      return;
    }

    JsonDocument reply;
    reply["ok"] = true;
    reply["accepted"] = true;
    reply["pump"] = pumpOn;
    reply["auto_mode"] = autoMode;
    reply["seconds_requested"] = seconds;
    reply["note"] = "Waiting for UNO relay acknowledgement";
    reply["uno_ready"] = unoOnline;
    String out;
    serializeJson(reply, out);
    server.send(202, "application/json", out);
    return;
  }

  if (strcmp(action, "pump_off") == 0) {
    if (!unoOnline) {
      sendUnoCommand("STATUS");
      server.send(503, "application/json", "{\"ok\":false,\"error\":\"UNO relay bridge not connected\"}");
      return;
    }
    sendUnoCommand("PUMP_OFF");
    server.send(202, "application/json", "{\"ok\":true,\"accepted\":true,\"command\":\"PUMP_OFF\"}");
    return;
  }

  if (strcmp(action, "auto_on") == 0) {
    autoMode = true;
    server.send(200, "application/json", "{\"ok\":true,\"auto_mode\":true}");
    return;
  }

  if (strcmp(action, "auto_off") == 0) {
    autoMode = false;
    if (unoOnline && pumpOn) sendUnoCommand("PUMP_OFF");
    server.send(200, "application/json", "{\"ok\":true,\"auto_mode\":false}");
    return;
  }

  server.send(400, "application/json", "{\"ok\":false,\"error\":\"Unknown action\"}");
}

void handleOptions() {
  sendCORS();
  server.send(204, "text/plain", "");
}

// ============================================================================
// WIFI
// ============================================================================
bool connectToWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.persistent(false);
  WiFi.setHostname(MDNS_HOSTNAME);

#if USE_STATIC_IP
  WiFi.config(STATIC_IP, STATIC_GATEWAY, STATIC_SUBNET, STATIC_DNS1, STATIC_DNS2);
#endif

  Serial.print("[WiFi] Connecting to: ");
  Serial.println(WIFI_SSID);

  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 20000UL) {
    delay(400);
    Serial.print('.');
  }
  Serial.println();

  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[WiFi] Initial connection failed; automatic retry will continue.");
    return false;
  }

  WiFi.setSleep(false);
  Serial.print("[WiFi] IP: ");
  Serial.println(WiFi.localIP());
  Serial.print("[WiFi] Gateway: ");
  Serial.println(WiFi.gatewayIP());
  Serial.print("[WiFi] RSSI: ");
  Serial.println(WiFi.RSSI());
  return true;
}

void serviceWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  if (millis() - lastWiFiCheckMs >= 5000UL) {
    lastWiFiCheckMs = millis();
    Serial.println("[WiFi] Connection lost. Reconnecting...");
    discoveryUdp.stop();
    discoveryStarted = false;
    WiFi.reconnect();
  }
}

// ============================================================================
// DISCOVERY
// ============================================================================
void startDiscoveryService() {
  if (WiFi.status() != WL_CONNECTED || discoveryStarted) return;

  if (discoveryUdp.begin(DISCOVERY_PORT)) {
    discoveryStarted = true;
    Serial.print("[DISCOVERY] UDP port ");
    Serial.println(DISCOVERY_PORT);
  } else {
    Serial.println("[DISCOVERY] UDP start failed; HTTP/TCP fallback remains available.");
  }
}

void serviceDiscovery() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!discoveryStarted) startDiscoveryService();
  if (!discoveryStarted) return;

  int packetSize = discoveryUdp.parsePacket();
  if (packetSize <= 0) return;

  char buffer[128];
  int len = discoveryUdp.read(buffer, sizeof(buffer) - 1);
  if (len <= 0) return;
  buffer[len] = '\0';

  String request(buffer);
  request.trim();
  if (request != DISCOVERY_REQUEST) return;

  String response;
  response.reserve(220);
  response += "SMARTPLANT_DISCOVER_V2|";
  response += WiFi.localIP().toString();
  response += "|";
  response += BOARD_NAME;
  response += "|";
  response += FIRMWARE;

  discoveryUdp.beginPacket(discoveryUdp.remoteIP(), discoveryUdp.remotePort());
  discoveryUdp.print(response);
  discoveryUdp.endPacket();
}

// ============================================================================
// WEB SERVER
// ============================================================================
void startWebServer() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/state", HTTP_GET, handleState);
  server.on("/api/health", HTTP_GET, handleHealth);
  server.on("/api/control", HTTP_POST, handleControl);
  server.on("/api/state", HTTP_OPTIONS, handleOptions);
  server.on("/api/control", HTTP_OPTIONS, handleOptions);
  server.begin();
  webServerStarted = true;
  Serial.println("[WEB] HTTP server ready on port 80");
}

void startMDNS() {
  if (WiFi.status() != WL_CONNECTED || mdnsStarted) return;
  if (MDNS.begin(MDNS_HOSTNAME)) {
    mdnsStarted = true;
    MDNS.addService("http", "tcp", 80);
    Serial.println("[mDNS] http://smartplant.local");
  }
}

void serviceMDNS() {
  if (WiFi.status() != WL_CONNECTED) {
    if (mdnsStarted) {
      MDNS.end();
      mdnsStarted = false;
    }
    return;
  }
  if (!mdnsStarted && millis() - lastMdnsAttemptMs >= 5000UL) {
    lastMdnsAttemptMs = millis();
    startMDNS();
  }
}

// ============================================================================
// SERIAL DEBUG
// ============================================================================
void printPeriodicDebug() {
  if (millis() - lastLogMs < 5000UL) return;
  lastLogMs = millis();

  Serial.println("---------------- SMART PLANT ----------------");
  Serial.print("WiFi: "); Serial.print(WiFi.status() == WL_CONNECTED ? "CONNECTED" : "OFFLINE");
  Serial.print("  IP: "); Serial.println(WiFi.localIP());
  Serial.print("UNO: "); Serial.println(unoOnline ? "READY" : "WAITING");
  Serial.print("Soil: "); if (isnan(soilPct)) Serial.println("--"); else { Serial.print(soilPct, 1); Serial.println(" %"); }
  Serial.print("Water: "); if (isnan(waterPct)) Serial.println("--"); else { Serial.print(waterPct, 1); Serial.println(" %"); }
  Serial.print("MQ2: "); if (isnan(gasLevelPct)) Serial.println("--"); else { Serial.print(gasLevelPct, 1); Serial.println(" %"); }
  Serial.print("DHT Temp: "); if (isnan(temperatureC)) Serial.println("--"); else { Serial.print(temperatureC, 1); Serial.println(" C"); }
  Serial.print("DHT Hum: "); if (isnan(humidityPct)) Serial.println("--"); else { Serial.print(humidityPct, 1); Serial.println(" %"); }
  Serial.print("DS18B20: "); if (!waterTempValid) Serial.println("--"); else { Serial.print(waterTempC, 1); Serial.println(" C"); }
  Serial.print("Pump: "); Serial.println(pumpOn ? "ON" : "OFF");
  Serial.print("Auto: "); Serial.println(autoMode ? "ON" : "OFF");
  if (millis() - mq2WarmupStartedMs < MQ2_WARMUP_MS) {
    Serial.print("MQ2 warmup remaining: ");
    Serial.print((MQ2_WARMUP_MS - (millis() - mq2WarmupStartedMs)) / 1000UL);
    Serial.println(" s");
  }
  Serial.println("----------------------------------------------");
}

// ============================================================================
// SETUP
// ============================================================================
void setup() {
  bootMs = millis();
  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("================================================");
  Serial.println(" SMART PLANT IRRIGATION SYSTEM - ESP32 FINAL");
  Serial.println("================================================");
  Serial.print("Firmware: "); Serial.println(FIRMWARE);
  Serial.print("Reset: "); Serial.println(getResetReason());

  // UART2 to UNO
  UnoSerial.begin(UNO_BAUD, SERIAL_8N1, PIN_UNO_RX, PIN_UNO_TX);
  Serial.println("[UNO] UART2 started: ESP32 TX17/RX16 @ 9600");

  // ADC
  analogReadResolution(12);
  analogSetPinAttenuation(PIN_SOIL, ADC_11db);
  analogSetPinAttenuation(PIN_WATER, ADC_11db);
  analogSetPinAttenuation(PIN_MQ2, ADC_11db);

  // DHT11
  dht.begin();
  dhtReady = true;
  Serial.println("[DHT11] GPIO4 ready");

  // DS18B20
  ds18b20.begin();
  ds18b20.setResolution(10);
  ds18b20.setWaitForConversion(false);
  ds18b20Ready = true;
  scanDS18B20();
  Serial.print("[DS18B20] GPIO33 devices: ");
  Serial.println(ds18b20DeviceCount);

  // MQ2 warm-up
  mq2WarmupStartedMs = millis();
  Serial.println("[MQ2] GPIO32 warm-up started (60 s)");

  // Wi-Fi
  bool wifiOK = connectToWiFi();
  startWebServer();
  if (wifiOK) {
    startDiscoveryService();
    startMDNS();
  }

  // Ask UNO for status after boot.
  sendUnoCommand("STATUS");

  Serial.println("================================================");
  Serial.println("ESP32 READY");
  Serial.println("Phone + PC must join the SAME Wi-Fi as ESP32");
  Serial.println("================================================");
}

// ============================================================================
// LOOP
// ============================================================================
void loop() {
  if (webServerStarted) server.handleClient();

  serviceUnoSerial();
  serviceWiFi();
  serviceMDNS();

  if (WiFi.status() == WL_CONNECTED) {
    startDiscoveryService();
    serviceDiscovery();
  }

  if (millis() - lastSensorMs >= 1000UL) {
    lastSensorMs = millis();
    readAllSensors();
  }

  serviceDS18B20();
  servicePumpTimer();
  serviceAutoIrrigation();
  printPeriodicDebug();

  // Re-start discovery after a reconnect.
  if (WiFi.status() == WL_CONNECTED && !discoveryStarted && millis() - lastDiscoveryRestartMs >= 2000UL) {
    lastDiscoveryRestartMs = millis();
    startDiscoveryService();
  }

  delay(2);
}
