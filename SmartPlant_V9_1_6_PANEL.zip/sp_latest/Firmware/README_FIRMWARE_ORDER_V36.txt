SMART PLANT FIRMWARE ORDER - V36 FINAL

USE THESE TWO FILES FOR NEW BUILDS:

1) ESP32 MAIN CONTROLLER
   Firmware/ESP32/SmartPlantESP32_V36_FINAL_AI_CONTROL.ino
   - Wi-Fi STA + auto discovery
   - HTTP API for PC/Phone
   - DHT11, soil moisture, water level, MQ-2, DS18B20
   - safety and automatic irrigation
   - Arduino UNO relay bridge communication

2) ARDUINO UNO RELAY BRIDGE
   Firmware/ArduinoUNO/SmartPlant_ArduinoUNO_D7_RELAY_V36_FINAL.ino
   - Relay output: D7
   - ESP32 serial receive: D10
   - UNO serial transmit: D11

NETWORK (MANDATORY):
Phone -> Same Wi-Fi -> ESP32
PC    -> Same Wi-Fi -> ESP32

SERIAL:
ESP32 GPIO17 TX -> UNO D10 RX
UNO D11 TX -> ESP32 GPIO16 RX through a proper 5V-to-3.3V level shifter/divider
GND must be common.

LEGACY COPIES:
Firmware/Legacy/
Do not use legacy copies for a new upload.
