LEGACY FIRMWARE COPIES - V36

Do not upload these files for a new build.
Use the canonical files only:

ESP32:
  Firmware/ESP32/SmartPlantESP32_V36_FINAL_AI_CONTROL.ino

Arduino UNO:
  Firmware/ArduinoUNO/SmartPlant_ArduinoUNO_D7_RELAY_V36_FINAL.ino

The legacy copies are retained only for compatibility/reference.
