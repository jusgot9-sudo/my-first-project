#include <Arduino.h>
#include <SoftwareSerial.h>

// ============================================================================
// SMART PLANT IRRIGATION SYSTEM - ARDUINO UNO RELAY BRIDGE
//
// Network architecture (fixed):
//   Phone -> Same Wi-Fi -> ESP32
//   PC    -> Same Wi-Fi -> ESP32
//
// UNO is only a local relay controller. It has NO Wi-Fi role.
// Relay output: D7 (active-low by default)
// ESP32 UART2: GPIO17 TX -> UNO D10 RX
// UNO D11 TX -> ESP32 GPIO16 RX THROUGH A 5V->3.3V LEVEL SHIFTER/DIVIDER
// GND must be common.
// ============================================================================

const uint8_t RELAY_PIN = 7;
const bool RELAY_ACTIVE_LOW = true;

const uint8_t ESP32_UART_RX_PIN = 10; // UNO RX from ESP32 TX GPIO17
const uint8_t ESP32_UART_TX_PIN = 11; // UNO TX to ESP32 RX GPIO16 (level-shift)
const unsigned long UART_BAUD = 9600UL;

const unsigned long MAX_PUMP_MS = 600000UL; // 10 min hardware backstop
const unsigned long HEARTBEAT_MS = 5000UL;
const size_t CMD_BUFFER_SIZE = 48;

SoftwareSerial Esp32Serial(ESP32_UART_RX_PIN, ESP32_UART_TX_PIN);

bool pumpOn = false;
unsigned long pumpUntilMs = 0;
unsigned long lastHeartbeatMs = 0;
char cmdBuffer[CMD_BUFFER_SIZE];
size_t cmdLen = 0;

void relayWrite(bool on) {
  pumpOn = on;
  const uint8_t level = RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW);
  digitalWrite(RELAY_PIN, level);
  if (!on) pumpUntilMs = 0;
}

void printStatus() {
  Esp32Serial.print(F("UNO_STATUS pump="));
  Esp32Serial.println(pumpOn ? F("ON") : F("OFF"));
}

void processCommand(char *line) {
  while (*line == ' ' || *line == '\t') line++;
  for (char *p = line; *p; ++p) {
    if (*p >= 'a' && *p <= 'z') *p = char(*p - 'a' + 'A');
  }
  if (*line == '\0') return;

  if (!strcmp(line, "STATUS") || !strcmp(line, "PING")) {
    printStatus();
    return;
  }

  if (!strcmp(line, "PUMP_OFF") || !strcmp(line, "RELAY_OFF")) {
    relayWrite(false);
    Esp32Serial.println(F("RELAY=OFF"));
    return;
  }

  if (!strcmp(line, "RELAY_ON")) {
    relayWrite(true);
    pumpUntilMs = millis() + MAX_PUMP_MS;
    Esp32Serial.println(F("RELAY=ON"));
    return;
  }

  if (!strncmp(line, "PUMP_ON", 7)) {
    unsigned long seconds = 60UL;
    char *arg = line + 7;
    while (*arg == ' ' || *arg == '\t') arg++;
    if (*arg) {
      unsigned long requested = strtoul(arg, NULL, 10);
      if (requested > 0UL) seconds = requested;
    }
    if (seconds > 600UL) seconds = 600UL;

    relayWrite(true);
    pumpUntilMs = millis() + seconds * 1000UL;
    Esp32Serial.println(F("RELAY=ON"));
    return;
  }

  Esp32Serial.println(F("ERR UNKNOWN_COMMAND"));
}

void serviceSerial() {
  while (Esp32Serial.available() > 0) {
    char c = (char)Esp32Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      cmdBuffer[cmdLen] = '\0';
      processCommand(cmdBuffer);
      cmdLen = 0;
      continue;
    }
    if (cmdLen < CMD_BUFFER_SIZE - 1U) {
      cmdBuffer[cmdLen++] = c;
    } else {
      cmdLen = 0; // discard an overlong/garbled command safely
    }
  }
}

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  relayWrite(false); // safe OFF at power-up

  Serial.begin(115200);
  Esp32Serial.begin(UART_BAUD);

  delay(300);
  Serial.println(F("SMART PLANT UNO RELAY BRIDGE READY"));
  Serial.println(F("Relay: D7 ACTIVE-LOW"));
  Serial.println(F("ESP32 UART: D10 RX / D11 TX @ 9600"));
  Esp32Serial.println(F("READY"));
  printStatus();
  lastHeartbeatMs = millis();
}

void loop() {
  serviceSerial();

  if (pumpOn && pumpUntilMs != 0UL && (long)(millis() - pumpUntilMs) >= 0L) {
    relayWrite(false);
    Esp32Serial.println(F("RELAY=OFF"));
  }

  if (millis() - lastHeartbeatMs >= HEARTBEAT_MS) {
    lastHeartbeatMs = millis();
    Esp32Serial.println(F("HEARTBEAT"));
  }
}
