"""Verify a SmartPlant source ZIP before sharing or releasing it.

Usage: python verify_zip.py SmartPlant_V9_1_3.zip
"""
from __future__ import annotations
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REQUIRED = {
    "sp_latest/PC_App/app.py",
    "sp_latest/PC_App/launcher.py",
    "sp_latest/PC_App/local_voice_engine.py",
    "sp_latest/PC_App/templates/dashboard.html",
    "sp_latest/PC_App/templates/panel.html",
    "sp_latest/PC_App/static/css/panel.css",
    "sp_latest/PC_App/static/js/panel.js",
    "sp_latest/PC_App/static/css/theme.css",
    "sp_latest/PC_App/static/css/app-shell.css",
    "sp_latest/PC_App/static/js/app.js",
    "sp_latest/PC_App/BUILD_PC_FINAL.bat",
    "sp_latest/Android_App/app/src/main/assets/ui/index.html",
    "sp_latest/Android_App/app/src/main/assets/ui/panel.html",
    "sp_latest/Android_App/app/src/main/assets/ui/css/panel.css",
    "sp_latest/Android_App/app/src/main/assets/ui/js/panel.js",
    "sp_latest/Android_App/app/src/main/assets/ui/css/theme.css",
    "sp_latest/Android_App/app/src/main/assets/ui/css/app-shell.css",
    "sp_latest/Android_App/app/src/main/assets/ui/js/app.js",
    "sp_latest/Installer/installer.py",
    "sp_latest/Installer/ui/index.html",
    "sp_latest/Installer/ui/css/style.css",
    "sp_latest/Installer/ui/js/main.js",
    "sp_latest/Installer/ui/img/logo.png",
    "sp_latest/build.py",
    "sp_latest/VERSION.txt",
    "sp_latest/.github/workflows/build.yml",
}
SECRET_PATTERNS = [re.compile(r"sk-[A-Za-z0-9_-]{20,}"), re.compile(r"x-manus-api-key\s*:\s*[A-Za-z0-9_-]{20,}", re.I)]

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: python verify_zip.py <archive.zip>", file=sys.stderr)
        return 2
    archive = Path(sys.argv[1])
    if not archive.is_file():
        print(f"ERROR: archive not found: {archive}", file=sys.stderr)
        return 1
    with zipfile.ZipFile(archive) as z:
        bad = z.testzip()
        if bad:
            print(f"ERROR: corrupt archive entry: {bad}", file=sys.stderr)
            return 1
        names = set(z.namelist())
        missing = sorted(REQUIRED - names)
        if missing:
            print("ERROR: missing required files:", *missing, sep="\n", file=sys.stderr)
            return 1
        if len(names) != len(z.namelist()):
            print("ERROR: duplicate ZIP entries detected", file=sys.stderr)
            return 1
        with tempfile.TemporaryDirectory(prefix="smartplant_zip_") as td:
            root = Path(td)
            z.extractall(root)
            source = root / "sp_latest"
            py_files = [source / "PC_App/app.py", source / "Installer/installer.py", source / "build.py", source / "verify_zip.py"]
            for path in py_files:
                compile(path.read_text(encoding="utf-8"), str(path), "exec")
            node = subprocess.run(["node", "--check", str(source / "PC_App/static/js/app.js")], capture_output=True, text=True)
            if node.returncode:
                raise RuntimeError(node.stderr.strip() or "PC JavaScript syntax check failed")
            node = subprocess.run(["node", "--check", str(source / "Android_App/app/src/main/assets/ui/js/app.js")], capture_output=True, text=True)
            if node.returncode:
                raise RuntimeError(node.stderr.strip() or "Android JavaScript syntax check failed")
            text_files = [p for p in source.rglob("*") if p.is_file() and p.suffix.lower() in {".py", ".js", ".html", ".css", ".md", ".bat"}]
            for path in text_files:
                text = path.read_text(encoding="utf-8", errors="ignore")
                if any(pattern.search(text) for pattern in SECRET_PATTERNS):
                    raise RuntimeError(f"possible API secret found in {path.relative_to(root)}")
    print(f"ZIP_VERIFY_OK entries={len(names)} archive={archive}")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
