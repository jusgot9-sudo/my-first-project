@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=%~dp0android_build.log"
set "OUTDIR=%~dp0..\APK_Output"
set "NOPAUSE="
if /i "%~1"=="nopause" set "NOPAUSE=1"

echo ============================================================
echo  SMART PLANT - ANDROID APK BUILD
echo ============================================================
>"%LOG%" echo Android build started %date% %time%

echo [1/5] Selecting Java (Gradle needs JDK 17 - 21)...
call :pick_java
if errorlevel 1 goto fail_java
echo Java %JVER%  (JAVA_HOME=%JAVA_HOME%)
>>"%LOG%" echo Using Java %JVER%  JAVA_HOME=%JAVA_HOME%

echo [2/5] Locating Android SDK...
set "SDK="
if defined ANDROID_HOME set "SDK=%ANDROID_HOME%"
if not defined SDK if defined ANDROID_SDK_ROOT set "SDK=%ANDROID_SDK_ROOT%"
if not defined SDK if exist "%LOCALAPPDATA%\Android\Sdk" set "SDK=%LOCALAPPDATA%\Android\Sdk"
if not defined SDK goto sdk_missing
set "SDKP=%SDK:\=/%"
>"local.properties" echo sdk.dir=%SDKP%
echo SDK: %SDK%
goto sdk_done
:sdk_missing
if exist "local.properties" goto sdk_done
goto fail_sdk
:sdk_done

echo [3/5] Accepting Android SDK licenses (if sdkmanager is installed)...
if not defined SDK goto lic_done
if not exist "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" goto lic_done
(for /l %%i in (1,1,40) do @echo y) | call "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" --licenses >>"%LOG%" 2>&1
if exist "%SDK%\platforms\android-35" goto lic_done
echo Installing Android platform 35 (one time)...
(for /l %%i in (1,1,40) do @echo y) | call "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" "platforms;android-35" "build-tools;35.0.0" >>"%LOG%" 2>&1
:lic_done

echo [4/5] Building APK (first run downloads Gradle + libraries, can take 5-15 minutes)...
call gradlew.bat assembleDebug --no-daemon --console=plain >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" goto fail_build

echo [5/5] Collecting APK...
set "SRC=%~dp0app\build\outputs\apk\debug\app-debug.apk"
if not exist "%SRC%" goto fail_output
copy /y "%SRC%" "%~dp0app\build\outputs\apk\debug\SmartPlantAndroid.apk" >nul
if not exist "%OUTDIR%" mkdir "%OUTDIR%"
copy /y "%SRC%" "%OUTDIR%\SmartPlantAndroid.apk" >nul
if errorlevel 1 goto fail_output

echo.
echo ============================================================
echo  APK BUILD SUCCESS
echo ============================================================
echo  %OUTDIR%\SmartPlantAndroid.apk
echo  Log: %LOG%
echo ============================================================
if not defined NOPAUSE pause
exit /b 0

:fail_java
echo ERROR: No usable Java found. Install JDK 17 (Temurin) from https://adoptium.net and run this again.
goto fail
:fail_sdk
echo ERROR: Android SDK not found. Install Android Studio once, or set ANDROID_HOME.
echo Expected: %LOCALAPPDATA%\Android\Sdk
goto fail
:fail_build
echo ERROR: Gradle build failed. Last 40 log lines:
echo ------------------------------------------------------------
powershell -NoProfile -Command "Get-Content -Tail 40 -LiteralPath '%LOG%'"
goto fail
:fail_output
echo ERROR: Build finished but the APK could not be collected.
goto fail
:fail
echo.
echo ============================================================
echo  APK BUILD FAILED  -  Log: %LOG%
echo ============================================================
if not defined NOPAUSE pause
exit /b 1

rem ---------------------------------------------------------------
rem  :pick_java  - prefer JDK 17..21 (Gradle 8.9 / AGP 8.7 support range)
rem ---------------------------------------------------------------
:pick_java
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\java.exe" set "PATH=%JAVA_HOME%\bin;%PATH%"
call :java_major
if %JMAJOR% GEQ 17 if %JMAJOR% LEQ 21 exit /b 0
set "FOUNDJ="
for %%R in ("%ProgramFiles%\Eclipse Adoptium" "%ProgramFiles%\Microsoft" "%ProgramFiles%\Java" "%ProgramFiles%\Amazon Corretto" "%ProgramFiles%\Zulu" "%ProgramFiles%\BellSoft") do for /d %%D in ("%%~R\jdk-17*" "%%~R\jdk-21*" "%%~R\jdk17*" "%%~R\jdk21*" "%%~R\corretto-17*" "%%~R\corretto-21*" "%%~R\zulu17*" "%%~R\zulu21*") do if exist "%%~D\bin\java.exe" set "FOUNDJ=%%~D"
if not defined FOUNDJ if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "FOUNDJ=%ProgramFiles%\Android\Android Studio\jbr"
if not defined FOUNDJ if exist "%LOCALAPPDATA%\Programs\Android Studio\jbr\bin\java.exe" set "FOUNDJ=%LOCALAPPDATA%\Programs\Android Studio\jbr"
if defined FOUNDJ goto pj_use
if %JMAJOR% GEQ 8 goto pj_warn
exit /b 1
:pj_use
set "JAVA_HOME=%FOUNDJ%"
set "PATH=%FOUNDJ%\bin;%PATH%"
call :java_major
exit /b 0
:pj_warn
echo WARNING: Java %JVER% is outside the tested range 17-21. Trying anyway.
echo          If Gradle complains, install JDK 17 from https://adoptium.net
exit /b 0

:java_major
set "JMAJOR=0"
set "JVER="
for /f "tokens=3" %%V in ('java -version 2^>^&1 ^| findstr /i "version"') do if not defined JVER set "JVER=%%~V"
if not defined JVER exit /b 0
for /f "delims=." %%M in ("%JVER%") do set "JMAJOR=%%M"
if "%JMAJOR%"=="1" for /f "tokens=2 delims=." %%M in ("%JVER%") do set "JMAJOR=%%M"
exit /b 0
