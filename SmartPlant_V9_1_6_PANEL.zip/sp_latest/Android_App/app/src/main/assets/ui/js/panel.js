/* Smart Plant HUD panel. Runs standalone (PC second-screen window / browser /panel) or inside the phone app (iframe).
   Data: GET <api>/api/state (+ /api/plants, /api/panel when the PC server answers). No fake values: missing = "--". */
(function () {
"use strict";
var Q = new URLSearchParams(location.search);
var API = (Q.get("api") || "").replace(/\/+$/, "");
var PC_WINDOW = Q.get("pc") === "1";           // opened by the PC launcher as its own window
var EMBED = Q.get("embed") === "1";            // inside the phone app / dashboard
var $ = function (id) { return document.getElementById(id); };
var LS = { get: function (k, d) { try { var v = localStorage.getItem("sp_" + k); return v === null ? d : v; } catch (e) { return d; } } };

var L = {
  en: { soil: "SOIL MOISTURE", temp: "AIR TEMP", hum: "HUMIDITY", water: "WATER TANK", gas: "GAS (MQ-2)", wtemp: "WATER TEMP",
        ctrl: "CONTROL", pump: "PUMP", auto: "AUTO", notify: "NOTIFICATIONS", pc: "THIS PC", on: "ON", off: "OFF",
        live: "LIVE", offline: "OFFLINE", locked: "Controls unlock when the board is live", ok: "All good", okd: "No alerts right now.",
        happy: "Plant is happy", dry: "Needs water", waiting: "Waiting for sensor", wateringNow: "Watering now", noplant: "No plant added yet",
        nolink: "No link to the controller", nolinkd: "Check Wi-Fi and the PC server." },
  si: { soil: "පස තෙතමනය", temp: "වායු උෂ්ණත්වය", hum: "ආර්ද්‍රතාව", water: "ජල ටැංකිය", gas: "වායු (MQ-2)", wtemp: "ජල උෂ්ණත්වය",
        ctrl: "පාලනය", pump: "පොම්පය", auto: "ස්වයංක්‍රීය", notify: "දැනුම්දීම්", pc: "මේ PC එක", on: "ON", off: "OFF",
        live: "සජීවී", offline: "ඕෆ්ලයින්", locked: "පුවරුව සම්බන්ධ වූ විට පාලනය ක්‍රියාත්මක වේ", ok: "සියල්ල හොඳයි", okd: "දැනට අවවාද නැහැ.",
        happy: "පැළය සතුටින්", dry: "වතුර අවශ්‍යයි", waiting: "සෙන්සරය බලාපොරොත්තුවෙන්", wateringNow: "දැන් වතුර දමමින්", noplant: "තවම පැළයක් එකතු කර නැහැ",
        nolink: "පාලකය සමඟ සම්බන්ධයක් නැහැ", nolinkd: "Wi-Fi සහ PC සර්වරය පරීක්ෂා කරන්න." }
};
function lang() { var l = LS.get("lang", ""); if (L[l]) return l; return String(navigator.language || "en").toLowerCase().indexOf("si") === 0 ? "si" : "en"; }
function t(k) { return (L[lang()] && L[lang()][k]) || L.en[k] || k; }
function applyLabels() {
  Array.prototype.forEach.call(document.querySelectorAll("[data-k]"), function (el) { el.textContent = t(el.getAttribute("data-k")); });
  document.documentElement.lang = lang();
}

function api(path, opts) {
  opts = opts || {}; opts.cache = "no-store";
  return fetch(API + path, opts).then(function (r) {
    return r.json().catch(function () { return {}; }).then(function (d) {
      if (!r.ok) { var e = new Error((d && d.error) || ("HTTP_" + r.status)); e.code = r.status; throw e; }
      return d;
    });
  });
}
function fmt(v, dp) { return v == null || isNaN(v) ? "--" : Number(v).toFixed(dp == null ? 1 : dp); }
function pct(v) { return v == null || isNaN(v) ? 0 : Math.max(0, Math.min(100, v)); }
function unitF() { return LS.get("units", "C") === "F"; }
function tOut(c) { return c == null ? null : (unitF() ? c * 9 / 5 + 32 : c); }

var S = {}, plants = [], plantIdx = 0, lastAlertKey = "", online = false, panelInfo = null;

function setVal(id, text, stale) { var el = $(id); el.textContent = text; el.classList.toggle("stale", !!stale); }
function setBar(id, v) { $(id).style.width = pct(v) + "%"; }

function localAlerts(s) {
  var out = [];
  if (s.soil != null && s.soil_threshold != null && s.soil <= s.soil_threshold) out.push({ level: "warning", title: t("dry"), details: "Soil " + fmt(s.soil) + "%" });
  if (s.water != null && s.water_safety != null && s.water <= s.water_safety) out.push({ level: "critical", title: "Water tank low", details: "Tank " + fmt(s.water) + "%" });
  return out;
}

function paint() {
  var on = S.connected != null ? !!S.connected : !!S.board_online;
  online = on;
  var chip = $("chip"); chip.classList.toggle("live", on); $("chipText").textContent = on ? t("live") : t("offline");
  var stale = !on;
  setVal("vSoil", on ? fmt(S.soil) : "--", stale);
  setVal("vTemp", on && S.temperature != null ? fmt(tOut(S.temperature)) : "--", stale);
  setVal("vHum", on ? fmt(S.humidity) : "--", stale);
  setVal("vWater", on ? fmt(S.water) : "--", stale);
  setVal("vGas", on ? fmt(S.gas) : "--", stale);
  setVal("vWtemp", on && S.water_temp != null ? fmt(tOut(S.water_temp)) : "--", stale);
  $("uTemp").textContent = $("uWtemp").textContent = unitF() ? "°F" : "°C";
  setBar("bTemp", on && S.temperature != null ? S.temperature / 50 * 100 : 0);
  setBar("bHum", on ? S.humidity : 0); setBar("bWater", on ? S.water : 0); setBar("bGas", on ? S.gas : 0);
  setBar("bWtemp", on && S.water_temp != null ? S.water_temp / 40 * 100 : 0);

  var soil = on && S.soil != null ? pct(S.soil) : 0;
  var rv = $("ringVal"); rv.setAttribute("stroke-dasharray", soil + " 100");
  var low = on && S.soil != null && S.soil_threshold != null && S.soil <= S.soil_threshold;
  rv.style.stroke = low ? "var(--amber)" : "var(--lime)";

  var line = $("plantLine"); line.className = "plant-line";
  var name = plants.length ? plants[plantIdx % plants.length].name : "";
  $("plantTag").textContent = name ? name.toUpperCase() : "PANEL";
  var msg;
  if (!on) { msg = t("waiting"); line.classList.add("crit"); }
  else if (S.pump) { msg = t("wateringNow"); }
  else if (low) { msg = t("dry"); line.classList.add("warn"); }
  else msg = t("happy");
  line.textContent = (name ? name + " · " : "") + msg;

  var pb = $("pumpBtn"), ab = $("autoBtn");
  pb.dataset.on = S.pump ? "1" : "0"; ab.dataset.on = S.auto_mode ? "1" : "0";
  $("pumpState").textContent = S.pump ? t("on") : t("off"); $("autoState").textContent = S.auto_mode ? t("on") : t("off");
  pb.disabled = ab.disabled = !on;
  $("ctlHint").textContent = on ? "" : t("locked");

  var alerts = S.alerts || (on ? localAlerts(S) : []);
  renderFeed(alerts, on);
}

function renderFeed(alerts, on) {
  var items = alerts.slice();
  if (!on && !items.length) items.push({ level: "critical", title: t("nolink"), details: t("nolinkd") });
  if (on && !items.length) items.push({ level: "ok", title: t("ok"), details: (plants.length ? plants[plantIdx % plants.length].name + " · " : "") + t("okd") });
  var key = items.map(function (a) { return a.level + a.title; }).join("|");
  var fresh = key !== lastAlertKey; lastAlertKey = key;
  var ul = $("feed"); ul.innerHTML = "";
  items.slice(0, 4).forEach(function (a) {
    var li = document.createElement("li"); li.className = (a.level || "ok") + (fresh ? " new" : "");
    var b = document.createElement("b"); b.textContent = a.title || "";
    var s = document.createElement("span"); s.textContent = a.details || "";
    li.appendChild(b); li.appendChild(s); ul.appendChild(li);
  });
}

function pollState() {
  return api("/api/state").then(function (d) { S = d || {}; paint(); }).catch(function () { S = {}; paint(); });
}
function pollPlants() {
  api("/api/plants").then(function (d) { plants = Array.isArray(d) ? d : []; paint(); }).catch(function () { plants = []; });
}
function pollPanel() {
  api("/api/panel").then(function (d) {
    panelInfo = d;
    var pc = d && d.sys;
    $("pcTile").hidden = !pc; $("pcTile").parentNode.classList.toggle("nopc", !pc);
    if (pc) {
      $("pcCpu").textContent = fmt(pc.cpu, 0) + "%"; setBar("bCpu", pc.cpu);
      $("pcRam").textContent = fmt(pc.ram, 0) + "%"; setBar("bRam", pc.ram);
    }
  }).catch(function () { $("pcTile").hidden = true; $("pcTile").parentNode.classList.add("nopc"); });
}

function send(action) {
  return api("/api/control", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: action }) })
    .then(pollState).catch(function (e) { $("ctlHint").textContent = e.message || "Failed"; });
}
$("pumpBtn").addEventListener("click", function () { send(S.pump ? "pump_off" : "pump_on"); });
$("autoBtn").addEventListener("click", function () { send(S.auto_mode ? "auto_off" : "auto_on"); });

function tick() {
  var d = new Date(), p = function (n) { return (n < 10 ? "0" : "") + n; };
  $("clkTime").textContent = p(d.getHours()) + ":" + p(d.getMinutes());
  try { $("clkDate").textContent = d.toLocaleDateString(lang() === "si" ? "si-LK" : undefined, { weekday: "short", day: "2-digit", month: "short" }).toUpperCase(); } catch (e) {}
}

/* window controls */
if (PC_WINDOW) {
  $("closeBtn").hidden = false; $("fsBtn").hidden = false;
  $("closeBtn").addEventListener("click", function () { api("/api/panel", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "off" }) }); });
  $("fsBtn").addEventListener("click", function () { api("/api/panel", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "fullscreen" }) }); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") $("closeBtn").click(); if (e.key === "F11") { e.preventDefault(); $("fsBtn").click(); } });
} else if (!EMBED) {
  $("fsBtn").hidden = false;           /* plain browser tab: use the browser Fullscreen API */
  $("fsBtn").addEventListener("click", function () {
    var el = document.documentElement;
    if (document.fullscreenElement) document.exitFullscreen(); else if (el.requestFullscreen) el.requestFullscreen();
  });
}

applyLabels(); tick(); setInterval(tick, 15000);
pollState(); pollPlants(); pollPanel();
setInterval(pollState, 2000);
setInterval(pollPlants, 30000);
setInterval(pollPanel, 5000);
setInterval(function () { if (plants.length > 1) { plantIdx++; paint(); } }, 7000);
window.addEventListener("storage", function () { applyLabels(); paint(); });
})();
