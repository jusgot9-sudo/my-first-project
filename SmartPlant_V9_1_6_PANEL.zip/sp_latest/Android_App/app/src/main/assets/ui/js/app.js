/* ==========================================================================
   SMART PLANT // front-end
   One bundle, two hosts:
     - served by the Flask PC app  -> same-origin UI/API; PC backend talks
                                      directly to the ESP32 on the same Wi-Fi
     - bundled in the Android APK  -> talks straight to the discovered ESP32
   No frameworks, no CDN, works offline.
   ========================================================================== */
(function () {
"use strict";

/* ----------------------------- 1. state ------------------------------- */
var API = "";                 // "" = same origin
var ANDROID_APP = (location.hostname === "appassets.androidplatform.net");
var DIRECT_BOARD = false;
var caps = { settings: true, history: true, plants: true, server: true };
var S = {};                   // last /api/state payload
var cfg = {};                 // last /api/settings payload
var cfgRevision = 0;          // server-authoritative settings revision
var settingsSyncInFlight = false;
var live = { t: [], soil: [], temp: [], hum: [], water: [], gas: [] };
var cameraStream = null;
var aiHistory = [];
var lastAiReply = "";
var voiceRecognition = null;
var voiceListening = false;
var androidVoiceSessionActive = false;
var timer = null, histTimer = null, page = "dashboard", started = false;

var LS = {
    get: function (k, d) { try { var v = localStorage.getItem("sp_" + k); return v === null ? d : v; } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem("sp_" + k, v); } catch (e) {} }
};

var $ = function (id) { return document.getElementById(id); };
var qsa = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
/* shared helper: update/voice/AI status code outside boot() needs it too */
function setText(id, text) { var el = $(id); if (el) el.textContent = text; }

/* ----------------------------- 2. i18n -------------------------------- */
var T = {
    en: {
        bootTitle: "System initialization",
        gateTitle: "Connect to controller",
        gateSub: "enter the pc server or the board address",
        serverAddress: "Server address",
        connect: "Connect",
        dashboard: "Dashboard",
        panel: "Panel",
        panelFullscreen: "Fullscreen panel",
        panelPcFs: "PC: fullscreen",
        analytics: "Analytics",
        plants: "Plants",
        irrigation: "Irrigation",
        history: "History",
        alerts: "Alerts",
        camera: "Camera",
        device: "Device",
        settings: "Settings",
        linkTarget: "LINK",
        subLive: "live telemetry · real hardware only",
        liveTrend: "Live trend",
        waitingBoard: "waiting for board",
        controls: "Controls",
        autoIrrigation: "Auto irrigation",
        autoHint: "waters when soil drops below threshold",
        pump: "Pump",
        pumpHint: "manual override",
        timedRun: "Timed run",
        timedHint: "run the pump for a set number of seconds",
        run: "Run",
        events: "Events",
        pumpTime: "Pump time",
        health: "Health",
        lockedNotice: "Controls stay locked until the board sends live telemetry.",
        averages: "Averages and extremes",
        storedSamples: "Stored samples",
        plantProfiles: "Plant profiles",
        addPlant: "Add plant",
        plantHint: "A profile records what a plant needs. Applying one copies its moisture range into the irrigation settings.",
        irrigationLogic: "Irrigation logic",
        threshold: "Start below (soil %)",
        target: "Stop at (soil %)",
        maxRuntime: "Max pump runtime (sec)",
        waterSafety: "Stop if tank below (%)",
        schedule: "Daily schedule",
        scheduleOn: "Scheduled watering",
        off: "Off",
        on: "On",
        scheduleTime: "Start time (24h)",
        scheduleSeconds: "Run for (sec)",
        scheduleHint: "A scheduled run still respects the tank minimum and the max runtime.",
        alertRanges: "Alert ranges",
        tempRange: "Temperature °C min / max",
        humRange: "Humidity % min / max",
        saveIrrigation: "Save irrigation settings",
        reload: "Reload",
        sensorLog: "Sensor log",
        exportCsv: "Export CSV",
        time: "Time",
        noSamples: "No stored samples in this range yet.",
        eventLog: "Event log",
        event: "Event",
        details: "Details",
        noEvents: "No events recorded in this range.",
        activeAlerts: "Active alerts",
        alertHint: "Alerts come from live telemetry and the link state. Ranges are set on the Irrigation page.",
        startCamera: "Start camera",
        stopCamera: "Stop",
        cameraHint: "Uses the current device camera (Android phone/tablet or PC webcam). On Android, allow camera permission; on PC, allow browser camera permission. The listed hardware does not include a separate ESP32-CAM module.",
        linkAndBoard: "Link and board",
        testLink: "Test link",
        copyAddress: "Copy address",
        controller: "Controller",
        state: "State",
        boardType: "Board type",
        firmware: "Firmware",
        pcServer: "PC server",
        linkMode: "Link mode",
        lastTelemetry: "Last telemetry",
        uptime: "Server uptime",
        boardToPc: "Board → PC (push mode)",
        pcToBoard: "PC → board (command polling)",
        deviceHint: "In poll mode the PC reads the board itself at GET /api/state and sends POST /api/control, so the same board works with the phone app directly.",
        appearance: "Appearance and language",
        theme: "Theme",
        themeCyber: "Cyberpunk",
        themeLight: "Light",
        themeForest: "Forest",
        themeOcean: "Ocean",
        themeSunset: "Sunset",
        themeViolet: "Violet",
        language: "Language",
        units: "Temperature unit",
        refresh: "Refresh every (sec)",
        controllerSetup: "Controller setup",
        controllerName: "Controller name",
        modePush: "Board pushes to PC",
        modePoll: "PC polls the board",
        boardAddress: "Board address",
        timeout: "Offline after (sec)",
        boardToken: "Board token",
        pinMap: "Sensor pin map",
        pinHint: "The pin map is documentation for your wiring. It is shown on the Device page and in the exported notes.",
        saveSystem: "Save controller settings",
        dataAndLink: "Data and link",
        retention: "Keep history for (days)",
        apiBase: "This app talks to",
        saveData: "Save data settings",
        changeLink: "Change link",
        clearHistory: "Clear stored history",
        name: "Name",
        plantType: "Type",
        zone: "Zone",
        plantMin: "Water below (soil %)",
        plantTarget: "Stop at (soil %)",
        notes: "Notes",
        save: "Save",
        cancel: "Cancel",
        celsius: "Celsius",
        fahrenheit: "Fahrenheit",
        thisDevice: "this device",
        fullscreen: "Fullscreen",
        soilSensor: "Soil",
        tempHumidity: "Temp / humidity",
        waterLevel: "Water level",
        mq2Gas: "MQ-2 gas",
        waterTempSensor: "Water temp (DS18B20)",
        pumpRelay: "Pump relay",
        matrixPins: "MAX7219 DIN / CS / CLK",
        tokenKeep: "leave blank to keep",
        sameDevice: "same device",
        soilMoisture: "Soil moisture",
        thresholdFoot: "threshold --",
        temperature: "Temperature",
        safeRange: "safe range --",
        humidity: "Humidity",
        relative: "relative",
        waterTemp: "Water temp",
        ds18b20Probe: "DS18B20 probe",
        waterTank: "Water tank",
        reserve: "reserve --",
        mq2GasLevel: "MQ-2 gas level",
        relativeGasLevel: "relative level · not ppm",
        controllerLabel: "Controller",
        noTelemetry: "no telemetry",
        avgSoil: "Avg soil",
        avgTemp: "Avg temp",
        avgHumidity: "Avg humidity",
        avgWater: "Avg water",
        avgGas: "Avg gas",
        avgWaterTemp: "Avg water temp",
        minMax: "min/max --",
        samples: "Samples",
        pumpCycles: "pump cycles --",
        analyticsHint: "Analytics uses stored real samples only.",
        gasAlert: "MQ-2 gas alert above (%)",
        findController: "Find controller",
        autoDetect: "Auto-detect controller at startup",
        openWithoutBoard: "Open dashboard without board",
        scanSearch: "Searching the local Wi-Fi network for the Smart Plant controller",
        scanning: "SCANNING...",
        initializingScan: "INITIALIZING NETWORK SCAN",
        startingDiscovery: "Starting real network discovery...",
        lanDiscovery: "LAN DISCOVERY",
        preparingSweep: "Preparing full LAN sweep...",
        mode: "MODE",
        checked: "CHECKED",
                api: "API",
        aiAssistant: "AI Assistant", aiSubtitle: "Ask about your live plant data. No sensor values are invented.", aiReady: "READY", voiceChat: "Voice chat", speakLast: "Speak last answer", voiceReady: "Voice ready", plantVoiceAi: "Plant AI Voice Control", plantVoiceAiHint: "Speak naturally about your Smart Plant system. The AI replies by voice and can apply allowed plant controls.", voiceScope: "Plant topics only · English default", edgeTtsEngine: "Google TTS · PC/Android native playback", voiceOnly: "Voice mode" , aiVoiceTab: "Voice", aiTextTab: "Text chat", aiTextHint: "Type a message to the Smart Plant AI.", aiSend: "Send", aiClear: "Clear", aiTextPlaceholder: "Type your question here...", aiWorking: "THINKING", aiError: "ERROR", voiceListening: "LISTENING",
        send: "Send", clearChat: "Clear chat", aiPlaceholder: "Ask the Smart Plant assistant...", aiControlNote: "AI plant control", aiControlHint: "AI can report real problems and execute explicit pump or automatic-irrigation requests. Controller safety rules still apply.", aiControlEnabled: "AI plant control enabled",
        aiSettings: "AI & Voice settings", aiSettingsHint: "Create a free key at console.groq.com, paste it here, then save and verify. The key stays on the PC hub.", keyNotSet: "NO API KEY — open Settings → AI & Voice and paste your key", aiEnabled: "AI Assistant enabled", aiModel: "AI model", detectAi: "PC AI පරීක්ෂා කරන්න", 
        openweatherKey: "OpenWeather API key (optional)", weatherLocation: "Weather location (optional)", apiKeyKeep: "leave blank to keep current key", weatherLocationHint: "e.g. Colombo",
        autoSpeak: "Automatically speak AI replies", aiVoiceNote: "Voice chat uses your microphone for input and your device/browser speech output for replies.",
        groqApiKey: "Groq API key", groqKeyPlaceholder: "Paste your Groq key", saveGroqKey: "Save and verify Groq key", clearGroqKey: "Clear saved Groq key", checkAiKey: "Check AI API key", testAi: "Test AI voice", groqKeySecurity: "On Android, the key is sent to the Smart Plant PC hub and is not stored in the APK.", groqKeySettingsHint: "Use the AI and Voice settings above to save or replace the Groq key."
    },
    si: {
        groqApiKey: "Groq API key", groqKeyPlaceholder: "Groq key එක මෙතන දාන්න", saveGroqKey: "Groq key Save + Verify", clearGroqKey: "Saved Groq key ඉවත් කරන්න", checkAiKey: "AI API key පරීක්ෂා කරන්න", testAi: "AI හඬ පරීක්ෂාව", groqKeySecurity: "Android එකේ key එක PC Smart Plant hub එකට පමණක් යවන අතර APK එක තුළ save කරන්නේ නැහැ.", groqKeySettingsHint: "AI & Voice settings වලින් Groq key එක save හෝ replace කරන්න.",
        plantVoiceAi: "Smart Plant AI Voice Control", plantVoiceAiHint: "Smart Plant system ගැන voice එකෙන් කතා කරන්න. AI එක voice එකෙන් පිළිතුරු දී අවසර ඇති plant controls ක්‍රියාත්මක කරයි.", voiceScope: "Plant topics only · English default", edgeTtsEngine: "Google TTS · PC/Android native playback", voiceOnly: "Voice mode" , aiVoiceTab: "Voice", aiTextTab: "Text chat", aiTextHint: "Type a message to the Smart Plant AI.", aiSend: "Send", aiClear: "Clear", aiTextPlaceholder: "Type your question here...", aiWorking: "THINKING", aiError: "ERROR", voiceListening: "LISTENING",
        bootTitle: "පද්ධතිය ආරම්භ වේ",
        gateTitle: "පාලකයට සම්බන්ධ වන්න",
        gateSub: "PC සේවාදායකයේ හෝ පුවරුවේ ලිපිනය ඇතුළත් කරන්න",
        serverAddress: "සේවාදායක ලිපිනය",
        connect: "සම්බන්ධ වන්න",
        dashboard: "ඩෑෂ්බෝඩ්",
        panel: "පැනල්",
        panelFullscreen: "පැනල් Fullscreen",
        panelPcFs: "PC: Fullscreen",
        analytics: "විශ්ලේෂණ",
        plants: "පැල",
        irrigation: "වාරිමාර්ග",
        history: "ඉතිහාසය",
        alerts: "ඇඟවීම්",
        camera: "කැමරාව",
        device: "උපාංගය",
        settings: "සැකසුම්",
        linkTarget: "සම්බන්ධය",
        subLive: "සජීවී දත්ත · සැබෑ උපාංගයෙන් පමණි",
        liveTrend: "සජීවී ප්‍රවණතාව",
        waitingBoard: "පුවරුව සඳහා රැඳී සිටී",
        controls: "පාලන",
        autoIrrigation: "ස්වයංක්‍රීය වතුර",
        autoHint: "පාංශු තෙතමනය සීමාවට අඩු වූ විට වතුර දමයි",
        pump: "පොම්පය",
        pumpHint: "අතින් පාලනය",
        timedRun: "කාලය සමඟ ක්‍රියාත්මක",
        timedHint: "තෝරාගත් තත්පර ගණනට පොම්පය ක්‍රියාත්මක වේ",
        run: "ආරම්භ",
        events: "සිදුවීම්",
        pumpTime: "පොම්ප කාලය",
        health: "තත්ත්වය",
        lockedNotice: "සැබෑ දත්ත ලැබෙන තුරු පාලන අගුලු දමා ඇත.",
        averages: "සාමාන්‍ය සහ අවම/උපරිම",
        storedSamples: "ගබඩා කළ දත්ත",
        plantProfiles: "පැල විස්තර",
        addPlant: "පැලයක් එකතු කරන්න",
        plantHint: "පැල profile එකෙන් පැලයට අවශ්‍ය තෙතමන පරාසය සුරකින්න. Apply කළ විට irrigation settings වෙත පිටපත් වේ.",
        irrigationLogic: "වාරිමාර්ග තර්කය",
        threshold: "මෙයට අඩු නම් ආරම්භ (තෙතමනය %)",
        target: "ඉලක්කය",
        maxRuntime: "උපරිම පොම්ප කාලය (තත්පර)",
        waterSafety: "ටැංකිය මෙයට අඩු නම් නවතන්න (%)",
        schedule: "දෛනික කාලසටහන",
        scheduleOn: "කාලසටහන් වතුර දැමීම",
        off: "නිෂ්ක්‍රීය",
        on: "ක්‍රියාත්මක",
        scheduleTime: "ආරම්භ වේලාව (පැය 24)",
        scheduleSeconds: "ධාවනය (තත්පර)",
        scheduleHint: "කාලසටහන් ධාවනයේදීත් ටැංකි අවමය සහ උපරිම ධාවන කාලය පිළිපදියි.",
        alertRanges: "ඇඟවීම් සීමා",
        tempRange: "උෂ්ණත්වය °C අවම / උපරිම",
        humRange: "ආර්ද්‍රතාව % අවම / උපරිම",
        saveIrrigation: "වාරිමාර්ග සැකසුම් සුරකින්න",
        reload: "නැවත ගන්න",
        sensorLog: "සංවේදක වාර්තාව",
        exportCsv: "CSV ලෙස ගන්න",
        time: "වේලාව",
        noSamples: "මෙම පරාසයේ ගබඩා කළ දත්ත නැත.",
        eventLog: "සිදුවීම් වාර්තාව",
        event: "සිදුවීම",
        details: "විස්තර",
        noEvents: "මෙම පරාසයේ සිදුවීම් නැත.",
        activeAlerts: "ක්‍රියාකාරී ඇඟවීම්",
        alertHint: "ඇඟවීම් සජීවී දත්ත සහ සම්බන්ධතා තත්ත්වය මත පදනම් වේ. සීමා වාරිමාර්ග පිටුවේ සකසන්න.",
        startCamera: "කැමරාව ආරම්භ",
        stopCamera: "නවත්වන්න",
        cameraHint: "දැනට භාවිතා කරන උපාංගයේ කැමරාව භාවිත කරයි.",
        linkAndBoard: "සම්බන්ධතාව සහ පුවරුව",
        testLink: "සම්බන්ධතාව පරීක්ෂා",
        copyAddress: "ලිපිනය පිටපත්",
        controller: "පාලකය",
        state: "තත්ත්වය",
        boardType: "පුවරු වර්ගය",
        firmware: "Firmware",
        pcServer: "PC සේවාදායකය",
        linkMode: "සම්බන්ධතා ක්‍රමය",
        lastTelemetry: "අවසන් දත්ත",
        uptime: "සේවාදායක ක්‍රියාකාලය",
        boardToPc: "පුවරුව → PC (push ක්‍රමය)",
        pcToBoard: "PC → පුවරුව (විධාන polling)",
        deviceHint: "Poll ක්‍රමයේදී PC එක GET /api/state මගින් පුවරුව කියවා POST /api/control මගින් විධාන යවයි. එම පුවරුව phone app එකෙන්ද සෘජුව භාවිත කළ හැක.",
        appearance: "පෙනුම සහ භාෂාව",
        theme: "තේමාව",
        themeCyber: "සයිබර්පන්ක්",
        themeLight: "ලා පැහැති",
        themeForest: "වනාන්තර",
        themeOcean: "සාගරය",
        themeSunset: "හිරු බැසීම",
        themeViolet: "වයලට්",
        language: "භාෂාව",
        units: "උෂ්ණත්ව ඒකකය",
        refresh: "යාවත්කාලීන වාරය (තත්පර)",
        controllerSetup: "පාලක සැකසුම",
        controllerName: "පාලකයේ නම",
        modePush: "පුවරුව PC වෙත යවයි",
        modePoll: "PC පුවරුව කියවයි",
        boardAddress: "පුවරු ලිපිනය",
        timeout: "මෙතෙක් දත්ත නැතිනම් offline (තත්පර)",
        boardToken: "පුවරු ටෝකනය",
        pinMap: "සංවේදක පින් සිතියම",
        pinHint: "මෙය wiring සටහනකි. Device පිටුවේ සහ export notes වල පෙන්වයි.",
        saveSystem: "පාලක සැකසුම් සුරකින්න",
        dataAndLink: "දත්ත සහ සම්බන්ධතාව",
        retention: "ඉතිහාසය තබන දින ගණන",
        apiBase: "මෙම යෙදුම සම්බන්ධ වන්නේ",
        saveData: "දත්ත සැකසුම් සුරකින්න",
        changeLink: "සම්බන්ධතාව වෙනස් කරන්න",
        clearHistory: "ඉතිහාසය මකන්න",
        name: "නම",
        plantType: "වර්ගය",
        zone: "කලාපය",
        plantMin: "පහළ තෙතමනයේදී වතුර (%)",
        plantTarget: "මෙහිදී නවතන්න (soil %)",
        notes: "සටහන්",
        save: "සුරකින්න",
        cancel: "අවලංගු",
        celsius: "සෙල්සියස්",
        fahrenheit: "ෆැරන්හයිට්",
        thisDevice: "මෙම උපාංගය",
        fullscreen: "සම්පූර්ණ තිරය",
        soilSensor: "පස",
        tempHumidity: "උෂ්ණත්වය / ආර්ද්‍රතාව",
        waterLevel: "ජල මට්ටම",
        mq2Gas: "MQ-2 වායු සංවේදකය",
        waterTempSensor: "ජල උෂ්ණත්වය (DS18B20)",
        pumpRelay: "පොම්ප relay",
        matrixPins: "MAX7219 DIN / CS / CLK",
        tokenKeep: "තබා ගැනීමට හිස්ව තබන්න",
        sameDevice: "එම උපාංගය",
        soilMoisture: "පාංශු තෙතමනය",
        thresholdFoot: "සීමාව --",
        temperature: "උෂ්ණත්වය",
        safeRange: "ආරක්ෂිත පරාසය --",
        humidity: "ආර්ද්‍රතාව",
        relative: "සාපේක්ෂ",
        waterTemp: "ජල උෂ්ණත්වය",
        ds18b20Probe: "DS18B20 සංවේදකය",
        waterTank: "ජල ටැංකිය",
        reserve: "ඉතිරිය --",
        mq2GasLevel: "MQ-2 වායු මට්ටම",
        relativeGasLevel: "සාපේක්ෂ මට්ටම · ppm නොවේ",
        controllerLabel: "පාලකය",
        noTelemetry: "දත්ත නොලැබේ",
        avgSoil: "සාමාන්‍ය පස",
        avgTemp: "සාමාන්‍ය උෂ්ණත්වය",
        avgHumidity: "සාමාන්‍ය ආර්ද්‍රතාව",
        avgWater: "සාමාන්‍ය ජලය",
        avgGas: "සාමාන්‍ය වායුය",
        avgWaterTemp: "සාමාන්‍ය ජල උෂ්ණත්වය",
        minMax: "අවම/උපරිම --",
        samples: "නියැදි",
        pumpCycles: "පොම්ප චක්‍ර --",
        analyticsHint: "විශ්ලේෂණ සඳහා ගබඩා කළ සැබෑ දත්ත පමණක් භාවිතා කරයි.",
        gasAlert: "MQ-2 වායු ඇඟවීම ඉහළ සීමාව (%)",
        findController: "පාලකය සොයන්න",
        autoDetect: "ආරම්භයේදී පාලකය ස්වයංක්‍රීයව සොයන්න",
        openWithoutBoard: "පුවරුවක් නැතිව ඩෑෂ්බෝඩ් විවෘත කරන්න",
        scanSearch: "Smart Plant පාලකය සඳහා මෙම Wi-Fi ජාලය සොයමින් සිටී",
        scanning: "සොයමින්...",
        initializingScan: "ජාල සෙවීම ආරම්භ කරමින්",
        startingDiscovery: "සැබෑ ජාල සෙවීම ආරම්භ කරමින්...",
        lanDiscovery: "LAN සෙවීම",
        preparingSweep: "LAN සෙවීම සූදානම් කරමින්...",
        mode: "ක්‍රමය",
        checked: "පරීක්ෂා කළ",
                api: "API",
        aiAssistant: "AI සහායක", aiSubtitle: "සජීවී පැල දත්ත ගැන අහන්න. සංවේදක අගයන් හදාගන්නේ නැහැ.", aiReady: "සූදානම්", voiceChat: "හඬ කතාබස්", speakLast: "අවසන් පිළිතුර කියවන්න", voiceReady: "හඬ සූදානම්", aiVoiceTab: "හඬ", aiTextTab: "පෙළ කතාබස්", aiTextHint: "Smart Plant AI වෙත පණිවිඩයක් ටයිප් කරන්න.", aiSend: "යවන්න", aiClear: "මකන්න", aiTextPlaceholder: "ඔබේ ප්‍රශ්නය මෙතන ටයිප් කරන්න...",
        send: "යවන්න", clearChat: "කතාබස් මකන්න", aiPlaceholder: "Smart Plant සහායකගෙන් අහන්න...", aiControlNote: "AI පැල පාලනය", aiControlHint: "AI හට සැබෑ ගැටලු report කර user පැහැදිලිව ඉල්ලූ pump හෝ automatic-irrigation actions කරන්න පුළුවන්. Controller safety rules තවමත් ක්‍රියාත්මකයි.", aiControlEnabled: "AI මගින් පැල පාලනය සක්‍රිය",
        aiSettings: "AI සහ හඬ සැකසුම්", aiSettingsHint: "console.groq.com එකෙන් free key එකක් ගෙන මෙතන දාලා Save + Verify කරන්න. Key එක PC hub එකේ විතරක් තබනවා.", keyNotSet: "PC AI key සකසා නැත", aiEnabled: "AI සහායක සක්‍රිය", aiModel: "AI model", detectAi: "PC AI පරීක්ෂා කරන්න", 
        openweatherKey: "OpenWeather API key (විකල්ප)", weatherLocation: "කාලගුණ ස්ථානය (විකල්ප)", apiKeyKeep: "දැනට key එක තබා ගැනීමට හිස්ව තබන්න", weatherLocationHint: "උදා: Colombo",
        saveAiSettings: "AI සැකසුම් සුරකින්න", testAI: "AI පරීක්ෂා කරන්න", clearAiKey: "Groq key මකන්න", autoSpeak: "AI පිළිතුරු ස්වයංක්‍රීයව හඬින් කියවන්න", aiVoiceNote: "හඬ කතාබස් සඳහා microphone input සහ device/browser speech output භාවිතා කරයි."
    },
    ja: {
        groqApiKey: "Groq API key", groqKeyPlaceholder: "Paste Groq key", saveGroqKey: "Save and verify Groq key", clearGroqKey: "Clear saved Groq key", checkAiKey: "Check AI API key", testAi: "Test AI voice", groqKeySecurity: "Android sends the key to the Smart Plant PC hub only.", groqKeySettingsHint: "Manage the Groq key from AI and Voice settings.",
        bootTitle: "システム初期化",
        gateTitle: "コントローラに接続",
        gateSub: "PCサーバーまたはボードのアドレスを入力",
        serverAddress: "サーバーアドレス",
        connect: "接続",
        dashboard: "ダッシュボード",
        panel: "パネル",
        panelFullscreen: "全画面パネル",
        panelPcFs: "PC: 全画面",
        analytics: "分析",
        plants: "植物",
        irrigation: "灌水",
        history: "履歴",
        alerts: "アラート",
        camera: "カメラ",
        device: "デバイス",
        settings: "設定",
        linkTarget: "接続",
        subLive: "実機テレメトリのみ",
        liveTrend: "ライブ推移",
        waitingBoard: "ボードを待機中",
        controls: "操作",
        autoIrrigation: "自動灌水",
        autoHint: "土壌水分が設定値を下回ると散水します",
        pump: "ポンプ",
        pumpHint: "手動操作",
        timedRun: "時間指定運転",
        timedHint: "run the pump for a set number of seconds",
        run: "運転",
        events: "イベント",
        pumpTime: "運転時間",
        health: "状態",
        lockedNotice: "実データを受信するまで操作はロックされます。",
        averages: "平均値",
        storedSamples: "保存サンプル",
        plantProfiles: "植物プロファイル",
        addPlant: "植物を追加",
        plantHint: "植物プロファイルに必要な土壌水分範囲を保存します。適用すると灌水設定へコピーされます。",
        irrigationLogic: "灌水ロジック",
        threshold: "この値未満で開始 (%)",
        target: "対象",
        maxRuntime: "最大運転時間 (秒)",
        waterSafety: "タンクがこの値未満なら停止",
        schedule: "毎日のスケジュール",
        scheduleOn: "スケジュール散水",
        off: "オフ",
        on: "オン",
        scheduleTime: "開始時刻（24時間）",
        scheduleSeconds: "運転時間（秒）",
        scheduleHint: "スケジュール運転でもタンク下限と最大運転時間を守ります。",
        alertRanges: "アラート範囲",
        tempRange: "温度 °C 最小 / 最大",
        humRange: "湿度 % 最小 / 最大",
        saveIrrigation: "保存",
        reload: "再読込",
        sensorLog: "センサーログ",
        exportCsv: "CSV出力",
        time: "時刻",
        noSamples: "この範囲には保存データがありません。",
        eventLog: "イベントログ",
        event: "イベント",
        details: "詳細",
        noEvents: "この範囲にはイベントがありません。",
        activeAlerts: "有効なアラート",
        alertHint: "アラートはライブテレメトリと接続状態に基づきます。範囲は灌水ページで設定します。",
        startCamera: "カメラ開始",
        stopCamera: "停止",
        cameraHint: "現在のデバイスのカメラを使用します。",
        linkAndBoard: "接続とボード",
        testLink: "接続テスト",
        copyAddress: "アドレスをコピー",
        controller: "コントローラ",
        state: "状態",
        boardType: "ボード種別",
        firmware: "ファームウェア",
        pcServer: "PCサーバー",
        linkMode: "接続モード",
        lastTelemetry: "最終テレメトリ",
        uptime: "サーバー稼働時間",
        boardToPc: "ボード → PC（プッシュ）",
        pcToBoard: "PC → ボード（コマンドポーリング）",
        deviceHint: "ポーリング時はPCがGET /api/stateでボードを読み、POST /api/controlで操作します。電話アプリから同じボードへ直接接続できます。",
        appearance: "外観と言語",
        theme: "テーマ",
        themeCyber: "サイバーパンク",
        themeLight: "ライト",
        themeForest: "フォレスト",
        themeOcean: "オーシャン",
        themeSunset: "サンセット",
        themeViolet: "バイオレット",
        language: "言語",
        units: "温度単位",
        refresh: "更新間隔（秒）",
        controllerSetup: "コントローラ設定",
        controllerName: "名前",
        modePush: "ボードがPCへ送信",
        modePoll: "PCがボードをポーリング",
        boardAddress: "ボードアドレス",
        timeout: "Offline after (sec)",
        boardToken: "ボードトークン",
        pinMap: "ピン配置",
        pinHint: "これは配線用のピン配置です。Deviceページとエクスポートしたメモに表示されます。",
        saveSystem: "保存",
        dataAndLink: "データと接続",
        retention: "履歴を保持する日数",
        apiBase: "このアプリの接続先",
        saveData: "データ設定を保存",
        changeLink: "接続先を変更",
        clearHistory: "履歴を消去",
        name: "名前",
        plantType: "種類",
        zone: "ゾーン",
        plantMin: "この土壌水分未満で給水 (%)",
        plantTarget: "この土壌水分で停止 (%)",
        notes: "メモ",
        save: "保存",
        cancel: "取消",
        celsius: "摂氏",
        fahrenheit: "華氏",
        thisDevice: "このデバイス",
        fullscreen: "全画面",
        soilSensor: "土壌",
        tempHumidity: "温度 / 湿度",
        waterLevel: "水位",
        mq2Gas: "MQ-2 ガス",
        waterTempSensor: "水温（DS18B20）",
        pumpRelay: "ポンプリレー",
        matrixPins: "MAX7219 DIN / CS / CLK",
        tokenKeep: "空欄のままにすると現在値を保持",
        sameDevice: "このデバイス",
        soilMoisture: "土壌水分",
        thresholdFoot: "しきい値 --",
        temperature: "温度",
        safeRange: "安全範囲 --",
        humidity: "湿度",
        relative: "相対",
        waterTemp: "水温",
        ds18b20Probe: "DS18B20プローブ",
        waterTank: "水タンク",
        reserve: "残量 --",
        mq2GasLevel: "MQ-2ガスレベル",
        relativeGasLevel: "相対レベル · ppmではありません",
        controllerLabel: "コントローラ",
        noTelemetry: "テレメトリなし",
        avgSoil: "平均土壌水分",
        avgTemp: "平均温度",
        avgHumidity: "平均湿度",
        avgWater: "平均水位",
        avgGas: "平均ガス",
        avgWaterTemp: "平均水温",
        minMax: "最小/最大 --",
        samples: "サンプル",
        pumpCycles: "ポンプ回数 --",
        analyticsHint: "分析には保存された実データのみを使用します。",
        gasAlert: "MQ-2ガスアラート上限 (%)",
        findController: "コントローラを検索",
        autoDetect: "起動時にコントローラを自動検出",
        openWithoutBoard: "ボードなしでダッシュボードを開く",
        scanSearch: "ローカルWi-FiでSmart Plantコントローラを検索しています",
        scanning: "スキャン中...",
        initializingScan: "ネットワークスキャンを初期化中",
        startingDiscovery: "実ネットワーク検出を開始しています...",
        lanDiscovery: "LAN検出",
        preparingSweep: "LAN全体のスキャンを準備中...",
        mode: "モード",
        checked: "確認済み",
                api: "API",
        aiAssistant: "AIアシスタント", aiSubtitle: "ライブの植物データについて質問できます。センサー値は作りません。", aiReady: "準備完了", voiceChat: "音声チャット", speakLast: "最後の回答を読み上げる", voiceReady: "音声準備完了", aiVoiceTab: "音声", aiTextTab: "テキストチャット", aiTextHint: "Smart Plant AI にメッセージを入力してください。", aiSend: "送信", aiClear: "消去", aiTextPlaceholder: "ここに質問を入力...",
        send: "送信", clearChat: "チャットを消去", aiPlaceholder: "Smart Plantアシスタントに質問...", aiControlNote: "AI植物制御", aiControlHint: "AIは実際の問題を報告し、ユーザーが明示的に依頼したポンプまたは自動灌水を実行できます。コントローラの安全条件は常に適用されます。", aiControlEnabled: "AI植物制御を有効化",
        aiSettings: "AIと音声の設定", aiSettingsHint: "AI は Smart Plant PC ハブの GROQ_API_KEY を使用します。", keyNotSet: "PC AI key 未設定", aiEnabled: "AIアシスタントを有効化", aiModel: "AIモデル", detectAi: "PC AIを確認", 
        openweatherKey: "OpenWeather APIキー（任意）", weatherLocation: "天気の場所（任意）", apiKeyKeep: "現在のキーを保持する場合は空欄", weatherLocationHint: "例: Colombo",
        saveAiSettings: "AI設定を保存", checkAiKey: "AI APIキーを確認", testAI: "AI音声テスト", clearAiKey: "Groqキーを消去", autoSpeak: "AIの回答を自動的に読み上げる", aiVoiceNote: "音声チャットはマイク入力と端末/ブラウザの音声出力を使用します。"
    }
};

function detectLanguage() {
    var raw = String(navigator.language || navigator.userLanguage || "en").toLowerCase();
    if (raw.indexOf("si") === 0) return "si";
    if (raw.indexOf("ja") === 0) return "ja";
    return "en";
}

function getLang() {
    var saved = LS.get("lang", "");
    return T[saved] ? saved : detectLanguage();
}

function tr(key, fallback) {
    var lang = getLang();
    var d = T[lang] || T.en;
    return (d && d[key]) || (T.en && T.en[key]) || fallback || key;
}

function applyI18n() {
    qsa("[data-i18n]").forEach(function (el) {
        var k = el.getAttribute("data-i18n");
        var def = el.getAttribute("data-en") || el.textContent;
        if (!el.getAttribute("data-en")) el.setAttribute("data-en", def);
        el.textContent = tr(k, el.getAttribute("data-en"));
    });
    qsa("[data-i18n-placeholder]").forEach(function (el) {
        var k = el.getAttribute("data-i18n-placeholder");
        el.setAttribute("placeholder", tr(k, el.getAttribute("placeholder") || ""));
    });
    qsa("[data-i18n-title]").forEach(function (el) {
        var k = el.getAttribute("data-i18n-title");
        el.setAttribute("title", tr(k, el.getAttribute("title") || ""));
    });
    setTitle(page);
}

/* --------------------------- 3. transport ----------------------------- */
function url(path) { return API + path; }

function api(path, opts) {
    opts = opts || {};
    opts.cache = "no-store";
    return fetch(url(path), opts).then(function (r) {
        return r.text().then(function (raw) {
            var data = null;
            try { data = raw ? JSON.parse(raw) : {}; } catch (e) {}
            if (r.status === 404) { var e404 = new Error("NOT_SUPPORTED"); e404.code = 404; throw e404; }
            if (!data || typeof data !== "object") {
                var ej = new Error("SERVER_NON_JSON");
                ej.code = r.status;
                ej.serverText = String(raw || "").slice(0, 500);
                throw ej;
            }
            if (!r.ok) {
                var eh = new Error(String(data.error || data.message || ("HTTP_" + r.status)));
                eh.code = r.status;
                eh.data = data;
                throw eh;
            }
            return data;
        });
    });
}

function post(path, body) {
    return api(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {})
    });
}
function aiServerReady(){
    return !!API || (!ANDROID_APP && (location.protocol === "http:" || location.protocol === "https:"));
}

/* ----------------------------- 4. toast ------------------------------- */
function toast(msg, isErr) {
    var box = $("toasts");
    var el = document.createElement("div");
    el.className = "toast" + (isErr ? " err" : "");
    el.innerHTML = '<span class="mono">' + (isErr ? "failed" : "done") + "</span>" + esc(msg);
    box.appendChild(el);
    setTimeout(function () { el.remove(); }, 4200);
}

function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
        return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
}

/* --------------------------- 5. formatting ---------------------------- */
function tempOut(c) {
    if (c == null) return null;
    return LS.get("units", "C") === "F" ? c * 9 / 5 + 32 : c;
}
function tempUnit() { return LS.get("units", "C") === "F" ? "°F" : "°C"; }

function fmt(v, dp) { return v == null ? "--" : Number(v).toFixed(dp == null ? 1 : dp); }

function setReadout(id, value, unit, pct) {
    var el = $("v" + id);
    if (!el) return;
    if (value == null) {
        el.classList.add("stale");
        el.innerHTML = "--" + (unit ? "<u>" + unit + "</u>" : "");
    } else {
        el.classList.remove("stale");
        el.innerHTML = esc(value) + (unit ? "<u>" + unit + "</u>" : "");
    }
    var bar = $("b" + id);
    if (bar) bar.style.width = (pct == null ? 0 : Math.max(0, Math.min(100, pct))) + "%";
}

/* ---------------------------- 6. charts ------------------------------- */
/* Small dependency-free line plot: neon stroke, soft fill, theme aware. */
function plot(canvas, labels, series) {
    if (!canvas) return;
    var box = canvas.parentNode;
    var dpr = window.devicePixelRatio || 1;
    var w = box.clientWidth, h = box.clientHeight;
    if (!w || !h) return;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    var g = canvas.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);

    var css = getComputedStyle(document.documentElement);
    var gridColor = css.getPropertyValue("--chart-grid").trim() || "rgba(255,255,255,.08)";
    var dimColor = css.getPropertyValue("--dim").trim() || "#888";
    var padL = 34, padR = 10, padT = 12, padB = 22;
    var pw = w - padL - padR, ph = h - padT - padB;
    if (pw <= 10 || ph <= 10) return;

    var all = [];
    series.forEach(function (s) { s.data.forEach(function (v) { if (v != null) all.push(v); }); });
    var lo = 0, hi = 100;
    if (all.length) {
        lo = Math.min.apply(null, all);
        hi = Math.max.apply(null, all);
        var pad = (hi - lo) * 0.15 || 5;
        lo = Math.floor(lo - pad); hi = Math.ceil(hi + pad);
        if (hi - lo < 4) { hi = lo + 4; }
    }

    g.font = "10px ui-monospace, Consolas, monospace";
    g.textBaseline = "middle";
    g.strokeStyle = gridColor;
    g.fillStyle = dimColor;
    g.lineWidth = 1;
    for (var i = 0; i <= 4; i++) {
        var y = padT + (ph / 4) * i;
        g.beginPath(); g.moveTo(padL, y); g.lineTo(padL + pw, y); g.stroke();
        var val = hi - ((hi - lo) / 4) * i;
        g.textAlign = "right";
        g.fillText(Math.round(val), padL - 6, y);
    }

    if (!all.length) {
        g.textAlign = "center";
        g.fillText(tr("waitingBoard", "waiting for board").toUpperCase(), padL + pw / 2, padT + ph / 2);
        return;
    }

    var n = Math.max(labels.length, 2);
    var xAt = function (i) { return padL + (pw / (n - 1)) * i; };
    var yAt = function (v) { return padT + ph - ((v - lo) / (hi - lo)) * ph; };

    /* x labels: first, middle, last only - a dense axis is noise here */
    g.textAlign = "center";
    [0, Math.floor((labels.length - 1) / 2), labels.length - 1].forEach(function (i) {
        if (labels[i] == null) return;
        g.fillText(labels[i], Math.min(padL + pw - 14, Math.max(padL + 14, xAt(i))), h - padB / 2);
    });

    series.forEach(function (s) {
        var pts = [];
        s.data.forEach(function (v, i) { if (v != null) pts.push([xAt(i), yAt(v)]); });
        if (pts.length < 1) return;

        if (s.fill) {
            var grad = g.createLinearGradient(0, padT, 0, padT + ph);
            grad.addColorStop(0, s.color + "38");
            grad.addColorStop(1, s.color + "00");
            g.beginPath();
            g.moveTo(pts[0][0], padT + ph);
            pts.forEach(function (p) { g.lineTo(p[0], p[1]); });
            g.lineTo(pts[pts.length - 1][0], padT + ph);
            g.closePath();
            g.fillStyle = grad;
            g.fill();
        }

        g.beginPath();
        pts.forEach(function (p, i) { i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]); });
        g.strokeStyle = s.color;
        g.lineWidth = s.width || 2;
        g.lineJoin = "round";
        g.shadowColor = s.color;
        g.shadowBlur = document.documentElement.dataset.theme === "light" ? 0 : 9;
        g.stroke();
        g.shadowBlur = 0;

        if (pts.length === 1) {
            g.fillStyle = s.color;
            g.beginPath(); g.arc(pts[0][0], pts[0][1], 3, 0, 6.3); g.fill();
        }
        var last = pts[pts.length - 1];
        g.fillStyle = s.color;
        g.beginPath(); g.arc(last[0], last[1], 2.6, 0, 6.3); g.fill();
    });
}

function C(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

function drawLive() {
    plot($("livePlot"), live.t, [
        { data: live.soil, color: C("--lime"), fill: true },
        { data: live.temp, color: C("--amber") },
        { data: live.hum, color: C("--cyan") },
        { data: live.water, color: C("--violet") },
        { data: live.gas, color: C("--magenta") }
    ]);
}

var histCache = { labels: [], soil: [], temp: [], hum: [], water: [], gas: [] };
function drawHist() {
    plot($("histPlot"), histCache.labels, [
        { data: histCache.soil, color: C("--lime"), fill: true },
        { data: histCache.temp, color: C("--amber") },
        { data: histCache.hum, color: C("--cyan") },
        { data: histCache.water, color: C("--violet") },
        { data: histCache.gas, color: C("--magenta") }
    ]);
}

/* ---------------------------- 7. routing ------------------------------ */
function setTitle(p) {
    $("pageTitle").textContent = tr(p, p.charAt(0).toUpperCase() + p.slice(1));
}

function go(p) {
    page = p;
    qsa(".page").forEach(function (s) { s.classList.add("hidden"); });
    var sec = $("page-" + p);
    if (sec) sec.classList.remove("hidden");
    qsa("#nav button[data-page]").forEach(function (b) { b.classList.toggle("active", b.dataset.page === p); });
    var moreBtn = $("navMore");
    if (moreBtn) moreBtn.classList.toggle("active", ["panel", "analytics", "history", "camera", "device", "settings"].indexOf(p) !== -1);
    setTitle(p);
    LS.set("page", p);
    closeMoreSheet();
    var scroller = document.querySelector("main"); if (scroller) scroller.scrollTop = 0;

    if (p === "history") loadHistory();
    if (p === "analytics") { loadAnalytics(); }
    if (p === "plants") loadPlants();
    if (p === "irrigation" || p === "settings" || p === "ai") loadSettings();
    if (p === "ai") updateAiLiveSummary();
    if (p === "camera") { stopCamera(); }
    if (p === "panel") panelShow(); else panelHide();
    if (p !== "camera") stopCamera();
    if (p === "device") { loadServer(); paintDevice(); }
    requestAnimationFrame(function () { drawLive(); drawHist(); });
}


/* ---------------------------- panel (HUD) page ---------------------------- */
var panelInfo = null, panelTimer = null;
function panelFrameSrc() { return "panel.html?embed=1" + (API ? "&api=" + encodeURIComponent(API) : ""); }
function panelShow() {
    var f = $("panelFrame");
    if (f && !f.getAttribute("data-on")) { f.setAttribute("data-on", "1"); f.src = panelFrameSrc(); }
    panelPoll();
    if (panelTimer) clearInterval(panelTimer);
    panelTimer = setInterval(panelPoll, 3000);
}
function panelHide() {
    panelFull(false);
    if (panelTimer) { clearInterval(panelTimer); panelTimer = null; }
    var f = $("panelFrame");
    if (f && f.getAttribute("data-on")) { f.removeAttribute("data-on"); f.src = "about:blank"; }   // stops its polling while hidden
}
function panelPoll() {
    api("/api/panel").then(function (d) { panelInfo = d; panelPaintBar(); })
        .catch(function () { panelInfo = null; panelPaintBar(); });
}
function panelPaintBar() {
    var b = $("panelPcBtn"), st = $("panelPcState"), fs = $("panelPcFsBtn");
    if (!b) return;
    if (!panelInfo) { b.hidden = true; fs.hidden = true; st.textContent = ""; return; }   // direct-board mode: no PC server
    b.hidden = false;
    if (panelInfo.supported) {
        b.textContent = "PC panel window: " + (panelInfo.want ? "ON \u2192 turn OFF" : "OFF \u2192 turn ON");
        b.classList.toggle("primary", !!panelInfo.want);
        fs.hidden = !panelInfo.open;
        st.textContent = panelInfo.open ? "showing on the PC" : "";
    } else {
        b.textContent = ANDROID_APP ? "PC panel window (open desktop app on PC)" : "Open panel in new tab";
        fs.hidden = true; st.textContent = "";
    }
}
function panelPc() {
    if (panelInfo && !panelInfo.supported) {
        if (ANDROID_APP) { toast("Start the Smart Plant desktop app on the PC to use the PC panel window.", true); return; }
        window.open(url("/panel"), "_blank"); return;
    }
    post("/api/panel", { action: "toggle" }).then(function (d) {
        panelInfo = d; panelPaintBar();
        toast(d.want ? "PC panel ON" : "PC panel OFF");
    }).catch(function (e) { toast("Panel: " + (e.message || "failed"), true); });
}
function panelPcFullscreen() {
    post("/api/panel", { action: "fullscreen" }).then(function (d) { panelInfo = d; panelPaintBar(); })
        .catch(function (e) { toast("Panel: " + (e.message || "failed"), true); });
}
function panelFull(on) {
    var w = $("panelWrap");
    if (!w) return false;
    var was = w.classList.contains("full");
    w.classList.toggle("full", !!on);
    document.body.classList.toggle("panel-full", !!on);
    return was && !on;
}

/* ---------- phone app shell: "More" sheet, keyboard + zoom guards ---------- */
function closeMoreSheet() {
    var n = $("nav"), b = $("moreBackdrop");
    if (n) n.classList.remove("more-open");
    if (b) b.classList.remove("show");
}
function toggleMoreSheet() {
    var n = $("nav"), b = $("moreBackdrop");
    if (!n) return;
    var open = !n.classList.contains("more-open");
    n.classList.toggle("more-open", open);
    if (b) b.classList.toggle("show", open);
}
(function initAppShell() {
    function ready(fn) { if (document.readyState !== "loading") fn(); else document.addEventListener("DOMContentLoaded", fn); }
    ready(function () {
        var more = $("navMore"), back = $("moreBackdrop");
        if (more) more.addEventListener("click", function (e) { e.preventDefault(); e.stopPropagation(); toggleMoreSheet(); });
        if (back) back.addEventListener("click", closeMoreSheet);
        // Block pinch / double-tap zoom everywhere (iOS-style gesture events + multi-touch).
        ["gesturestart", "gesturechange", "gestureend"].forEach(function (ev) {
            document.addEventListener(ev, function (e) { e.preventDefault(); }, { passive: false });
        });
        document.addEventListener("touchmove", function (e) { if (e.touches && e.touches.length > 1) e.preventDefault(); }, { passive: false });
        var lastTap = 0, lastTapEl = null;
        document.addEventListener("touchend", function (e) {
            var now = Date.now();
            if (now - lastTap < 300 && e.target === lastTapEl && !/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) e.preventDefault();
            lastTap = now; lastTapEl = e.target;
        }, { passive: false });
        // Keep the focused field visible above the on-screen keyboard.
        document.addEventListener("focusin", function (e) {
            var t = e.target;
            if (t && /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) setTimeout(function () { try { t.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (x) {} }, 320);
        });
        if (window.visualViewport) {
            var vv = window.visualViewport;
            var fit = function () { document.documentElement.style.setProperty("--vvh", vv.height + "px"); };
            vv.addEventListener("resize", fit); fit();
        }
    });
})();


/* ------------------------- 8. live telemetry -------------------------- */
function paintLink(ok, text) {
    var chip = $("linkChip");
    chip.classList.toggle("live", !!ok);
    $("linkText").textContent = text;
}

function refresh() {
    return api("/api/state").then(function (d) {
        S = d || {};
        syncSharedSettings(S.config_revision);
        updateAiLiveSummary();
        var on = S.connected != null ? !!S.connected : !!S.board_online;
        var th = num(S.soil_threshold, cfg.soil_threshold, 30);
        var safe = num(S.water_safety, cfg.water_safety, 20);

        setReadout("Soil", S.soil != null ? fmt(S.soil) : null, "%", S.soil);
        setReadout("Temp", S.temperature != null ? fmt(tempOut(S.temperature)) : null, tempUnit(), S.temperature != null ? (S.temperature / 50) * 100 : 0);
        setReadout("Hum", S.humidity != null ? fmt(S.humidity) : null, "%", S.humidity);
        setReadout("Wtemp", S.water_temp != null ? fmt(tempOut(S.water_temp)) : null, tempUnit(), S.water_temp != null ? (S.water_temp / 40) * 100 : 0);
        setReadout("Water", S.water != null ? fmt(S.water) : null, "%", S.water);
        setReadout("Gas", S.gas != null ? fmt(S.gas) : null, "%", S.gas);

        ["Soil", "Temp", "Hum", "Wtemp", "Water", "Gas"].forEach(function (id) {
            var valueEl = $("v" + id);
            if (valueEl) valueEl.classList.toggle("stale", !on && valueEl.textContent.trim() !== "--");
        });
        setReadout("Link", on ? "live" : "offline", "", on ? 100 : 0);

        $("fSoil").textContent = "start below " + th + "%";
        $("fWater").textContent = "min " + safe + "%";
        $("fTemp").textContent = "range " + fmt(tempOut(num(cfg.temp_min, null, 10)), 0) + "–" + fmt(tempOut(num(cfg.temp_max, null, 45)), 0) + tempUnit();
        $("fLink").textContent = on ? "last " + (S.last_seen || "--") : "no telemetry";
        $("cardLink").classList.toggle("alarm", !on);

        $("vLink").classList.toggle("stale", !on);
        $("dState").textContent = on ? "connected" : "offline";
        $("dName").textContent = S.board_name || "--";
        $("dType").textContent = S.board_type || "--";
        $("dFirmware").textContent = S.firmware || "--";
        $("dSeen").textContent = S.last_seen || "--";
        $("dUptime").textContent = S.uptime || "--";
        $("dMode").textContent = S.link_mode || (caps.settings ? "push" : "direct board");

        var alerts = S.alerts || [];
        renderAlerts(alerts);
        $("tHealth").textContent = !on ? "offline" : (alerts.length ? "warning" : "ok");
        $("tRuntime").textContent = S.pump_seconds != null ? S.pump_seconds + "s" : (S.pump ? "running" : "--");
        if (S.control_events != null) $("tEvents").textContent = S.control_events;

        var auto = $("autoBtn"), pump = $("pumpBtn"), run = $("runBtn");
        auto.dataset.on = S.auto_mode ? "1" : "0";
        auto.textContent = S.auto_mode ? tr("on", "on") : tr("off", "off");
        pump.dataset.on = S.pump ? "1" : "0";
        pump.textContent = S.pump ? tr("on", "on") : tr("off", "off");
        auto.disabled = pump.disabled = run.disabled = !on;

        $("plotBadge").textContent = on ? "live telemetry" : tr("waitingBoard", "waiting for board");
        $("plotBadge").classList.toggle("live", on);
        $("ctrlNotice").textContent = on
            ? "Board is live. Manual control overrides auto irrigation until the next cycle."
            : tr("lockedNotice", "Controls stay locked until the board sends live telemetry.");
        $("ctrlNotice").classList.toggle("ok", on);

        $("pumpHint").textContent = tr("pumpHint", "manual override");

        paintLink(on, on ? "board connected · live" : "board not connected");

        if (on) {
            var stamp = new Date();
            live.t.push(pad(stamp.getHours()) + ":" + pad(stamp.getMinutes()) + ":" + pad(stamp.getSeconds()));
            live.soil.push(S.soil); live.temp.push(S.temperature);
            live.hum.push(S.humidity); live.water.push(S.water); live.gas.push(S.gas);
            if (live.t.length > 40) {
                ["t", "soil", "temp", "hum", "water", "gas"].forEach(function (k) { live[k].shift(); });
            }
            if (page === "dashboard") drawLive();
        }
    }).catch(function () {
        paintLink(false, API ? "server unreachable" : "server unavailable");
        setReadout("Link", "offline", "", 0);
        $("cardLink").classList.add("alarm");
        renderAlerts([{ level: "critical", title: "No link to the controller", details: "Check Wi-Fi and the address on the Settings page." }]);
    });
}
/* Pull settings changed by the other client without overwriting active edits. */
function syncSharedSettings(revision) {
    if (!caps.settings || revision == null || Number(revision) === Number(cfgRevision) || settingsSyncInFlight) return;
    var active = document.activeElement;
    if (active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName || "")) return;
    settingsSyncInFlight = true;
    api("/api/settings").then(function (data) {
        if (!data || data.ok === false) return;
        cfgRevision = Number(data.config_revision || revision);
        cfg = data;
        cacheSettings(data);
        applySettingsForm(data);
    }).catch(function () {}).then(function () {
        settingsSyncInFlight = false;
    });
}
function pad(n) { return (n < 10 ? "0" : "") + n; }
function num(a, b, c) { return a != null ? a : (b != null ? b : c); }

function renderAlerts(list) {
    var box = $("alertList");
    var marks = { critical: "✕", warning: "!", ok: "✓" };
    box.innerHTML = list.length
        ? list.map(function (a) {
            return '<div class="alert ' + esc(a.level) + '"><span class="mark">' + (marks[a.level] || "·") +
                "</span><div><b>" + esc(a.title) + "</b><p>" + esc(a.details) + "</p></div></div>";
        }).join("")
        : '<div class="alert ok"><span class="mark">✓</span><div><b>All clear</b><p>No active alerts.</p></div></div>';
    $("alertBadge").textContent = list.length;
    var tag = $("navAlerts");
    tag.textContent = list.length ? list.length : "";
    tag.setAttribute("data-count", list.length);
    $("alertBadge").classList.toggle("hot", list.length > 0);
}

/* ---------------------------- 9. controls ----------------------------- */
function ctrl(action, extra) {
    var body = { action: action };
    if (extra) Object.keys(extra).forEach(function (k) { body[k] = extra[k]; });
    return post("/api/control", body).then(function (d) {
        if (!d.ok) { toast(d.error || "Control rejected", true); }
        return refresh().then(function () { return d; });
    }).catch(function (e) {
        toast("Could not reach the controller.", true);
        return { ok: false, error: String((e && e.message) || "controller unreachable") };
    });
}

/* --------------------------- 10. settings ----------------------------- */
/* ------------------- robust settings persistence --------------------- */

/*
 * SETTINGS DESIGN
 *
 * 1. Always save settings locally first.
 * 2. Try server save when server is available.
 * 3. If server save fails, keep the local settings.
 * 4. Queue server changes for later sync.
 * 5. Reload uses server first, then local cache.
 * 6. Direct-board mode can still keep device settings.
 */

var SETTINGS_CACHE_KEY = "settings_cache_v5";
var PENDING_SETTINGS_KEY = "settings_pending_v5";


function jsonGet(key, fallback) {
    try {
        var raw = LS.get(key, "");
        if (!raw) return fallback;

        var value = JSON.parse(raw);

        return value;
    } catch (e) {
        return fallback;
    }
}


function jsonSet(key, value) {
    try {
        LS.set(key, JSON.stringify(value));
    } catch (e) {
        /* localStorage may be unavailable in unusual WebView/private modes */
    }
}


function cacheSettings(data) {

    if (!data || typeof data !== "object") {
        return;
    }

    var safe = {};

    Object.keys(data).forEach(function (key) {

        /*
         * Never cache the real board token.
         */
        if (key === "board_token") {
            return;
        }

        safe[key] = data[key];
    });


    if (safe.io && typeof safe.io === "object") {
        safe.io = Object.assign({}, safe.io);
    }


    /*
     * Mark this as local cache data.
     */
    safe._local_settings_cache = true;
    safe._saved_at = new Date().toISOString();


    jsonSet(SETTINGS_CACHE_KEY, safe);
}


function cachedSettings() {
    return jsonGet(SETTINGS_CACHE_KEY, null);
}


function hasCachedSettings() {

    var local = cachedSettings();

    return !!(
        local &&
        typeof local === "object" &&
        Object.keys(local).length > 1
    );
}


function queueSettings(body) {

    var queue = jsonGet(PENDING_SETTINGS_KEY, []);

    if (!Array.isArray(queue)) {
        queue = [];
    }


    var clean = Object.assign({}, body || {});


    /*
     * Never queue the board token.
     */
    delete clean.board_token;


    clean._queued_at = new Date().toISOString();


    queue.push(clean);


    /*
     * Keep only the latest 20 changes.
     */
    queue = queue.slice(-20);


    jsonSet(PENDING_SETTINGS_KEY, queue);
}


function clearPendingSettings() {
    jsonSet(PENDING_SETTINGS_KEY, []);
}


function pendingSettings() {

    var queue = jsonGet(PENDING_SETTINGS_KEY, []);

    return Array.isArray(queue) ? queue : [];
}


/*
 * Try to send saved offline changes to the PC server.
 */
function syncPendingSettings() {

    if (!API) {
        return Promise.resolve(false);
    }


    if (!caps.settings) {
        return Promise.resolve(false);
    }


    var queue = pendingSettings();


    if (!queue.length) {
        return Promise.resolve(true);
    }


    var failed = false;

    var work = Promise.resolve();


    queue.forEach(function (body) {

        work = work.then(function () {

            if (failed) {
                return;
            }


            return post("/api/settings", body)

                .then(function (result) {

                    if (!result || result.ok !== true) {
                        failed = true;
                    }

                })

                .catch(function () {

                    failed = true;

                });

        });

    });


    return work.then(function () {

        if (!failed) {
            clearPendingSettings();
        }


        return !failed;

    });
}


/*
 * Put settings into the visible form.
 */
function applySettingsForm(data) {

    if (!data || typeof data !== "object") {
        return;
    }


    cfg = data;


    set("sThreshold", data.soil_threshold);
    set("sTarget", data.moisture_target);

    set("sMaxRuntime", data.max_runtime);

    set("sWaterSafety", data.water_safety);


    set(
        "sScheduleOn",
        data.schedule_enabled ? "1" : "0"
    );


    set("sScheduleTime", data.schedule_time);
    set("sScheduleSeconds", data.schedule_seconds);


    set("sTempMin", data.temp_min);
    set("sTempMax", data.temp_max);


    set("sHumMin", data.hum_min);
    set("sHumMax", data.hum_max);


    set("sGasAlert", data.gas_alert);


    set("sBoardName", data.board_name);
    set("sBoardType", data.board_type);

    set("sLinkMode", data.link_mode);
    set("sBoardUrl", data.board_url);

    set("sTimeout", data.connection_timeout);
    set("sRetention", data.retention_days);
    if ($("sAiEnabled")) $("sAiEnabled").checked = !!data.ai_enabled;
    if ($("sAiControl")) { $("sAiControl").checked = data.ai_control_enabled == null ? LS.get("ai_control_enabled", "1") !== "0" : !!data.ai_control_enabled; }
    set("sAiModel", "GPT-OSS 20B (Groq)"); if ($("sAiProvider")) $("sAiProvider").value = "Groq"; if ($("sAiModelLabel")) $("sAiModelLabel").textContent = "GPT-OSS 20B (Groq)";

        if ($("aiKeyState")) $("aiKeyState").textContent = data.groq_key_set ? "PC HUB KEY PRESENT • VERIFYING" : tr("keyNotSet", "PC AI key not configured");
        if ($("aiKeySettingsState")) $("aiKeySettingsState").textContent = data.groq_key_set ? ((data.groq_key_source || "PC HUB") + " • READY") : tr("keyNotSet", "NOT CONFIGURED");


    var io = data.io || {};


    set("ioSoil", io.soil);
    set("ioTH", io.temperature_humidity);
    set("ioWaterTemp", io.water_temp);
    set("ioWater", io.water);
    set("ioMq2", io.mq2);
    set("ioPump", io.pump);


    var matrix = [
        io.matrix_din || "",
        io.matrix_cs || "",
        io.matrix_clk || ""
    ].filter(function (v) {
        return v !== "";
    });


    set("ioMatrix", matrix.join(" / "));


    if ($("tokenState")) {

        $("tokenState").textContent =
            data.token_set
                ? "· set"
                : "· not set";

    }


    /*
     * Never repopulate the secret token.
     */
    if ($("sBoardToken")) {
        $("sBoardToken").value = "";
    }


    paintDevice();
}


/*
 * RELOAD SETTINGS
 *
 * Server first.
 * Local cache second.
 * No scary error when local settings already exist.
 */
function applyDirectBoardDefaults() {
    var d = {
        ok: true, board_name: (S && S.board_name) || "Smart Plant ESP32",
        board_type: (S && S.board_type) || "ESP32 DevKit 38-pin + Arduino UNO relay D7",
        link_mode: "direct", board_url: API || ((S && S.ip) || ""),
        connection_timeout: 6, soil_threshold: 30, moisture_target: 60,
        water_safety: 20, max_runtime: 600, schedule_enabled: false,
        schedule_time: "06:30", schedule_seconds: 20, temp_min: 10, temp_max: 45,
        hum_min: 25, hum_max: 95, gas_alert: 60, retention_days: 30,
        io: { soil: "GPIO34", temperature_humidity: "GPIO4", water_temp: "GPIO33",
              water: "GPIO35", mq2: "GPIO32", pump: "UNO D7 via UART",
              matrix_din: "GPIO23", matrix_cs: "GPIO5", matrix_clk: "GPIO18" },
        token_set: false, ai_enabled: false, ai_model: "openai/gpt-oss-20b", groq_key_set: false, weather_key_set: false, weather_location: LS.get("weather_location", ""), _direct_board_defaults: true
    };
    cacheSettings(d);
    applySettingsForm(d);
    return d;
}

function loadSettings(announce, triesLeft) {

    /*
     * Direct board / no settings API:
     * use local device settings.
     */
    if (!caps.settings) {

        var directLocal = cachedSettings();

        if (directLocal) {

            applySettingsForm(directLocal);

            if (announce) {
                toast("Saved settings loaded from this device.");
            }

            return Promise.resolve(directLocal);
        }


        applyDirectBoardDefaults();
        if (announce) {
            toast("Direct ESP32 settings loaded on this device.");
        }
        return Promise.resolve(cfg);
    }


    if (triesLeft === undefined) {
        triesLeft = 2;
    }


    return api("/api/settings")

        .then(function (data) {

            if (!data || data.ok === false) {
                throw new Error(
                    (data && data.error) ||
                    "SETTINGS_READ_FAILED"
                );
            }


            /*
             * Server values become the new local cache.
             */
            cacheSettings(data);

            applySettingsForm(data);


            if (announce) {
                toast("Settings reloaded.");
            }


            return data;

        })


        .catch(function () {

            /*
             * Retry server a small number of times.
             */
            if (triesLeft > 0) {

                return new Promise(function (resolve) {

                    setTimeout(resolve, 700);

                }).then(function () {

                    return loadSettings(
                        announce,
                        triesLeft - 1
                    );

                });

            }


            /*
             * SERVER FAILED.
             *
             * Local cache is the recovery path.
             */
            var local = cachedSettings();


            if (local) {

                applySettingsForm(local);


                if (announce) {
                    toast(
                        "Server unavailable. Saved settings loaded from this device."
                    );
                }


                return local;
            }


            /*
             * Do not leave the UI in an unexplained state.
             */
            if (announce) {

                toast(
                    "No saved settings found. Connect to the PC server to load them.",
                    true
                );

            }


            return null;
        });
}


function set(id, value) {

    var element = $(id);

    if (!element) {
        return;
    }


    if (element.tagName === "SELECT" && value != null && value !== "") {
        var has = false;
        for (var i = 0; i < element.options.length; i++) {
            if (element.options[i].value === String(value)) { has = true; break; }
        }
        if (!has) {
            var opt = document.createElement("option");
            opt.value = String(value); opt.textContent = String(value);
            element.insertBefore(opt, element.firstChild);
        }
    }

    element.value =
        value == null
            ? ""
            : value;
}


function val(id) {

    return $(id)
        ? $(id).value
        : "";
}


function n(id) {

    var value = Number(val(id));

    return isFinite(value)
        ? value
        : 0;
}


/*
 * SAVE IRRIGATION SETTINGS
 *
 * LOCAL FIRST
 */
function saveIrrigation() {

    var body = {

        soil_threshold: n("sThreshold"),
        moisture_target: n("sTarget"),

        max_runtime: n("sMaxRuntime"),

        water_safety: n("sWaterSafety"),

        schedule_enabled:
            val("sScheduleOn") === "1",

        schedule_time:
            val("sScheduleTime"),

        schedule_seconds:
            n("sScheduleSeconds"),

        temp_min:
            n("sTempMin"),

        temp_max:
            n("sTempMax"),

        hum_min:
            n("sHumMin"),

        hum_max:
            n("sHumMax"),

        gas_alert:
            n("sGasAlert")
    };


    /*
     * Update local copy immediately.
     */
    var local =
        Object.assign({}, cfg || {}, body);


    cacheSettings(local);

    applySettingsForm(local);


    /*
     * Direct-board mode:
     * local save is still valid.
     */
    if (!caps.settings || !API) {

        toast(
            "Irrigation settings saved on this device."
        );

        return Promise.resolve(local);
    }


    /*
     * Server save.
     */
    return post("/api/settings", body)

        .then(function (data) {

            if (!data || data.ok !== true) {

                throw new Error(
                    (data && data.error) ||
                    "SAVE_SETTINGS_FAILED"
                );

            }


            toast("Irrigation settings saved.");


            /*
             * Refresh from server so the UI is authoritative.
             */
            return loadSettings(false);

        })


        .catch(function () {

            /*
             * Keep local settings and queue them.
             */
            queueSettings(body);


            applySettingsForm(local);


            toast(
                "Saved on this device. Server sync will retry automatically."
            );


            return local;

        });
}


/*
 * SAVE CONTROLLER SETTINGS
 *
 * LOCAL FIRST
 */
function saveSystem() {

    LS.set("units", val("sUnits"));
    LS.set("poll", val("sPoll"));
    LS.set("auto_scan", $("sAutoScan") && $("sAutoScan").checked ? "1" : "0");

    restartTimer();


    var matrixParts =
        val("ioMatrix")
            .split("/")
            .map(function (x) {
                return x.trim();
            });


    var body = {

        board_name:
            val("sBoardName"),

        board_type:
            val("sBoardType"),

        link_mode:
            val("sLinkMode"),

        board_url:
            val("sBoardUrl"),

        connection_timeout:
            n("sTimeout"),

        io: {

            soil:
                val("ioSoil"),

            temperature_humidity:
                val("ioTH"),

            water_temp:
                val("ioWaterTemp"),

            water:
                val("ioWater"),

            mq2:
                val("ioMq2"),

            pump:
                val("ioPump"),

            matrix_din:
                matrixParts[0] || "",

            matrix_cs:
                matrixParts[1] || "",

            matrix_clk:
                matrixParts[2] || ""
        }
    };


    /*
     * Token is ONLY sent to server.
     * It is never stored in localStorage.
     */
    var enteredToken =
        val("sBoardToken").trim();


    if (enteredToken) {
        body.board_token = enteredToken;
    }


    /*
     * Local copy without token.
     */
    var local =
        Object.assign({}, cfg || {});


    Object.keys(body).forEach(function (key) {

        if (key !== "board_token") {
            local[key] = body[key];
        }

    });


    cacheSettings(local);

    applySettingsForm(local);


    /*
     * Direct board mode / no API:
     * still save locally.
     */
    if (!caps.settings || !API) {

        toast(
            "Controller settings saved on this device."
        );

        return Promise.resolve(local);
    }


    /*
     * Try server.
     */
    return post("/api/settings", body)

        .then(function (data) {

            if (!data || data.ok !== true) {

                throw new Error(
                    (data && data.error) ||
                    "SAVE_SETTINGS_FAILED"
                );

            }


            toast("Controller settings saved.");


            return loadSettings(false);

        })


        .catch(function () {

            /*
             * Never queue the board token.
             */
            var queued =
                Object.assign({}, body);

            delete queued.board_token;


            queueSettings(queued);

            applySettingsForm(local);


            toast(
                "Saved on this device. Server sync will retry automatically."
            );


            return local;

        });
}


/*
 * SAVE DATA SETTINGS
 */
function saveData() {

    LS.set("units", val("sUnits"));
    LS.set("poll", val("sPoll"));

    restartTimer();


    var body = {

        retention_days:
            n("sRetention")
    };


    var local =
        Object.assign({}, cfg || {}, body);


    cacheSettings(local);

    applySettingsForm(local);


    /*
     * Local save always works.
     */
    if (!caps.settings || !API) {

        toast(
            "Data settings saved on this device."
        );

        return Promise.resolve(local);
    }


    return post("/api/settings", body)

        .then(function (data) {

            if (!data || data.ok !== true) {

                throw new Error(
                    (data && data.error) ||
                    "SAVE_SETTINGS_FAILED"
                );

            }


            toast("Data settings saved.");


            return loadSettings(false);

        })


        .catch(function () {

            queueSettings(body);

            applySettingsForm(local);


            toast(
                "Saved on this device. Server sync will retry automatically."
            );


            return local;

        });
}


function lockServerFields() {

    [
        "sThreshold",
        "sTarget",
        "sMaxRuntime",
        "sWaterSafety",

        "sScheduleOn",
        "sScheduleTime",
        "sScheduleSeconds",

        "sTempMin",
        "sTempMax",

        "sHumMin",
        "sHumMax",

        "sGasAlert",

        "sBoardName",
        "sBoardType",

        "sLinkMode",
        "sBoardUrl",

        "sTimeout",

        "sBoardToken",

        "ioSoil",
        "ioTH",
        "ioWaterTemp",
        "ioWater",
        "ioMq2",
        "ioPump",
        "ioMatrix",

        "sRetention"

    ].forEach(function (id) {

        if ($(id)) {
            $(id).disabled = true;
        }

    });
}

/* ----------------------- 11. history / analytics ---------------------- *//* ----------------------- 11. history / analytics ---------------------- */
/* Phone layout shows table rows as cards; each cell gets its column title (data-label). */
function labelRows(tbodyId) {
    var tb = $(tbodyId); if (!tb || !tb.parentNode) return;
    var heads = [].map.call(tb.parentNode.querySelectorAll("thead th"), function (h) { return h.textContent.trim(); });
    [].forEach.call(tb.rows, function (tr) {
        [].forEach.call(tr.cells, function (td, i) { td.setAttribute("data-label", heads[i] || ""); });
    });
}

function loadHistory() {
    if (!caps.history) {
        $("histBody").innerHTML = "";
        $("histEmpty").classList.remove("hidden");
        $("histEmpty").textContent = "Stored history needs the PC server. This link talks to the board directly.";
        return;
    }
    var minutes = val("rangeHistory") || 60;
    api("/api/history?minutes=" + minutes).then(function (d) {
        var rows = d.rows || [];
        $("histBody").innerHTML = rows.map(function (r) {
            return "<tr><td>" + esc(r.timestamp) + "</td><td>" + fmt(r.soil) + "%</td><td>" +
                fmt(tempOut(r.temperature)) + "°</td><td>" + fmt(r.humidity) + "%</td><td>" +
                fmt(r.water) + "%</td><td>" + fmt(r.gas) + "%</td><td>" +
                fmt(tempOut(r.water_temp)) + "°</td><td class=\"" +
                (r.pump ? "on" : "off") + '">' + (r.pump ? "on" : "off") + "</td></tr>";
        }).join("");
        labelRows("histBody");
        $("histEmpty").classList.toggle("hidden", rows.length > 0);

        var ev = d.events || [];
        $("eventBody").innerHTML = ev.map(function (e) {
            return "<tr><td>" + esc(e.timestamp) + "</td><td>" + esc(e.event) + "</td><td>" + esc(e.details) + "</td></tr>";
        }).join("");
        labelRows("eventBody");
        $("eventEmpty").classList.toggle("hidden", ev.length > 0);
        $("eventBadge").textContent = ev.length;
        $("tEvents").textContent = ev.filter(function (e) { return e.event === "Control" || e.event === "Auto"; }).length;
    }).catch(function () { $("histEmpty").classList.remove("hidden"); });
}

function loadAnalytics() {
    if (!caps.history) {
        $("analyticsMeta").textContent = "Analytics needs the PC server. This link talks to the board directly.";
        return;
    }
    var minutes = val("rangeAnalytics") || 60;
    api("/api/analytics?minutes=" + minutes).then(function (d) {
        var a = d.averages || {}, x = d.extremes || {};
        putAvg("aSoil", a.soil, "%", x.soil);
        putAvg("aTemp", tempOut(a.temperature), tempUnit(), x.temperature, true);
        putAvg("aHum", a.humidity, "%", x.humidity);
        putAvg("aWater", a.water, "%", x.water);
        putAvg("aGas", a.gas, "%", x.gas);
        putAvg("aWtemp", tempOut(a.water_temp), tempUnit(), x.water_temp, true);
        var samples = $("aSamples");
        samples.textContent = d.samples || 0;
        samples.classList.toggle("stale", !d.samples);
        $("aWaterUse").textContent = "pump cycles " + (d.pump_cycles == null ? "--" : d.pump_cycles);
        $("analyticsMeta").textContent = (d.samples || 0) + " stored samples in the selected range.";
        $("histBadge").textContent = (d.samples || 0) + " samples";
        drawHistFrom(minutes);
    }).catch(function () { $("analyticsMeta").textContent = "Analytics unavailable."; });
}

function putAvg(id, v, unit, ex, conv, dp) {
    var el = $(id);
    el.classList.toggle("stale", v == null);
    el.innerHTML = v == null ? "--" : fmt(v, dp) + (unit ? "<u>" + unit + "</u>" : "");
    var f = $(id + "X");
    if (f) {
        if (!ex || ex.min == null) f.textContent = "min/max --";
        else {
            var lo = conv ? tempOut(ex.min) : ex.min, hi = conv ? tempOut(ex.max) : ex.max;
            f.textContent = "min " + fmt(lo, dp) + " · max " + fmt(hi, dp);
        }
    }
}

function drawHistFrom(minutes) {
    api("/api/history?minutes=" + minutes).then(function (d) {
        var rows = (d.rows || []).slice().reverse();
        histCache = {
            labels: rows.map(function (r) { return r.timestamp.slice(11, 16); }),
            soil: rows.map(function (r) { return r.soil; }),
            temp: rows.map(function (r) { return r.temperature; }),
            hum: rows.map(function (r) { return r.humidity; }),
            water: rows.map(function (r) { return r.water; }),
            gas: rows.map(function (r) { return r.gas; })
        };
        drawHist();
    }).catch(function () {});
}

function exportCsv() {
    if (!caps.history) return toast("Export needs the PC server.", true);
    var minutes = val("rangeHistory") || 60;
    var link = url("/api/export?minutes=" + minutes);
    if (API) { window.open(link, "_blank"); } else { window.location.href = link; }
}

function clearHistory() {
    if (!caps.history) return toast("Not available in direct board mode.", true);
    if (!confirm("Delete all stored samples and events? This cannot be undone.")) return;
    post("/api/history/clear", {}).then(function (d) {
        d.ok ? toast("Stored history cleared.") : toast(d.error || "Failed", true);
        loadHistory(); loadAnalytics();
    }).catch(function () { toast("Failed.", true); });
}

/* ---------------------------- 12. plants ------------------------------ */
function loadPlants() {
    if (!caps.plants) {
        $("plantList").innerHTML = '<div class="empty">Plant profiles are stored by the PC server.</div>';
        return;
    }
    api("/api/plants").then(function (rows) {
        if (!rows || !rows.length) {
            $("plantList").innerHTML = '<div class="empty">No plant profiles yet. Add one to record what a plant needs.</div>';
            return;
        }
        $("plantList").innerHTML = rows.map(function (p) {
            return '<div class="plant"><h4>' + esc(p.name) + '</h4><div class="meta">' +
                esc(p.plant_type) + " · " + esc(p.zone) + '</div><div class="range">water below ' +
                p.moisture_min + "% · stop at " + p.moisture_target + "%</div><p>" +
                (esc(p.notes) || "&nbsp;") + '</p><div class="plant-foot">' +
                '<button class="btn sm" onclick="SP.applyPlant(' + p.id + ')">Apply</button>' +
                '<button class="btn sm" onclick="SP.editPlant(' + p.id + ')">Edit</button>' +
                '<button class="btn sm danger" onclick="SP.deletePlant(' + p.id + ')">Delete</button>' +
                "</div></div>";
        }).join("");
        window.__plants = rows;
    }).catch(function () {
        $("plantList").innerHTML = '<div class="empty">Could not load plant profiles.</div>';
    });
}

function openPlant() {
    set("pId", ""); set("pName", ""); set("pType", "Custom"); set("pZone", "Zone 1");
    set("pMin", 30); set("pTarget", 60); set("pNotes", "");
    $("plantModalTitle").textContent = tr("addPlant", "Add plant");
    $("plantModal").classList.remove("hidden");
    $("pName").focus();
}

function editPlant(id) {
    var p = (window.__plants || []).filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    set("pId", p.id); set("pName", p.name); set("pType", p.plant_type); set("pZone", p.zone);
    set("pMin", p.moisture_min); set("pTarget", p.moisture_target); set("pNotes", p.notes);
    $("plantModalTitle").textContent = "Edit plant";
    $("plantModal").classList.remove("hidden");
}

function closePlant() { $("plantModal").classList.add("hidden"); }

function savePlant() {
    var body = {
        name: val("pName"), plant_type: val("pType"), zone: val("pZone"),
        moisture_min: n("pMin"), moisture_target: n("pTarget"), notes: val("pNotes")
    };
    if (!body.name.trim()) return toast("Give the plant a name.", true);
    var id = val("pId");
    var req = id
        ? api("/api/plants/" + id, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) })
        : post("/api/plants", body);
    req.then(function (d) {
        if (!d.ok) return toast(d.error || "Save failed", true);
        closePlant(); loadPlants(); toast(id ? "Plant updated." : "Plant added.");
    }).catch(function () { toast("Save failed.", true); });
}

function deletePlant(id) {
    if (!confirm("Delete this plant profile?")) return;
    api("/api/plants/" + id, { method: "DELETE" }).then(function (d) {
        d.ok ? toast("Plant deleted.") : toast(d.error || "Failed", true);
        loadPlants();
    }).catch(function () { toast("Failed.", true); });
}

function applyPlant(id) {
    var p = (window.__plants || []).filter(function (x) { return x.id === id; })[0];
    if (!p) return;
    post("/api/settings", { soil_threshold: p.moisture_min, moisture_target: p.moisture_target })
        .then(function (d) {
            if (!d.ok) return toast(d.error || "Could not apply", true);
            toast(p.name + " applied to irrigation settings.");
            loadSettings(); refresh();
        }).catch(function () { toast("Could not apply.", true); });
}

/* ---------------------------- 13. device ------------------------------ */
function loadServer() {
    if (!caps.server) { $("dServer").textContent = API || "direct board"; return; }
    api("/api/server-info").then(function (d) {
        var host = d.ok ? d.ip + ":" + d.port : "--";
        $("dServer").textContent = host;
        $("pushSample").textContent = $("pushSample").textContent.replace(/HOST/g, host);
        $("pollSample").textContent = $("pollSample").textContent.replace(/HOST/g, host);
    }).catch(function () { $("dServer").textContent = "--"; });
}

function paintDevice() {
    $("railTarget").textContent = API || "same device";
    set("sApiBase", API);
    if (cfg.io) {
        var pins = "soil " + (cfg.io.soil || "-") + " · th " + (cfg.io.temperature_humidity || "-") +
            " · wtemp " + (cfg.io.water_temp || "-") + " · water " + (cfg.io.water || "-") + " · mq2 " + (cfg.io.mq2 || "-") + " · pump " + (cfg.io.pump || "-");
        var el = $("dMode");
        el.title = pins;
    }
}

/* ------------------------- 13B. board scan UI -------------------------- */
var SCAN_ACTIVE = false;
var SCAN_STARTUP = false;
var SCAN_POLL = null;
var SCAN_STATUS_POLL = null;
var SCAN_FALLBACK = null;
var SCAN_OPEN_TIMER = null;
var SCAN_SHOWN_AT = 0;
var SCAN_MIN_VISIBLE_MS = 2200;
var SCAN_STATUS_FAILS = 0;

function scanOverlay(mode, startup) {
    var el = $("scanOverlay");
    if (!el) return;
    SCAN_ACTIVE = true;
    SCAN_STARTUP = !!startup;
    SCAN_SHOWN_AT = Date.now();
    el.classList.remove("hidden", "found", "error");
    el.setAttribute("aria-hidden", "false");
    var credit = el.querySelector(".scan-credit");
    if (credit) credit.classList.toggle("scan-is-android", ANDROID_APP);
    $("scanStatus").textContent = "SCANNING...";
    $("scanSub").textContent = ANDROID_APP
        ? "Scanning this phone's Wi-Fi network for the Smart Plant ESP32 controller"
        : "Scanning the local Wi-Fi network for the Smart Plant controller";
    $("scanMode").textContent = mode || "LAN DISCOVERY";
    $("scanTarget").textContent = "Preparing full LAN sweep...";
    $("scanChecked").textContent = "0 / 0";
    $("scanPct").textContent = "0%";
    if ($("scanPhase")) $("scanPhase").textContent = ANDROID_APP ? "INITIALIZING PHONE WIFI SCAN" : "INITIALIZING REAL LAN SCAN";
    $("scanFound").textContent = "Starting real network discovery...";
    $("scanFound").className = "scan-found";
    $("scanActionText").textContent = "STOP";
    el.style.setProperty("--scan-progress", "0deg");
}
function updateScanProgress(checked, total, target, pct) {
    var el=$("scanOverlay"); if(!el || !SCAN_ACTIVE) return;
    checked=Math.max(0,Number(checked)||0); total=Math.max(0,Number(total)||0);
    pct=total ? Math.max(0,Math.min(100,Number(pct)||Math.round(checked*100/total))) : 0;
    $("scanTarget").textContent=target || "Scanning LAN...";
    $("scanChecked").textContent=checked+" / "+total;
    $("scanPct").textContent=Math.round(pct)+"%";
    if ($("scanPhase")) {
        if (pct >= 99) $("scanPhase").textContent = "VERIFYING FINAL RESPONSE";
        else if (checked === 0) $("scanPhase").textContent = "BUILDING FULL LAN SWEEP";
        else $("scanPhase").textContent = "PROBING LIVE HOSTS // " + Math.round(pct) + "% COMPLETE";
    }
    el.style.setProperty("--scan-progress", (pct*3.6)+"deg");
    if($('scanFound')) $('scanFound').textContent = target ? "Probing " + target + " ..." : "Searching for Smart Plant controller...";
}
function finishScanUI(ip, err) {
    clearInterval(SCAN_POLL); SCAN_POLL=null;
    clearInterval(SCAN_STATUS_POLL); SCAN_STATUS_POLL=null;
    clearTimeout(SCAN_FALLBACK); SCAN_FALLBACK=null;
    var el=$("scanOverlay"); if(!el) return;
    if(ip){
        el.classList.add("found");
        updateScanProgress(1,1,ip,100);
        $("scanStatus").textContent="ESP32 FOUND";
        $("scanSub").textContent="Smart Plant ESP32 controller detected and ready";
        if ($("scanPhase")) $("scanPhase").textContent="ESP32 VERIFIED // CONNECTING TO LIVE TELEMETRY";
        $("scanPct").textContent="100%";
        $("scanFound").textContent="ESP32 FOUND • " + ip;
        $("scanFound").className="scan-found ok";
        $("scanActionText").textContent="OPEN";
        if(typeof set === "function") set("sBoardUrl", ip);
        if (ANDROID_APP) {
            if(typeof set === "function") set("sLinkMode", "direct");
            API = normalize(ip);
            DIRECT_BOARD = false;
            caps.settings = false;
            caps.history = false;
            caps.plants = false;
            caps.server = false;
            DIRECT_BOARD = true;
            lockServerFields();
            LS.set("api", API);
        } else {
            if(typeof set === "function") set("sLinkMode", "poll");
            // Windows desktop: keep the local Flask app as the UI/data host.
            // Its backend already stores the discovered ESP32 address and
            // forwards telemetry/control over the same local Wi-Fi. Switching
            // to direct-board mode here would silently disable PC history,
            // plants and persistent settings.
            API = "";
            DIRECT_BOARD = false;
            caps.settings = caps.history = caps.plants = caps.server = true;
            if (typeof cfg === "object" && cfg) cfg.board_url = ip;
            LS.set("api", "");
        }
        var elapsed = Date.now() - SCAN_SHOWN_AT;
        var wait = Math.max(1200, SCAN_MIN_VISIBLE_MS - elapsed);
        clearTimeout(SCAN_OPEN_TIMER);
        SCAN_OPEN_TIMER = setTimeout(function(){ openAfterScan(ip); }, wait);
    } else {
        el.classList.add("error");
        $("scanStatus").textContent=err ? "SCAN FAILED" : "NO SMART PLANT PC FOUND";
        $("scanSub").textContent=err || "Connect the phone to the same Wi-Fi as the Smart Plant ESP32 and scan again";
        if ($("scanPhase")) $("scanPhase").textContent=err ? "NETWORK SCAN STOPPED" : "FULL LAN SWEEP COMPLETE // NO SMART PLANT PC";
        $("scanFound").textContent=err || "No Smart Plant ESP32 controller answered on this network.";
        $("scanFound").className="scan-found fail";
        $("scanActionText").textContent="SCAN";
        SCAN_ACTIVE=false;
    }
}
function hideScanOverlay() {
    var x = $("scanOverlay");
    if (x) { x.classList.add("hidden"); x.setAttribute("aria-hidden", "true"); }
}
function openAfterScan(ip) {
    clearTimeout(SCAN_OPEN_TIMER); SCAN_OPEN_TIMER = null;
    hideScanOverlay();
    SCAN_ACTIVE = false;
    var wasStartup = SCAN_STARTUP;
    SCAN_STARTUP = false;
    if (wasStartup) { start(); }
    else { loadSettings(); refresh(); if (ip) toast("Board found at " + ip); }
}
function stopScan() {
    var ov = $("scanOverlay");
    if (ov && ov.classList.contains("found") && SCAN_OPEN_TIMER) { return openAfterScan(null); }
    if (!SCAN_ACTIVE) { return scanBoard(SCAN_STARTUP); }
    try {
        if (ANDROID_APP && window.AndroidBridge && window.AndroidBridge.stopScan) window.AndroidBridge.stopScan();
    } catch (e) {}
    window.__androidScanResult = null; window.__androidScanProgress = null;
    if (!ANDROID_APP) { post("/api/board/scan/stop", {}).catch(function () {}); }
    clearInterval(SCAN_STATUS_POLL); SCAN_STATUS_POLL = null;
    finishScanUI(null, "Scan stopped.");
}
function skipScan() {
    clearInterval(SCAN_POLL); SCAN_POLL = null;
    clearInterval(SCAN_STATUS_POLL); SCAN_STATUS_POLL = null;
    clearTimeout(SCAN_FALLBACK); SCAN_FALLBACK = null;
    clearTimeout(SCAN_OPEN_TIMER); SCAN_OPEN_TIMER = null;
    try {
        if (ANDROID_APP && window.AndroidBridge && window.AndroidBridge.stopScan) window.AndroidBridge.stopScan();
    } catch (e) {}
    window.__androidScanResult = null; window.__androidScanProgress = null;
    var wasStartup = SCAN_STARTUP;
    var wasActive = SCAN_ACTIVE;
    SCAN_ACTIVE = false;
    SCAN_STARTUP = false;
    if (wasActive && !ANDROID_APP) { post("/api/board/scan/stop", {}).catch(function () {}); }
    hideScanOverlay();
    if (wasStartup) { start(); }
}

function scanBoard(startup) {
    if(typeof startup !== "boolean") startup=false;
    scanOverlay(ANDROID_APP ? "SMART PLANT ESP32 SCAN" : "PC LAN SCAN", startup);
    if(ANDROID_APP){
        window.__androidScanProgress=function(checked,total,target,pct){ updateScanProgress(checked,total,target,pct); };
        window.__androidScanResult=function(ip){
            window.__androidScanResult=null; window.__androidScanProgress=null;
            finishScanUI(ip,null);
        };
        try {
            if(window.AndroidBridge && window.AndroidBridge.scanBoard) window.AndroidBridge.scanBoard();
            else finishScanUI(null,"Android scan bridge is unavailable.");
        } catch(e){ finishScanUI(null,"Android scan failed."); }
        SCAN_FALLBACK=setTimeout(function(){ finishScanUI(null,"Scan timed out. Check Wi-Fi and try again."); },20000);
        return;
    }
    // PC: the Flask backend starts the real LAN sweep in a background thread.
    // The status endpoint supplies the actual checked/total counts.
    $("scanTarget").textContent = "FULL LAN SWEEP /api/board/scan";
    $("scanChecked").textContent = "0 / calculating...";
    SCAN_STATUS_FAILS = 0;
    post("/api/board/scan",{}).then(function(d){
        if(!d || !d.ok){
            finishScanUI(null,(d&&d.error)||"Could not start the board scan.");
            return;
        }

        updateScanProgress(0, Number(d.total || 0), "Full LAN sweep started", 0);
        clearInterval(SCAN_STATUS_POLL);
        SCAN_STATUS_POLL = setInterval(function(){
            api("/api/board/scan/status").then(function(st){
                SCAN_STATUS_FAILS = 0;
                if(!st || !st.ok) return;
                updateScanProgress(st.checked, st.total, st.target, st.total ? (st.checked * 100 / st.total) : 0);
                if(st.active) return;
                clearInterval(SCAN_STATUS_POLL); SCAN_STATUS_POLL=null;
                if(st.found){ finishScanUI(st.found,null); }
                else { finishScanUI(null,st.error || "No Smart Plant ESP32 controller answered on this network."); }
            }).catch(function(){
                SCAN_STATUS_FAILS++;
                if (SCAN_STATUS_FAILS >= 12) {
                    clearInterval(SCAN_STATUS_POLL); SCAN_STATUS_POLL=null;
                    finishScanUI(null,"Scan status could not be read. Restart the PC app and run the full scan again.");
                }
            });
        }, 140);
        clearTimeout(SCAN_FALLBACK);
        SCAN_FALLBACK = setTimeout(function(){
            if (SCAN_ACTIVE) finishScanUI(null,"Full LAN scan timed out. Check Wi-Fi and firewall access.");
        }, 18000);
    }).catch(function(){ finishScanUI(null,"Could not start the full LAN scan."); });
}

function testLink() {
    if (!caps.settings) {
        return api("/api/state").then(function () { toast("Board answered."); })
            .catch(function () { toast("No answer from the board.", true); });
    }
    post("/api/board/test", {}).then(function (d) {
        d.ok ? toast("Board answered: " + (d.detail || "ok")) : toast(d.error || "No answer", true);
        refresh();
    }).catch(function () { toast("Test failed.", true); });
}

function copyAddress() {
    var text = ($("dServer") && $("dServer").textContent) || API || "";
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { toast("Address copied: " + text); },
            function () { toast(text); });
    } else { toast(text); }
}

/* --------------------------- 14A. camera ----------------------------- */
function startCamera() {
    var video = $("cameraVideo"), msg = $("cameraMsg");
    if (!video || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        if (msg) msg.textContent = "Camera API is not available in this browser.";
        return;
    }
    if (cameraStream) {
        video.srcObject = cameraStream;
        if (msg) msg.textContent = "Camera live.";
        return;
    }
    navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false })
        .then(function (stream) {
            cameraStream = stream;
            video.srcObject = stream;
            if (msg) msg.textContent = "Camera live.";
        })
        .catch(function (err) {
            if (msg) msg.textContent = "Camera permission denied or camera unavailable: " + (err && err.name ? err.name : "error");
        });
}

function stopCamera() {
    if (cameraStream) {
        cameraStream.getTracks().forEach(function (t) { t.stop(); });
        cameraStream = null;
    }
    var video = $("cameraVideo"), msg = $("cameraMsg");
    if (video) video.srcObject = null;
    if (msg) msg.textContent = "Camera is stopped.";
}

/* -------------------------- 14. theme / lang -------------------------- */
function setTheme(v, save) {
    var allowedThemes = ["cyber", "light", "forest", "ocean", "sunset", "violet"];
    if (allowedThemes.indexOf(v) === -1) v = "cyber";
    document.documentElement.dataset.theme = v;
    var meta = document.querySelector('meta[name="theme-color"]');
    var colors = {
        cyber: "#04090b", light: "#e8f1ec", forest: "#06110b",
        ocean: "#031018", sunset: "#170b08", violet: "#0a0714"
    };
    if (meta) meta.setAttribute("content", colors[v] || colors.cyber);
    if ($("sTheme")) $("sTheme").value = v;
    if ($("themeBtn")) $("themeBtn").textContent = v === "light" ? "☀" : "◐";
    if (save) LS.set("theme", v);
    requestAnimationFrame(function () { drawLive(); drawHist(); });
}

function cycleTheme() {
    var themes = ["cyber", "ocean", "forest", "violet", "sunset", "light"];
    var current = document.documentElement.dataset.theme || "cyber";
    var idx = themes.indexOf(current);
    setTheme(themes[(idx + 1) % themes.length], true);
}


/* --------------------------- AI + REAL VOICE -------------------------- */
var AI_MODEL_DEFAULT = "openai/gpt-oss-20b";
var AI_MODELS = ["openai/gpt-oss-20b"];
var AI_HISTORY_KEY = "ai_history_v42_18_16";

function safeAiModel(v){ return AI_MODEL_DEFAULT; }
function updateAiLiveSummary(){
    var box=$("aiLiveSummary");if(!box)return;
    var items=["Soil "+fmt(S&&S.soil,1)+"%","Temp "+fmt(S&&S.temperature,1)+"°C","Humidity "+fmt(S&&S.humidity,1)+"%","Water "+fmt(S&&S.water,1)+"%","Gas "+fmt(S&&S.gas,1)+"%","Water temp "+fmt(S&&S.water_temp,1)+"°C"];
    box.innerHTML=items.map(esc).map(function(x){return "<span>"+x+"</span>";}).join("");
}
function aiAdd(role,text){
    var box=$("aiChatWindow");if(!box)return;
    var el=document.createElement("div");el.className="chat-msg "+role;el.textContent=text;box.appendChild(el);box.scrollTop=box.scrollHeight;
}
function aiSystemMessage(text){aiAdd("meta",text);}
function saveAiHistory(){
    try { LS.set(AI_HISTORY_KEY,JSON.stringify(aiHistory.slice(-20))); } catch(e) {}
}
function loadAiHistory(){
    try {
        var raw=LS.get(AI_HISTORY_KEY,"");
        if(!raw)return;
        var arr=JSON.parse(raw);
        if(!Array.isArray(arr))return;
        aiHistory=arr.filter(function(x){return x&&typeof x.text==="string"&&(x.role==="user"||x.role==="assistant");}).slice(-20);
        var box=$("aiChatWindow");
        if(box){box.innerHTML="";aiHistory.forEach(function(x){aiAdd(x.role==="assistant"?"ai":"user",x.text);});}
    } catch(e) {}
}
function aiHistoryText(){return aiHistory.slice(-12).map(function(x){var role=x.role==="assistant"?"Assistant":"User";return role+": "+String(x.text||"").slice(0,1200);}).join("\n").slice(-7000);}
function liveAiContext(){
    return {connected:!!(S&&S.connected),soil:S&&S.soil,temperature:S&&S.temperature,humidity:S&&S.humidity,water:S&&S.water,gas:S&&S.gas,water_temp:S&&S.water_temp,pump:S&&S.pump,auto_mode:S&&S.auto_mode,water_safety:cfg&&cfg.water_safety,soil_threshold:cfg&&cfg.soil_threshold,moisture_target:cfg&&cfg.moisture_target,alerts:(S&&S.alerts)||[]};
}
function chooseSpeechVoice(lang){
    if(!window.speechSynthesis)return null;
    try{var voices=window.speechSynthesis.getVoices()||[];var wanted=lang==="si"?"si":(lang==="ja"?"ja":"en");
        var exact=voices.find(function(v){return v&&v.lang&&v.lang.toLowerCase().indexOf(wanted)===0;});
        if(exact)return exact;
        return voices.find(function(v){return v&&v.default;})||voices[0]||null;
    }catch(e){return null;}
}
/* --------------------------------------------------------------------------
   Reliable speech output
   - Android uses the native TextToSpeech bridge. Never send Android TTS audio
     through WebView <audio>, because that path can be blocked/muted on some
     WebView/device combinations.
   - PC uses the native Windows bridge first and falls back to the Flask TTS
     endpoint only when native playback fails.
   - A small promise queue prevents two replies from flushing each other.
   -------------------------------------------------------------------------- */
var speechQueue=Promise.resolve();
var speechQueueDepth=0;
var androidTtsWaiters=[];
var androidTtsWaiterSerial=0;

function speakTextNow(textValue){
    var clean=String(textValue||"").trim();
    if(!clean) return Promise.resolve(false);

    if(ANDROID_APP && window.AndroidBridge && typeof window.AndroidBridge.speakText === "function"){
        return new Promise(function(resolve,reject){
            var id=++androidTtsWaiterSerial;
            var timer=setTimeout(function(){
                for(var i=0;i<androidTtsWaiters.length;i++){
                    if(androidTtsWaiters[i].id===id){androidTtsWaiters.splice(i,1);break;}
                }
                reject(new Error("Android speaker did not finish the TTS request within 30 seconds."));
            },30000);
            androidTtsWaiters.push({id:id,resolve:resolve,reject:reject,timer:timer});
            try{
                window.AndroidBridge.speakText(clean,getLang());
            }catch(e){
                clearTimeout(timer);
                for(var j=0;j<androidTtsWaiters.length;j++){
                    if(androidTtsWaiters[j].id===id){androidTtsWaiters.splice(j,1);break;}
                }
                reject(e);
            }
        });
    }

    if(!ANDROID_APP && useLocalVoiceAI() && window.pywebview && window.pywebview.api && window.pywebview.api.native_local_tts){
        return window.pywebview.api.native_local_tts(clean,getLang()).then(function(d){if(d&&d.ok)return true;throw new Error((d&&d.error)||"Local TTS failed.");});
    }
    var nativeReady=!ANDROID_APP && window.pywebview && window.pywebview.api && window.pywebview.api.native_tts;
    if(nativeReady){
        return window.pywebview.api.native_tts(clean,getLang()).then(function(d){
            if(d&&d.ok)return true;
            throw new Error((d&&d.error)||"Native Windows TTS failed.");
        }).catch(function(nativeErr){
            if(!aiServerReady()) throw nativeErr;
            return fetch(url("/api/ai/tts"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:clean,language:getLang()}),cache:"no-store"})
              .then(function(r){if(!r.ok)return r.text().then(function(t){var d={};try{d=JSON.parse(t||"{}");}catch(e){}throw new Error(d.error||"Smart Plant TTS failed.");});return r.blob();})
              .then(function(blob){
                  if(window.__spAudioUrl){try{URL.revokeObjectURL(window.__spAudioUrl);}catch(e){}}
                  window.__spAudioUrl=URL.createObjectURL(blob);
                  if(!window.__spAudio) window.__spAudio=new Audio();
                  window.__spAudio.src=window.__spAudioUrl; window.__spAudio.preload="auto";
                  return window.__spAudio.play().then(function(){return true;});
              }).catch(function(browserErr){throw new Error((nativeErr&&nativeErr.message?nativeErr.message+" | ":"")+String(browserErr&&browserErr.message||browserErr));});
        });
    }
    if(aiServerReady()){
        return fetch(url("/api/ai/tts"),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:clean,language:getLang()}),cache:"no-store"})
          .then(function(r){if(!r.ok) return r.text().then(function(t){var d={};try{d=JSON.parse(t||"{}");}catch(e){}throw new Error(d.error||"Smart Plant TTS failed.");});return r.blob();})
          .then(function(blob){
              if(window.__spAudioUrl){try{URL.revokeObjectURL(window.__spAudioUrl);}catch(e){}}
              window.__spAudioUrl=URL.createObjectURL(blob);
              if(!window.__spAudio) window.__spAudio=new Audio();
              window.__spAudio.src=window.__spAudioUrl; window.__spAudio.preload="auto";
              return window.__spAudio.play().then(function(){return true;});
          });
    }
    return Promise.reject(new Error("Smart Plant TTS is unavailable on the Smart Plant PC hub."));
}

function speakText(text){
    var clean=String(text||"").trim();
    if(!clean) return Promise.resolve(false);
    speechQueueDepth++;
    var job=speechQueue.catch(function(){return false;}).then(function(){return speakTextNow(clean);});
    speechQueue=job.catch(function(){return false;});
    return job.finally(function(){
        speechQueueDepth=Math.max(0,speechQueueDepth-1);
        if(ANDROID_APP && androidVoiceSessionActive && speechQueueDepth===0 && window.AndroidBridge && typeof window.AndroidBridge.startVoice === "function"){
            setTimeout(function(){
                if(!voiceListening || speechQueueDepth!==0)return;
                setText("aiStatusBadge","LISTENING");
                setText("aiVoiceState",getLang()==="si"?"ආයෙත් සවන් දෙමින්…":"Listening again…");
                try{window.AndroidBridge.startVoice(getLang());}catch(e){toast(String(e&&e.message||e),true);}
            },350);
        }
    });
}

function nativeDesktopAudioTest(){
    if(window.pywebview&&window.pywebview.api&&window.pywebview.api.native_audio_test){
        return window.pywebview.api.native_audio_test();
    }
    return Promise.reject(new Error("Native Windows audio test is available only in the desktop app."));
}
function testAudio(){
    if(!ANDROID_APP && window.pywebview&&window.pywebview.api&&window.pywebview.api.native_audio_test){
        return nativeDesktopAudioTest().then(function(d){
            if(!d||!d.ok)throw new Error((d&&d.error)||"PC audio device check failed.");
            return speakText("Smart Plant audio test successful.").then(function(){return d;});
        });
    }
    if(ANDROID_APP && window.AndroidBridge && window.AndroidBridge.speakText){
        window.AndroidBridge.speakText("Smart Plant audio test successful.",getLang());
        return Promise.resolve({ok:true,speaker:true});
    }
    return speakText("Smart Plant audio test successful.").then(function(){return {ok:true};});
}
function updateVoiceTranscript(userText,reply,actionResult){
    var el=$("aiVoiceTranscript"); if(!el)return;
    var prefix=getLang()==="si"?"Voice request received. AI is speaking.":"Voice request received. AI is speaking.";
    if(actionResult&&actionResult.executed) prefix += " Control applied.";
    el.textContent=prefix; el.classList.add("active");
}

function parseAiEnvelope(raw){
    var text=String(raw||"").trim();if(!text)return {reply:"",action:null};
    var candidate=text.replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/i,"").trim();var obj=null;
    try{obj=JSON.parse(candidate);}catch(e){var a=candidate.indexOf("{"),z=candidate.lastIndexOf("}");if(a>=0&&z>a){try{obj=JSON.parse(candidate.slice(a,z+1));}catch(e2){obj=null;}}}
    if(!obj||typeof obj!=="object")return {reply:text.slice(0,12000),action:null};
    var reply=String(obj.reply||obj.message||text).trim().slice(0,12000),action=null;
    if(obj.action&&typeof obj.action==="object"){
        var n=String(obj.action.name||"").toLowerCase();
        if(["pump_on","pump_off","auto_on","auto_off"].indexOf(n)>=0){action={name:n};if(n==="pump_on")action.seconds=Math.round(Math.max(1,Math.min(600,Number(obj.action.seconds)||30)));}
    }
    return {reply:reply,action:action};
}
function aiControlEnabled(){return LS.get("ai_control_enabled","1")==="1";}
function aiActionText(a){if(!a)return "";if(a.name==="pump_on")return "pump ON"+(a.seconds?" for "+a.seconds+"s":"");if(a.name==="pump_off")return "pump OFF";if(a.name==="auto_on")return "automatic irrigation ON";if(a.name==="auto_off")return "automatic irrigation OFF";return a.name;}
function applyAiAction(action,fromVoice){
    if(!action)return Promise.resolve({ok:true,executed:false});
    if(!aiControlEnabled()){var reason="AI plant control is disabled.";aiSystemMessage("⚠ "+reason);return Promise.resolve({ok:false,executed:false,error:reason});}
    var extra=action.name==="pump_on"?{seconds:Math.round(Math.max(1,Math.min(600,Number(action.seconds)||30)))}:null;
    aiSystemMessage("AI control request: "+aiActionText(action));
    return ctrl(action.name,extra).then(function(d){
        if(d&&d.ok){var okText="✓ Control applied: "+aiActionText(action);aiSystemMessage(okText);if(fromVoice)speakText(okText);}else{var errText="⚠ Control not applied: "+((d&&d.error)||"controller rejected the command.");aiSystemMessage(errText);if(fromVoice)speakText(errText);}
        return d||{ok:false,error:"No control response."};
    });
}
function finishAiResponse(raw,fromVoice){
    var env=parseAiEnvelope(raw);if(!env.reply)throw new Error("AI returned no reply");
    aiAdd("ai",env.reply);aiHistory.push({role:"assistant",text:env.reply});if(aiHistory.length>20)aiHistory=aiHistory.slice(-20);saveAiHistory();lastAiReply=env.reply;
    if(fromVoice||LS.get("ai_auto_speak","1")!=="0")speakText(env.reply);return env;
}
function setAiModelDetected(active){
    if($("aiModelState"))$("aiModelState").textContent=active?"AUTO • ACTIVE":"AUTO • UNAVAILABLE";
    if($("sAiModelLabel"))$("sAiModelLabel").textContent="GPT-OSS 20B";
}
function groqKeyValue(){return "";}
function nativeGroqKeyReady(){return false;}
function detectGroqAPI(){
    if(!aiServerReady()){
        aiApiVerified=false;setAiModelDetected(false);
        if($("aiKeyState"))$("aiKeyState").textContent=tr("keyNotSet","PC hub not connected");
        return Promise.resolve(false);
    }
    if(aiApiChecking)return Promise.resolve(aiApiVerified);
    aiApiChecking=true;
    if($("aiKeyState"))$("aiKeyState").textContent="CHECKING GROQ API + CHAT…";
    if($("aiKeySettingsState"))$("aiKeySettingsState").textContent="CHECKING GROQ API + CHAT…";
    return api("/api/ai/verify",{cache:"no-store"}).then(function(d){
        aiApiVerified=!!(d&&d.verified===true&&d.chat_test===true);
        setAiModelDetected(aiApiVerified);
        var label=aiApiVerified?"GROQ API VERIFIED • CHAT TEST OK • GPT-OSS 20B":"GROQ API ERROR • "+String((d&&d.error)||"Verification failed").slice(0,220);
        if($("aiKeyState"))$("aiKeyState").textContent=label;
        if($("aiKeySettingsState"))$("aiKeySettingsState").textContent=label;
        return aiApiVerified;
    }).catch(function(e){
        aiApiVerified=false;setAiModelDetected(false);
        var label="GROQ API ERROR • "+String(e.message||e).slice(0,220);
        if($("aiKeyState"))$("aiKeyState").textContent=label;
        if($("aiKeySettingsState"))$("aiKeySettingsState").textContent=label;
        return false;
    }).finally(function(){aiApiChecking=false;});
}

function ensureAiVerified(){
    if(aiApiVerified)return Promise.resolve(true);
    return detectGroqAPI().then(function(ok){
        if(!ok){
            var msg=getLang()==="si"?"මුලින් Groq API key එක පරීක්ෂා කර සාර්ථක බව තහවුරු කරන්න.":"Check and verify the Groq API key first.";
            toast(msg,true);
            throw new Error(msg);
        }
        return true;
    });
}

function postAiChat(body, timeoutMs){
    timeoutMs=timeoutMs||18000;
    var controller=(typeof AbortController!=="undefined")?new AbortController():null;
    var timer=controller?setTimeout(function(){try{controller.abort();}catch(e){}},timeoutMs):null;
    var opts={method:"POST",headers:{"Content-Type":"application/json","X-SmartPlant-Client":"desktop-webview"},body:JSON.stringify(body||{}),cache:"no-store"};
    if(controller)opts.signal=controller.signal;
    return fetch(url("/api/ai/chat"),opts).then(function(r){
        return r.text().then(function(raw){
            var d={};
            try{d=raw?JSON.parse(raw):{};}catch(e){throw new Error("AI server returned invalid JSON (HTTP "+r.status+").");}
            if(!r.ok||!d.ok)throw new Error(String(d.error||d.message||("AI request failed (HTTP "+r.status+")")));
            return d;
        });
    }).catch(function(e){
        if(e&&e.name==="AbortError")throw new Error("AI request timed out after 18 seconds. Check the PC internet connection and Groq API status.");
        throw e;
    }).then(function(d){
        if(!d||!String(d.reply||"").trim()) throw new Error("Groq returned an empty AI answer.");
        return d;
    },function(e){throw e;}).then(function(d){
        if(timer)clearTimeout(timer);
        return d;
    },function(e){
        if(timer)clearTimeout(timer);
        throw e;
    });
}


var lastUpdateInfo=null;
function checkUpdate(silent){
    if(!aiServerReady()){ if(!silent) toast(getLang()==="si"?"PC hub එකට සම්බන්ධ කරන්න.":"Connect to the Smart Plant PC hub first.",true); return Promise.resolve(null); }
    setText("updateState",getLang()==="si"?"පරීක්ෂා කරනවා…":"Checking GitHub…");
    return fetch(url("/api/update/check"),{cache:"no-store"}).then(function(r){return r.json();}).then(function(d){
        lastUpdateInfo=d; var btn=$("updateInstallBtn");
        if(!d.ok){ setText("updateState",(d.error||"Update check failed")); if(btn)btn.style.display="none"; return d; }
        if(d.update_available){
            setText("updateState",(getLang()==="si"?"අලුත් version එකක් තියෙනවා: ":"New version available: ")+d.latest+" (current "+d.current+")");
            if(btn){ btn.style.display=""; btn.textContent=ANDROID_APP?(getLang()==="si"?"APK download කරන්න":"Download APK"):(getLang()==="si"?"දැන් update කරන්න":"Update now"); }
        }else{
            setText("updateState",(getLang()==="si"?"ඔයාගේ app එක අලුත්ම version එකයි: ":"You have the latest version: ")+d.current);
            if(btn)btn.style.display="none";
        }
        return d;
    }).catch(function(e){ setText("updateState","Update check failed: "+String(e.message||e)); return null; });
}
function installUpdate(){
    if(ANDROID_APP){
        var u=lastUpdateInfo&&lastUpdateInfo.apk_url;
        if(!u){ toast("This release has no APK attached.",true); return; }
        if(window.AndroidBridge&&window.AndroidBridge.openUrl){ window.AndroidBridge.openUrl(u); } else { window.open(u,"_blank"); }
        return;
    }
    if(!confirm(getLang()==="si"?"App එක update කරලා restart කරන්නද?":"Download the update and restart the app?"))return;
    setText("updateState",getLang()==="si"?"Download කරනවා… app එක restart වෙයි.":"Downloading… the app will restart.");
    fetch(url("/api/update/install"),{method:"POST"}).then(function(r){return r.json();}).then(function(d){
        if(!d.ok){ setText("updateState",d.error||"Update failed"); toast(d.error||"Update failed",true); }
    }).catch(function(){ /* app closes itself while installing */ });
}

function useLocalVoiceAI(){ return LS.get("local_voice_ai","0")==="1"; }
function localAiChat(message, history){
    return fetch(url("/api/local-voice/chat"),{method:"POST",headers:{"Content-Type":"application/json","X-SmartPlant-Client":ANDROID_APP?"android":"desktop-local"},body:JSON.stringify({message:String(message||"").trim(),language:getLang(),history:history||[]}),cache:"no-store"})
      .then(function(r){return r.text().then(function(t){var d={};try{d=JSON.parse(t||"{}");}catch(e){throw new Error("Local AI returned invalid JSON (HTTP "+r.status+").");}if(!r.ok||!d.ok)throw new Error(d.error||"Local AI request failed.");return d;});})
      .then(function(d){if(!d||!String(d.reply||"").trim())throw new Error("Local AI returned an empty reply.");return d;});
}
function checkLocalVoiceAI(){
    if(!aiServerReady()){toast(getLang()==="si"?"Smart Plant PC hub එකට සම්බන්ධ කරන්න.":"Connect to the Smart Plant PC hub first.",true);return Promise.reject(new Error("PC hub unavailable"));}
    setText("localVoiceState","CHECKING LOCAL WHISPER + OLLAMA + TTS…");
    return fetch(url("/api/local-voice/status"),{cache:"no-store"}).then(function(r){return r.json().then(function(d){
        var ok=!!(d&&d.ok); var msg=ok?"LOCAL VOICE AI READY • WHISPER + OLLAMA + "+String(d.tts_engine||"LOCAL TTS"):"LOCAL AI NOT READY • "+String((d&&d.error)||"Install local voice components.");
        setText("localVoiceState",msg); return d;
    });}).catch(function(e){setText("localVoiceState","LOCAL AI ERROR • "+String(e.message||e));throw e;});
}

function aiSend(message,fromVoice){
    var msg=String(message||"").trim(); if(!msg) return Promise.resolve();
    if(!aiServerReady()){var m=getLang()==="si"?"Smart Plant PC සේවාදායකයට දුරකථනය සම්බන්ධ කරන්න.":"Connect to the Smart Plant PC server for AI chat.";toast(m,true);return Promise.reject(new Error(m));}
    if(fromVoice){
        var thinking=getLang()==="si"?"හ්ම්, බලන්නම්…":"Hmm, let me check…";
        speakText(thinking).catch(function(){});
    }
    if(useLocalVoiceAI()){
        var localBox=$("sLocalVoiceAI"); if(localBox){ localBox.checked=true; }
        setText("aiStatusBadge",tr("aiWorking","THINKING"));
        if(!aiHistory.length || String(aiHistory[aiHistory.length-1].text||"")!==msg || aiHistory[aiHistory.length-1].role!=="user"){ aiAdd("user",msg); aiHistory.push({role:"user",text:msg}); if(aiHistory.length>20)aiHistory=aiHistory.slice(-20); saveAiHistory(); }
        return localAiChat(msg,aiHistory.slice(-12)).then(function(d){
            var reply=String(d.reply||"").trim(); aiAdd("ai",reply); aiHistory.push({role:"assistant",text:reply}); if(aiHistory.length>20)aiHistory=aiHistory.slice(-20); saveAiHistory(); lastAiReply=reply; updateVoiceTranscript(msg,reply,d.action_result); setText("aiStatusBadge",tr("aiReady","READY"));
            if(fromVoice || LS.get("ai_auto_speak","1")==="1"){ speakText(reply).catch(function(se){aiSystemMessage("⚠ Local AI text is ready, but speaker playback failed: "+String(se&&se.message||se));}); }
            return d;
        }).catch(function(e){setText("aiStatusBadge",tr("aiError","ERROR"));aiSystemMessage("⚠ "+String(e.message||e));throw e;});
    }
    // Put the user's message on screen immediately. API verification and
    // network calls must never make the chat look frozen or empty.
    if(!aiHistory.length || String(aiHistory[aiHistory.length-1].text||"")!==msg || aiHistory[aiHistory.length-1].role!=="user"){
        setText("aiStatusBadge",tr("aiWorking","THINKING"));
        aiAdd("user",msg);
        aiHistory.push({role:"user",text:msg}); if(aiHistory.length>20) aiHistory=aiHistory.slice(-20); saveAiHistory();
    }
    var sendAfterVerify=function(){
        setText("aiStatusBadge",tr("aiWorking","THINKING"));
        return postAiChat({message:msg,language:getLang(),history:aiHistory.slice(-12),platform:ANDROID_APP?"android":"pc"},18000);
    };
    // Do not block chat on a separate preflight request. The chat endpoint
    // performs the real authenticated Groq request and returns the exact error
    // when the key/model/network is wrong. A background preflight may update
    // the settings status, but it can never leave the Send button spinning.
    if(!aiApiVerified){detectGroqAPI().catch(function(){});}
    return sendAfterVerify().then(function(d){
        aiApiVerified=true;
        setAiModelDetected(true);
        if($('aiKeyState'))$('aiKeyState').textContent='GROQ API VERIFIED • CHAT OK • GPT-OSS 20B';
        if(!d||!d.ok) throw new Error((d&&d.error)||"AI request failed");
        var reply=String(d.reply||"").trim();
        if(!reply) throw new Error("AI server returned an empty reply.");
        // Render text before speaker playback. TTS is best-effort and cannot
        // make Text Chat appear empty when the speaker path has a problem.
        aiAdd("ai",reply);
        aiHistory.push({role:"assistant",text:reply}); if(aiHistory.length>20) aiHistory=aiHistory.slice(-20); saveAiHistory(); lastAiReply=reply;
        updateVoiceTranscript(msg,reply,d.action_result);
        setText("aiStatusBadge",tr("aiReady","READY"));
        var shouldSpeak=!!fromVoice || LS.get("ai_auto_speak","1")==="1";
        if(shouldSpeak){
            var speechPromise=speakText(reply);
            if(speechPromise&&typeof speechPromise.catch==="function") speechPromise.catch(function(se){
                aiSystemMessage("⚠ Text reply is ready, but speaker playback failed: "+String(se&&se.message||se));
            });
        }
        return d;
    }).catch(function(e){var msgErr=String(e&&e.message||e);setText("aiStatusBadge",tr("aiError","ERROR"));aiSystemMessage("⚠ "+msgErr);toast(msgErr,true);throw e;});
}

function aiSetMode(mode,save){
    mode=(mode==="text")?"text":"voice";
    if(save)LS.set("ai_mode",mode);
    var voice=$("aiVoiceMode"), text=$("aiTextMode"), vb=$("aiVoiceTab"), tb=$("aiTextTab");
    if(voice){voice.classList.toggle("hidden",mode!=="voice");voice.style.display=mode==="voice"?"block":"none";}
    if(text){text.classList.toggle("hidden",mode!=="text");text.style.display=mode==="text"?"block":"none";}
    if(vb){vb.classList.toggle("active",mode==="voice");vb.setAttribute("aria-selected",mode==="voice"?"true":"false");}
    if(tb){tb.classList.toggle("active",mode==="text");tb.setAttribute("aria-selected",mode==="text"?"true":"false");}
    if(mode==="text"){var inp=$("aiInput");if(inp)inp.focus();}
    if(mode==="voice"){var orb=$("aiVoiceBtn");if(orb){orb.style.display="flex";setTimeout(function(){try{orb.scrollIntoView({block:"nearest",behavior:"smooth"});}catch(e){}},80);}}
}
var aiApiVerified=false;
var aiApiChecking=false;
var aiTextBusy=false;
function aiTextSend(){
    var inp=$("aiInput");if(!inp)return Promise.resolve(false);
    var msg=String(inp.value||"").trim();if(!msg||aiTextBusy)return Promise.resolve(false);
    aiTextBusy=true;
    var sendBtn=document.querySelector("#aiTextMode .btn.primary");
    var original=msg;
    if(sendBtn){sendBtn.disabled=true;sendBtn.setAttribute("aria-busy","true");sendBtn.textContent=getLang()==="si"?"යවමින්…":"Sending…";}
    var emergencyTimer=setTimeout(function(){
        if(!aiTextBusy)return;
        aiTextBusy=false;
        if(sendBtn){sendBtn.disabled=false;sendBtn.removeAttribute("aria-busy");sendBtn.textContent=tr("aiSend","Send");}
        setText("aiStatusBadge",tr("aiError","ERROR"));
        aiSystemMessage(getLang()==="si"?"AI ඉල්ලීම කාලය ඉක්මවා ගියා. නැවත උත්සාහ කරන්න.":"AI request timed out. Please try again.");
    },20000);
    return aiSend(msg,false).then(function(result){
        if(inp && String(inp.value||"").trim()===original) inp.value="";
        clearTimeout(emergencyTimer);
        aiTextBusy=false;
        if(sendBtn){sendBtn.disabled=false;sendBtn.removeAttribute("aria-busy");sendBtn.textContent=tr("aiSend","Send");}
        return result;
    },function(err){
        clearTimeout(emergencyTimer);
        if(inp && !String(inp.value||"").trim()) inp.value=original;
        aiTextBusy=false;
        if(sendBtn){sendBtn.disabled=false;sendBtn.removeAttribute("aria-busy");sendBtn.textContent=tr("aiSend","Send");}
        return false;
    });
}



function installAiTextEnterHandler(){
    var inp=$("aiInput");
    if(!inp||inp.__spEnterHook)return;
    inp.__spEnterHook=true;
    inp.addEventListener("keydown",function(ev){
        if(ev.key==="Enter" && !ev.shiftKey){
            ev.preventDefault();
            aiTextSend();
        }
    });
}

function aiTextClear(){aiClear();}

function aiClear(){var box=$("aiChatWindow");if(box)box.innerHTML="";aiHistory=[];lastAiReply="";saveAiHistory();aiSystemMessage(tr("aiReady","AI ready"));}
function updateVoiceUi(on){
    voiceListening=!!on;var b=$("aiVoiceBtn"),st=$("aiVoiceState"),ic=$("aiVoiceIcon");
    if(b)b.classList.toggle("listening",!!on);
    if(ic)ic.textContent=on?"STOP":"MIC";
    if(st)st.textContent=on?"Listening…":tr("voiceReady","Voice ready");
    setText("aiStatusBadge",on?tr("voiceListening","LISTENING"):tr("aiReady","READY"));
}
var voiceRecorder=null, voiceStream=null, voiceChunks=[];
var pcVoiceSessionActive=false;
var pcVoiceTurnBusy=false;
var pcVoiceRetryTimer=null;
var VOICE_RECORD_MS=12000;
function voiceMimeType(){
    var list=["audio/webm;codecs=opus","audio/webm","audio/ogg;codecs=opus","audio/ogg"];
    for(var i=0;i<list.length;i++){
        try{if(window.MediaRecorder&&MediaRecorder.isTypeSupported&&MediaRecorder.isTypeSupported(list[i])) return list[i];}catch(e){}
    }
    return "";
}
function stopVoiceRecorder(){
    try{if(voiceRecorder&&voiceRecorder.state!=="inactive") voiceRecorder.stop();}catch(e){}
}
function finishRecordedVoice(){
    var chunks=voiceChunks.slice(); voiceChunks=[];
    var stream=voiceStream; voiceStream=null;
    if(stream){try{stream.getTracks().forEach(function(t){t.stop();});}catch(e){}}
    voiceRecorder=null; updateVoiceUi(false);
    if(!chunks.length){toast("No voice captured. Please speak after the microphone starts.",true);return;}
    var type=(chunks[0]&&chunks[0].type)||"audio/webm";
    var blob=new Blob(chunks,{type:type});
    var fd=new FormData();
    fd.append("file",blob,"smartplant-voice.webm");
    fd.append("language",getLang()==="si"?"si":(getLang()==="ja"?"ja":"en"));
    setText("aiStatusBadge","TRANSCRIBING");
    fetch(url("/api/ai/transcribe"),{method:"POST",body:fd,cache:"no-store"})
      .then(function(r){return r.text().then(function(t){var d={};try{d=JSON.parse(t||"{}");}catch(e){}if(!r.ok||!d.ok)throw new Error(d.error||"Voice transcription failed.");return d;});})
      .then(function(d){
          var textValue=String(d.text||"").trim();
          if(!textValue) throw new Error("No speech was detected.");
          return aiSend(textValue,true);
      })
      .catch(function(e){setText("aiStatusBadge",tr("aiError","ERROR"));toast(String(e.message||e),true);});
}
function browserVoiceToggle(){
    if(!aiServerReady()){
        toast(getLang()==="si"?"Smart Plant PC server එකට connect කරන්න.":"Connect to the Smart Plant PC server first.",true);
        return;
    }
    if(voiceRecorder){stopVoiceRecorder();return;}
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||!window.MediaRecorder){
        toast("This device/browser does not provide microphone recording.",true);return;
    }
    var mt=voiceMimeType();
    var options=mt?{mimeType:mt}:undefined;
    navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}})
      .then(function(stream){
          voiceStream=stream; voiceChunks=[];
          try{voiceRecorder=new MediaRecorder(stream,options);}catch(e){try{voiceRecorder=new MediaRecorder(stream);}catch(e2){voiceRecorder=null;stream.getTracks().forEach(function(t){t.stop();});throw e2;}}
          voiceRecorder.ondataavailable=function(ev){if(ev.data&&ev.data.size>0) voiceChunks.push(ev.data);};
          voiceRecorder.onstop=finishRecordedVoice;
          voiceRecorder.onerror=function(){finishRecordedVoice();};
          updateVoiceUi(true);
          try{voiceRecorder.start(250);}catch(e){finishRecordedVoice();throw e;}
          setText("aiVoiceState",getLang()==="si"?"සවන් දෙමින්…":"Listening…");
          window.__spVoiceTimeout=setTimeout(function(){if(voiceRecorder) stopVoiceRecorder();},VOICE_RECORD_MS);
      })
      .catch(function(e){updateVoiceUi(false);toast("Microphone access failed: "+(e&&e.message?e.message:"permission/device error"),true);});
}
function hasNativeDesktopVoice(){
    return !ANDROID_APP && !!(window.pywebview && window.pywebview.api && window.pywebview.api.native_voice_chat);
}
function hasAndroidVoiceBridge(){
    return ANDROID_APP && window.AndroidBridge && typeof window.AndroidBridge.startVoice === "function";
}
function stopPcVoiceSession(){
    pcVoiceSessionActive=false;
    pcVoiceTurnBusy=false;
    if(pcVoiceRetryTimer){clearTimeout(pcVoiceRetryTimer);pcVoiceRetryTimer=null;}
    updateVoiceUi(false);
    setText("aiStatusBadge",tr("aiReady","READY"));
    setText("aiVoiceState",tr("voiceReady","Voice ready"));
}
function runPcVoiceTurn(){
    if(!pcVoiceSessionActive||pcVoiceTurnBusy)return;
    pcVoiceTurnBusy=true;
    updateVoiceUi(true);
    setText("aiVoiceState",getLang()==="si"?"සවන් දෙමින්…":"Listening…");
    setText("aiStatusBadge","LISTENING");
    var historyCopy=aiHistory.slice(-12);
    var voiceCall = useLocalVoiceAI() && window.pywebview.api.native_local_voice_chat ? window.pywebview.api.native_local_voice_chat(getLang(),8,historyCopy) : window.pywebview.api.native_voice_chat(getLang(),8,historyCopy);
    voiceCall.then(function(d){
        pcVoiceTurnBusy=false;
        if(!d||!d.ok) throw new Error((d&&d.error)||"Native voice chat failed.");
        var spoken=String(d.transcript||"").trim();
        var reply=String(d.reply||"").trim();
        if(spoken){aiHistory.push({role:"user",text:spoken});if(aiHistory.length>20)aiHistory=aiHistory.slice(-20);}
        if(reply){aiHistory.push({role:"assistant",text:reply});if(aiHistory.length>20)aiHistory=aiHistory.slice(-20);lastAiReply=reply;}
        saveAiHistory();
        updateVoiceTranscript(spoken,reply,d.action_result);
        if(!pcVoiceSessionActive)return;
        if(reply){
            setText("aiStatusBadge","SPEAKING");
            setText("aiVoiceState",getLang()==="si"?"AI පිළිතුර කියනවා…":"AI is speaking…");
            speakText(reply).catch(function(se){
                aiSystemMessage("⚠ AI text reply is ready, but speaker playback failed: "+String(se&&se.message||se));
            }).finally(function(){
                if(!pcVoiceSessionActive)return;
                setText("aiStatusBadge","LISTENING");
                setText("aiVoiceState",getLang()==="si"?"ආයෙත් සවන් දෙමින්…":"Listening again…");
                pcVoiceRetryTimer=setTimeout(function(){pcVoiceRetryTimer=null;runPcVoiceTurn();},350);
            });
        }else{
            setText("aiStatusBadge","READY");
            pcVoiceRetryTimer=setTimeout(function(){pcVoiceRetryTimer=null;runPcVoiceTurn();},350);
        }
    }).catch(function(e){
        pcVoiceTurnBusy=false;
        var msg=String(e&&e.message||e);
        if(pcVoiceSessionActive && /No speech was detected|speech was not detected|too little audio/i.test(msg)) {
            setText("aiStatusBadge","LISTENING");
            setText("aiVoiceState",getLang()==="si"?"කිසිම හඬක් ලැබුණේ නැහැ — ආයෙත් අහනවා…":"No speech detected — listening again…");
            pcVoiceRetryTimer=setTimeout(function(){pcVoiceRetryTimer=null;runPcVoiceTurn();},250);
            return;
        }
        stopPcVoiceSession();
        if(/microphone|input device|permission|access|portaudio/i.test(msg) && window.pywebview.api.open_microphone_settings){
            toast(msg+" — Windows microphone settings will open.",true);
            try{window.pywebview.api.open_microphone_settings();}catch(_e){}
        }else toast(msg,true);
    });
}
function voiceToggle(){
    if(hasAndroidVoiceBridge()){
        if(voiceListening){
            androidVoiceSessionActive=false;
            try{if(typeof window.AndroidBridge.stopVoice === "function") window.AndroidBridge.stopVoice();}catch(e){}
            updateVoiceUi(false);
            return;
        }
        if(!aiServerReady()){
            toast(getLang()==="si"?"මුලින් Smart Plant PC hub එකට සම්බන්ධ වෙන්න.":"Connect to the Smart Plant PC hub first.",true);
            return;
        }
        androidVoiceSessionActive=true;
        updateVoiceUi(true);
        setText("aiVoiceState",getLang()==="si"?"සවන් දෙමින්…":"Listening…");
        setText("aiStatusBadge","LISTENING");
        try{window.AndroidBridge.startVoice(getLang());}
        catch(e){updateVoiceUi(false);toast("Android microphone could not start: "+String(e&&e.message||e),true);}
        return;
    }
    if(hasNativeDesktopVoice()){
        if(pcVoiceSessionActive){
            stopPcVoiceSession();
            return;
        }
        if(!aiServerReady()){
            toast(getLang()==="si"?"Smart Plant PC server එක සූදානම් නැහැ.":"Smart Plant PC server is not ready.",true);
            return;
        }
        pcVoiceSessionActive=true;
        pcVoiceTurnBusy=false;
        runPcVoiceTurn();
        return;
    }
    browserVoiceToggle();
}

function aiSpeakLast(){
    var candidate=String(lastAiReply||"").trim();
    if(!candidate){
        for(var i=aiHistory.length-1;i>=0;i--){if(aiHistory[i]&&aiHistory[i].role==="assistant"&&String(aiHistory[i].text||"").trim()){candidate=String(aiHistory[i].text).trim();break;}}
    }
    if(candidate){lastAiReply=candidate;speakText(candidate).catch(function(e){toast(String(e.message||e),true);});}
    else{aiSystemMessage(getLang()==="si"?"AI පිළිතුරක් තවම ලැබී නැහැ.":"There is no AI answer to speak yet.");}
}
function nativeBridgeReady(){return !ANDROID_APP&&window.pywebview&&window.pywebview.api;}
function audioDeviceOptionText(item){return String(item.name||('Audio device '+(item.index!=null?item.index:item.id)));}
function browserAudioDevices(){
    if(!navigator.mediaDevices||!navigator.mediaDevices.enumerateDevices)return Promise.reject(new Error('Browser audio-device detection is unavailable.'));
    var ensure=(!navigator.mediaDevices.getUserMedia)?Promise.resolve():navigator.mediaDevices.getUserMedia({audio:true}).then(function(s){try{s.getTracks().forEach(function(t){t.stop();});}catch(e){}});
    return ensure.then(function(){return navigator.mediaDevices.enumerateDevices();}).then(function(list){
        var inputs=(list||[]).filter(function(d){return d.kind==='audioinput';});
        var outputs=(list||[]).filter(function(d){return d.kind==='audiooutput';});
        return {ok:true,inputs:inputs,outputs:outputs};
    });
}
function audioDeviceText(list,kind){
    var named=(list||[]).map(function(d){return String(d.label||'');}).filter(Boolean);
    return named.length?named.join(', '):(list&&list.length?(kind==='input'?'Microphone available':'Speaker/output available'):'None detected');
}
function renderPCAudioDevices(d){
    if(!d||!d.ok){if($('audioDeviceState'))$('audioDeviceState').textContent=(d&&d.error)||'AUDIO DEVICE SCAN FAILED';return;}
    var ins=$('sAudioInput'), outs=$('sAudioOutput');
    function fill(sel,list,selected){
        if(!sel)return; sel.innerHTML='';
        var def=document.createElement('option'); def.value='-1'; def.textContent='System default'; sel.appendChild(def);
        (list||[]).forEach(function(item){var o=document.createElement('option');o.value=String(item.index);o.textContent=audioDeviceOptionText(item);sel.appendChild(o);});
        sel.value=String(selected==null?-1:selected);
        if(sel.value!==String(selected==null?-1:selected))sel.value='-1';
    }
    fill(ins,d.inputs,d.selected_input); fill(outs,d.outputs,d.selected_output);
    if($('audioDeviceState'))$('audioDeviceState').textContent=(d.inputs||[]).length+' microphone(s) • '+(d.outputs||[]).length+' speaker(s) detected';
}
function detectPCAudioDevices(){
    if(nativeBridgeReady() && typeof window.pywebview.api.audio_devices==='function'){
        if($('audioDeviceState'))$('audioDeviceState').textContent='SCANNING AUDIO DEVICES…';
        return window.pywebview.api.audio_devices().then(function(d){renderPCAudioDevices(d);return d;}).catch(function(e){
            var m=String(e&&e.message||e);
            if($('audioDeviceState'))$('audioDeviceState').textContent='NATIVE SCAN ERROR • '+m.slice(0,160);
            return browserAudioDevices().then(function(d){
                if($('sAudioInput')) $('sAudioInput').innerHTML='<option value="-1">'+audioDeviceText(d.inputs,'input')+'</option>';
                if($('sAudioOutput')) $('sAudioOutput').innerHTML='<option value="-1">'+audioDeviceText(d.outputs,'output')+'</option>';
                if($('audioDeviceState'))$('audioDeviceState').textContent=(d.inputs||[]).length+' microphone(s) • '+(d.outputs||[]).length+' speaker(s) detected (browser)';
                return d;
            });
        });
    }
    if($('audioDeviceState'))$('audioDeviceState').textContent='DETECTING BROWSER AUDIO DEVICES…';
    return browserAudioDevices().then(function(d){
        if($('sAudioInput')) $('sAudioInput').innerHTML='<option value="-1">'+audioDeviceText(d.inputs,'input')+'</option>';
        if($('sAudioOutput')) $('sAudioOutput').innerHTML='<option value="-1">'+audioDeviceText(d.outputs,'output')+'</option>';
        if($('audioDeviceState'))$('audioDeviceState').textContent=(d.inputs||[]).length+' microphone(s) • '+(d.outputs||[]).length+' speaker(s) detected';
        return d;
    });
}
function savePCAudioDeviceSelection(){
    if(!nativeBridgeReady()||typeof window.pywebview.api.set_audio_devices!=='function')return Promise.resolve(false);
    var input=$('sAudioInput')?parseInt($('sAudioInput').value,10):-1;
    var output=$('sAudioOutput')?parseInt($('sAudioOutput').value,10):-1;
    if(!Number.isFinite(input))input=-1; if(!Number.isFinite(output))output=-1;
    return window.pywebview.api.set_audio_devices(input,output).then(function(d){renderPCAudioDevices(d);toast('Microphone and speaker selection saved.');return d;});
}
function openPCMicrophoneSettings(){if(nativeBridgeReady()&&typeof window.pywebview.api.open_microphone_settings==='function'){window.pywebview.api.open_microphone_settings();return;}toast('Open Windows microphone privacy settings on the PC.',true);}
function openPCSoundSettings(){if(nativeBridgeReady()&&typeof window.pywebview.api.open_sound_settings==='function'){window.pywebview.api.open_sound_settings();return;}toast('Open Windows sound settings on the PC.',true);}

function toggleGroqKeyVisibility(){
    var field=$("sGroqKey");
    if(!field) return;
    field.type=field.type==="password"?"text":"password";
}
function saveGroqKeySettings(){
    var field=$("sGroqKey"); var key=field?String(field.value||"").trim():"";
    if(key.length<12){toast(getLang()==="si"?"කරුණාකර valid Groq API key එකක් දාන්න.":"Please enter a valid Groq API key.",true);return Promise.resolve(false);}
    if(!aiServerReady()){var m=getLang()==="si"?"මුලින් Smart Plant PC hub එකට connect වෙන්න.":"Connect to the Smart Plant PC hub first.";toast(m,true);return Promise.resolve(false);}
    if($("aiKeySettingsState"))$("aiKeySettingsState").textContent="SAVING…";
    var body={groq_api_key:key,ai_enabled:true,ai_control_enabled:true,weather_location:LS.get("weather_location","")};
    return post("/api/ai/settings",body).then(function(d){
        if(!d||!d.ok)throw new Error((d&&d.error)||"Could not save Groq key.");
        if(field)field.value="";
        aiApiVerified=false;
        if($("sAiEnabled"))$("sAiEnabled").checked=true;
        if(cfg){cfg.ai_enabled=true;cfg.groq_key_set=!!d.groq_key_set;cfg.groq_key_source=d.groq_key_source||"Smart Plant Settings";}
        if($("aiKeySettingsState"))$("aiKeySettingsState").textContent=(d.groq_key_source||"SMART PLANT SETTINGS")+" • READY";
        return detectGroqAPI().then(function(ok){
            if(ok) toast(getLang()==="si"?"Groq key save + AI chat verification සාර්ථකයි.":"Groq key saved and AI chat verification succeeded.");
            return ok;
        });
    }).catch(function(e){if($("aiKeySettingsState"))$("aiKeySettingsState").textContent="ERROR • "+String(e.message||e).slice(0,120);toast(String(e.message||e),true);return false;});
}
function clearGroqKeySettings(){
    if(!aiServerReady()){toast(getLang()==="si"?"මුලින් Smart Plant PC hub එකට connect වෙන්න.":"Connect to the Smart Plant PC hub first.",true);return Promise.resolve(false);}
    return post("/api/ai/settings",{groq_api_key:"",ai_enabled:!!(cfg&&cfg.ai_enabled),ai_control_enabled:true}).then(function(d){
        if(!d||!d.ok)throw new Error((d&&d.error)||"Could not clear Groq key.");
        if($("sGroqKey"))$("sGroqKey").value="";
        aiApiVerified=false;
        if($("aiKeySettingsState"))$("aiKeySettingsState").textContent="NOT CONFIGURED";
        if($("aiKeyState"))$("aiKeyState").textContent=tr("keyNotSet","PC AI key not configured");
        toast(getLang()==="si"?"Saved Groq key ඉවත් කළා.":"Saved Groq key cleared.");
        return true;
    }).catch(function(e){toast(String(e.message||e),true);return false;});
}
function saveAISettings(){return saveGroqKeySettings();}
function clearAIKey(){return clearGroqKeySettings();}
function aiHealthCheck(){
    return api("/api/ai/diagnostics",{cache:"no-store"}).then(function(d){
        if(d&&d.groq_api_verified){aiApiVerified=true;setAiModelDetected(true);}
        return d;
    });
}

function checkGroqKeyOnly(){return detectGroqAPI();}
function testAI(){return aiHealthCheck().then(function(){return aiSend("Give me a one-sentence Smart Plant status check. Use only the live sensor data.",true);});}
window.__androidVoiceResult=function(text){
    var spoken=String(text||"").trim();
    if(!spoken)return;
    updateVoiceTranscript(spoken,"",null);
    setText("aiStatusBadge","THINKING");
    setText("aiVoiceState",getLang()==="si"?"AI පිළිතුර සකස් කරමින්…":"Preparing AI reply…");
    aiSend(spoken,true).catch(function(){
        if(androidVoiceSessionActive && window.AndroidBridge && typeof window.AndroidBridge.startVoice === "function") setTimeout(function(){try{window.AndroidBridge.startVoice(getLang());}catch(e){}},700);
    });
};
window.__androidVoiceState=function(active,message){
    // Android sends active=false while a recognized turn is being processed or
    // spoken. Keep the overall Voice Chat session visually active until the
    // user explicitly presses STOP.
    if(androidVoiceSessionActive && !active && message && /processing|reply playing/i.test(message)){
        setText("aiVoiceState",message);
        setText("aiStatusBadge",/reply playing/i.test(message)?"SPEAKING":"THINKING");
        return;
    }
    updateVoiceUi(active);
    if(message&&/error|denied|unavailable|permission/i.test(message)){
        aiSystemMessage(message);
        if(/permission|unavailable/i.test(message)) androidVoiceSessionActive=false;
    }
};

function setLanguage(v, save) {
    if (!T[v]) v = "en";
    if (save) LS.set("lang", v);
    if ($("sLanguage")) $("sLanguage").value = v;
    document.documentElement.lang = v;
    applyI18n();
    refresh();
}

/* --------------------------- 15. api base ----------------------------- */
function normalize(raw) {
    var u = (raw || "").trim();
    if (!u) return "";
    if (!/^https?:\/\//i.test(u)) u = "http://" + u;
    return u.replace(/\/+$/, "");
}

function applyApiBase() {
    var base = normalize(val("sApiBase"));
    API = base;
    LS.set("api", base);
    toast(base ? "Link set to " + base : "Link set to this device.");
    probe().then(function () { loadSettings(); refresh(); paintDevice(); });
}

function gatePreset(v) { set("gateUrl", v); }

function gateLocal() {
    API = "";
    LS.set("api", "");
    probe().then(function (ok) {
        if (!ok) { $("gateMsg").textContent = "no server on this device"; return; }
        $("gate").classList.add("hidden");
        boot(function () { scanBoard(true); });
    });
}

function gateConnect() {
    var base = normalize(val("gateUrl"));
    if (!base) { $("gateMsg").textContent = "enter an address first"; return; }
    $("gateMsg").textContent = "connecting to " + base + " ...";
    API = base;
    probe().then(function (ok) {
        if (!ok) {
            $("gateMsg").textContent = "no answer from " + base + " - check Wi-Fi and the port";
            API = "";
            return;
        }
        LS.set("api", base);
        $("gate").classList.add("hidden");
        boot(function () { scanBoard(true); });
    });
}

function probe() {
    return api("/api/state").then(function () {
        caps.server = true;
        return api("/api/settings").then(function () {
            caps.settings = caps.history = caps.plants = true;
            return true;
        }).catch(function (e) {
            if (e && e.code === 404) {
                /* Only /api/state + /api/control -> a board answering directly. */
                caps.settings = caps.history = caps.plants = caps.server = false;
                lockServerFields();
            }
            return true;
        });
    }).catch(function () { return false; });
}

/* ----------------------------- 16. boot ------------------------------- */
function boot(afterBoot) {
    if (window.__SP_BOOT_ACTIVE) {
        // After the initial intro has been removed, gate/settings flows may
        // ask to run a new startup callback. Do not start a second animation;
        // just continue with the requested callback.
        if (!$("boot") && typeof afterBoot === "function") {
            try { afterBoot(); } catch (e) { console.error("[SmartPlant] afterBoot error", e); }
        }
        return;
    }

    window.__SP_BOOT_ACTIVE = true;
    started = true;

    var isAndroidApp = ANDROID_APP;

    function byId(id) { return $(id); }
    function setText(id, text) {
        var el = byId(id);
        if (el) el.textContent = text;
    }
    function show(el) {
        if (!el) return;
        el.style.display = (el.id === "bootCore") ? "block" : "grid";
        el.classList.remove("leave");
        el.classList.add("show");
    }
    function hide(el) {
        if (!el) return;
        el.classList.remove("show");
        el.classList.add("leave");
        setTimeout(function () {
            if (el) el.style.display = "none";
        }, 600);
    }
    function afterBootNow() {
        var b = byId("boot");
        if (b) b.classList.add("done");
        setTimeout(function () {
            var x = byId("boot");
            if (x) x.remove();
            if (typeof afterBoot === "function") {
                try { afterBoot(); }
                catch (e) { console.error("[SmartPlant] afterBoot error", e); start(); }
            } else {
                start();
            }
        }, 450);
    }

    try {
        setText("bootCredit", isAndroidApp ? "Developed by Geenuka" : "Developed by Tharusha");
        if (byId("railCredit")) byId("railCredit").textContent = isAndroidApp ? "Developed by Geenuka" : "Developed by Tharusha";
        if (byId("aboutLine")) byId("aboutLine").textContent = isAndroidApp
            ? "Smart Plant Irrigation & Monitoring System · Developed by Geenuka"
            : "Developed by Tharusha";
        if (byId("teacherThanks")) byId("teacherThanks").classList.toggle("hidden", false);
        if (byId("slideWelcomeCredit")) byId("slideWelcomeCredit").textContent = isAndroidApp
            ? "Developed by Geenuka" : "Developed by Tharusha";
        if (isAndroidApp) {
            if (byId("scanKicker")) byId("scanKicker").textContent = "SMART PLANT // ESP32 DISCOVERY";
            if (byId("scanSub")) byId("scanSub").textContent = "Searching this Wi-Fi network for the Smart Plant ESP32 controller";
            if (byId("scanFound")) byId("scanFound").textContent = "Starting real Smart Plant ESP32 discovery...";
            if (byId("scanTarget")) byId("scanTarget").textContent = "Looking for Smart Plant ESP32...";
        }

        // Mr. Sudesh photo is shown on BOTH PC and Android.
        if (byId("introTeacherPhoto")) byId("introTeacherPhoto").classList.remove("hidden");
        if (byId("introTeacherEmoji")) byId("introTeacherEmoji").classList.add("hidden");

        (function setupDesktopControls() {
            var btn = byId("desktopFullscreenBtn");
            if (!btn) return;
            function reveal() {
                if (!(window.pywebview && window.pywebview.api && window.pywebview.api.toggle_fullscreen)) return;
                btn.classList.remove("hidden");
                btn.onclick = function () { window.pywebview.api.toggle_fullscreen(); };
            }
            window.addEventListener("pywebviewready", reveal);
            reveal();
        })();

        var teacher = byId("slideTeacher");
        var welcome = byId("slideWelcome");
        var core = byId("bootCore");
        var boot = byId("boot");

        if (!welcome || !teacher || !core || !boot) {
            throw new Error("Startup elements are missing");
        }

        // Force a known visual state before starting the timers.
        welcome.style.display = "grid";
        welcome.classList.remove("leave");
        welcome.classList.add("show");
        teacher.style.display = "none";
        teacher.classList.remove("show", "leave");
        core.style.display = "none";
        core.classList.remove("show", "leave");
        setText("bootPct", "0%");
        var bootBar = byId("bootBar");
        if (bootBar) bootBar.style.width = "0%";
        setText("bootStatus", "booting core services");

        var steps = [
            ["Control core", "control core online"],
            ["Interface modules", "interface modules ready"],
            ["Sensor bus", "sensor bus armed"],
            ["History pipeline", "history pipeline ready"],
            ["Controller link", "controller link standby"]
        ];
        var marks = qsa("#bootLog b");

        function runProgress() {
            var pct = 0;
            var stepIndex = 0;

            function tick() {
                pct = Math.min(100, pct + 20);
                stepIndex = Math.min(4, Math.max(0, Math.floor((pct - 1) / 20)));
                setText("bootPct", pct + "%");
                var bar = byId("bootBar");
                if (bar) bar.style.width = pct + "%";
                setText("bootStatus", pct >= 100 ? "system ready // opening ESP32 scan" : steps[stepIndex][1]);

                for (var k = 0; k < marks.length; k++) {
                    var done = k < Math.floor(pct / 20);
                    marks[k].textContent = done ? "ok" : (k === Math.floor(pct / 20) ? "standby" : "wait");
                    marks[k].className = done ? "ok" : (k === Math.floor(pct / 20) ? "wait" : "");
                }

                if (pct >= 100) {
                    setTimeout(afterBootNow, 250);
                } else {
                    setTimeout(tick, 700);
                }
            }
            tick();
        }

        // Welcome -> Teacher -> Core -> progress. No network work is allowed
        // to block this visual state machine.
        setTimeout(function () {
            hide(welcome);
            show(teacher);

            setTimeout(function () {
                hide(teacher);
                show(core);

                // Run progress on the next task so the browser paints the core
                // screen before the first progress update.
                setTimeout(runProgress, 80);

                // Safety watchdog: never leave the user frozen on 0%.
                // If a browser/webview timer is interrupted, force recovery.
                setTimeout(function () {
                    var p = byId("bootPct");
                    if (p && p.textContent === "0%") {
                        console.warn("[SmartPlant] boot watchdog recovery");
                        try {
                            var bb = byId("bootBar");
                            if (bb) bb.style.width = "100%";
                            p.textContent = "100%";
                            setText("bootStatus", "startup recovery // opening ESP32 scan");
                            afterBootNow();
                        } catch (e) {
                            console.error("[SmartPlant] watchdog failed", e);
                        }
                    }
                }, 3500);
            }, 5000);
        }, 1800);

    } catch (e) {
        console.error("[SmartPlant] startup error:", e);
        // Hard fallback: never leave the user at a static 0% screen.
        var teacher2 = byId("slideTeacher");
        var welcome2 = byId("slideWelcome");
        var core2 = byId("bootCore");
        if (welcome2) { welcome2.style.display = "none"; welcome2.classList.remove("show"); }
        if (teacher2) { teacher2.style.display = "none"; teacher2.classList.remove("show"); }
        if (core2) { core2.style.display = "block"; core2.classList.add("show"); }
        setText("bootStatus", "startup recovery // opening ESP32 scan");
        setText("bootPct", "100%");
        var bar2 = byId("bootBar");
        if (bar2) bar2.style.width = "100%";
        setTimeout(afterBootNow, 300);
    }
}

function restartTimer() {
    var secs = Math.max(1, Math.min(60, Number(LS.get("poll", 1)) || 1));
    if (timer) clearInterval(timer);
    timer = setInterval(refresh, secs * 1000);
}

function start() {
    loadSettings().then(refresh);
    loadPlants();
    loadServer();
    restartTimer();
    if (histTimer) clearInterval(histTimer);
    histTimer = setInterval(function () {
        if (page === "history") loadHistory();
        if (page === "analytics") loadAnalytics();
    }, 15000);
}

/* Keep the bundled surface app-like: vertical scrolling only, no pinch zoom. */
function installNativeSurfaceGuards(){
    ["gesturestart","gesturechange","gestureend"].forEach(function(name){
        document.addEventListener(name,function(e){e.preventDefault();},{passive:false});
    });
    document.addEventListener("wheel",function(e){if(e.ctrlKey)e.preventDefault();},{passive:false});
}
function scheduleUpdateNotice(){
    if(!aiServerReady()) return;
    checkUpdate(true).then(function(d){
        if(!d || !d.update_available) return;
        var key=String(d.latest||"");
        if(!key || LS.get("update_notice_version","")===key) return;
        LS.set("update_notice_version",key);
        toast(getLang()==="si" ? "අලුත් app version එකක් තියෙනවා: "+key : "New Smart Plant version available: "+key, false);
    }).catch(function(){});
}
function init() {
    installNativeSurfaceGuards();
    setTheme(LS.get("theme", "cyber"), false);
    setLanguage(getLang(), false);
    set("sUnits", LS.get("units", "C"));
    set("sPoll", LS.get("poll", 1));
    if ($("sAiEnabled")) $("sAiEnabled").checked = LS.get("ai_enabled", "1") === "1";
    if ($("sAiControl")) $("sAiControl").checked = LS.get("ai_control_enabled", "1") !== "0";
    if ($("sLocalVoiceAI")) { $("sLocalVoiceAI").checked = useLocalVoiceAI(); $("sLocalVoiceAI").onchange=function(){ LS.set("local_voice_ai",this.checked?"1":"0"); if(this.checked) checkLocalVoiceAI().catch(function(){}); }; }
    if ($("sAiAutoSpeak")) $("sAiAutoSpeak").checked = LS.get("ai_auto_speak", "1") !== "0";
    set("sAiModel", AI_MODEL_DEFAULT); if ($("sAiModelLabel")) $("sAiModelLabel").textContent = "GPT-OSS 20B"; setAiModelDetected(false);
    if ($("aiKeyState")) {
        $("aiKeyState").textContent = (cfg && cfg.groq_key_set) ? "PC HUB KEY PRESENT • VERIFYING" : tr("keyNotSet", "PC AI key not configured");
    }
    if ($("aiKeySettingsState")) {
        $("aiKeySettingsState").textContent = (cfg && cfg.groq_key_set) ? ((cfg.groq_key_source || "PC HUB") + " • READY") : tr("keyNotSet", "NOT CONFIGURED");
    }
    if ($("sAudioInput")) $("sAudioInput").onchange=function(){savePCAudioDeviceSelection().catch(function(e){toast(String(e.message||e),true);});};
    if ($("sAudioOutput")) $("sAudioOutput").onchange=function(){savePCAudioDeviceSelection().catch(function(e){toast(String(e.message||e),true);});};
    // Wait for pywebview's native bridge, then retry once more in case the
    // WebView page beat the native bridge by a few hundred milliseconds.
    if(!ANDROID_APP){
        function autoDetectPCAudio(){detectPCAudioDevices().catch(function(){});}
        window.addEventListener("pywebviewready",autoDetectPCAudio,{once:true});
        setTimeout(autoDetectPCAudio,700);
        setTimeout(autoDetectPCAudio,1800);
        if(navigator.mediaDevices&&navigator.mediaDevices.addEventListener) navigator.mediaDevices.addEventListener("devicechange",autoDetectPCAudio);
    }
    if ($("aiInput")) $("aiInput").addEventListener("keydown", function(e){if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();aiTextSend();}});
    aiSetMode(LS.get("ai_mode","voice"),false);
    loadAiHistory();
    setTimeout(function(){ if(API) detectGroqAPI(); }, 1200);
    setTimeout(scheduleUpdateNotice, 2600);
    if ($("sAutoScan")) $("sAutoScan").checked = LS.get("auto_scan", "1") !== "0";

    qsa("#nav button[data-page]").forEach(function (b) {
        b.addEventListener("click", function () { go(b.dataset.page); });
    });
    $("plantModal").addEventListener("click", function (e) { if (e.target === this) closePlant(); });
    document.addEventListener("keydown", function (e) {
        if (e.key === "Escape") closePlant();
    });
    window.addEventListener("resize", function () { drawLive(); drawHist(); });

    go("dashboard");

    /* Served by the PC app  -> the API is this same origin.
       Bundled in the APK    -> the page comes from appassets, so ask for an
                                address the first time and remember it.       */
    var isAndroidApp = location.hostname === "appassets.androidplatform.net";
    var served = (location.protocol === "http:" || location.protocol === "https:") && !isAndroidApp;
    API = LS.get("api", "");

    var SCAN_UI_VERSION = "20261001-v42-18-15-full-ai-voice-chat";
    if (LS.get("scan_ui_version", "") !== SCAN_UI_VERSION) {
        LS.set("scan_ui_version", SCAN_UI_VERSION);
        LS.set("auto_scan", "1");
        if ($("sAutoScan")) $("sAutoScan").checked = true;
    }

    var autoScan = LS.get("auto_scan", "1") !== "0";

    // PC app: always use the local Flask server for discovery first.
    // A stale saved board API can otherwise bypass the visible scan screen.
    if (served) {
        API = "";
        LS.set("api", "");
        return boot(function(){ if(autoScan) scanBoard(true); else start(); });
    }

    if (!API) return boot(function(){ if(autoScan) scanBoard(true); else showGate(""); });

    probe().then(function (ok) {
        if (ok) return boot(function(){ if(autoScan) scanBoard(true); else start(); });
        showGate("saved address did not answer");
    });
}

function showGate(msg) {
    var bootEl = $("boot"); if (bootEl) bootEl.classList.add("done");
    set("gateUrl", API || LS.get("api", ""));
    $("gate").classList.remove("hidden");
    $("gateMsg").textContent = msg || "";
    var btn = $("gateLocalBtn");
    if (btn && location.hostname === "appassets.androidplatform.net") btn.remove();
}

/* --------------------------- 17. exports ------------------------------ */
/* Android hardware/gesture Back: close sheet/dialog -> go to Dashboard -> (only then) let the app exit. */
function handleBack() {
    var nav = $("nav");
    var pw = $("panelWrap");
    if (pw && pw.classList.contains("full")) { panelFull(false); return true; }
    if (nav && nav.classList.contains("more-open")) { closeMoreSheet(); return true; }
    var pm = $("plantModal");
    if (pm && !pm.classList.contains("hidden")) { closePlant(); return true; }
    if (page && page !== "dashboard") { go("dashboard"); return true; }
    return false;
}

window.SP = {
    go: go, refresh: refresh, handleBack: handleBack,
    panelFull: panelFull, panelPc: panelPc, panelPcFullscreen: panelPcFullscreen,
    toggleAuto: function () { ctrl(S.auto_mode ? "auto_off" : "auto_on"); },
    togglePump: function () { ctrl(S.pump ? "pump_off" : "pump_on"); },
    timedRun: function () {
        var s = Math.max(1, Math.min(600, n("runSeconds") || 10));
        ctrl("pump_on", { seconds: s }).then(function(d){
            if (d && d.ok) toast("Pump command accepted for " + s + "s.");
        });
    },
    loadSettings: loadSettings, saveIrrigation: saveIrrigation, saveSystem: saveSystem,
    saveData: saveData, loadHistory: loadHistory, loadAnalytics: loadAnalytics,
    exportCsv: exportCsv, clearHistory: clearHistory,
    loadPlants: loadPlants, openPlant: openPlant, editPlant: editPlant, closePlant: closePlant,
    savePlant: savePlant, deletePlant: deletePlant, applyPlant: applyPlant,
    testLink: testLink, scanBoard: scanBoard, stopScan: stopScan, skipScan: skipScan, copyAddress: copyAddress, startCamera: startCamera, stopCamera: stopCamera,
    setTheme: setTheme, cycleTheme: cycleTheme, setLanguage: setLanguage,
    checkLocalVoiceAI: checkLocalVoiceAI, checkUpdate: checkUpdate, installUpdate: installUpdate, aiSend: aiSend, aiClear: aiClear, aiSetMode: aiSetMode, aiTextSend: aiTextSend, aiTextClear: aiTextClear, voiceToggle: voiceToggle, aiSpeakLast: aiSpeakLast, aiHealthCheck: aiHealthCheck, testAI: testAI, checkGroqKeyOnly: checkGroqKeyOnly, nativeDesktopAudioTest: nativeDesktopAudioTest, testAudio: testAudio, detectPCAudioDevices: detectPCAudioDevices, savePCAudioDeviceSelection: savePCAudioDeviceSelection, openPCMicrophoneSettings: openPCMicrophoneSettings, openPCSoundSettings: openPCSoundSettings, saveGroqKeySettings: saveGroqKeySettings, clearGroqKeySettings: clearGroqKeySettings, toggleGroqKeyVisibility: toggleGroqKeyVisibility,
    applyApiBase: applyApiBase, gateConnect: gateConnect, gatePreset: gatePreset,
    gateLocal: gateLocal
};

function safeInit() {
    try { init(); }
    catch (e) {
        console.error("[SmartPlant] init error", e);
        window.__SP_LAST_ERROR = String(e && e.message || e);
    }
    setTimeout(ensureBootSequence, 250);
}
if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", safeInit, { once: true });
} else {
    safeInit();
}

function ensureBootSequence() {
    if (window.__SP_BOOT_ACTIVE) return;
    try {
        boot();
    } catch (e) {
        console.error("[SmartPlant] ensureBootSequence error", e);
        // boot() already contains a hard recovery path. This only records the
        // error; it intentionally does not create a second competing sequence.
    }
}

})();
