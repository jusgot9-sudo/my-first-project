package com.smartplant.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.os.Build;
import android.content.Intent;
import android.content.SharedPreferences;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.speech.tts.UtteranceProgressListener;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;

import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private static final String UI_URL =
            "https://appassets.androidplatform.net/assets/ui/index.html";

    private static final long PAGE_TIMEOUT_MS = 8000L;
    private static final int CAMERA_PERMISSION = 4101;
    private static final int VOICE_PERMISSION = 4102;
    private static final int MEDIA_PERMISSION = 4103;

    private PermissionRequest pendingCameraRequest;
    private PermissionRequest pendingMediaRequest;
    private ConnectivityManager.NetworkCallback wifiNetworkCallback;
    private AndroidScanBridge scanBridge;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private android.media.AudioManager voiceAudioManager;
    private android.media.AudioFocusRequest voiceAudioFocusRequest;

    private WebView web;
    private WebViewAssetLoader loader;

    private View errorPanel;
    private TextView errorText;
    private Button retryButton;

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private boolean pageLoaded = false;
    private boolean pendingVoiceAfterPermission = false;
    private boolean ttsReady = false;

    private final Runnable timeoutRunnable =
            new Runnable() {

        @Override
        public void run() {

            if (!pageLoaded) {

                showError(
                        "Dashboard did not load.\n\n" +
                        "The local Android dashboard could not be opened."
                );
            }
        }
    };


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        // Normal Android app window: dark system bars stay visible, so the on-screen keyboard
        // resizes the page (adjustResize) and nothing is hidden under the bars.
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        bindToWifiNetwork();

        setContentView(
                R.layout.activity_main
        );
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        hideSystemBars();


        // --------------------------------------------------------
        // Views
        // --------------------------------------------------------

        web = findViewById(R.id.web);

        errorPanel =
                findViewById(R.id.errorPanel);

        errorText =
                findViewById(R.id.errorText);

        retryButton =
                findViewById(R.id.retryButton);


        if (web == null) {

            throw new IllegalStateException(
                    "WebView with id 'web' was not found."
            );
        }


        // --------------------------------------------------------
        // WebView Asset Loader
        // --------------------------------------------------------

        loader =
                new WebViewAssetLoader.Builder()
                        .setHttpAllowed(true)
                        .setDomain(
                                "appassets.androidplatform.net"
                        )
                        .addPathHandler(
                                "/assets/",
                                new WebViewAssetLoader.AssetsPathHandler(
                                        this
                                )
                        )
                        .build();


        // --------------------------------------------------------
        // WebView appearance
        // --------------------------------------------------------

        web.setBackgroundColor(
                Color.rgb(2, 6, 9)
        );

        web.setOverScrollMode(
                View.OVER_SCROLL_NEVER
        );

        web.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        web.setVerticalScrollBarEnabled(false);

        web.setHorizontalScrollBarEnabled(false);
        web.setVerticalFadingEdgeEnabled(false);
        web.setHorizontalFadingEdgeEnabled(false);

        // Do not intercept touch events at the WebView host level.
        // Intercepting ACTION_POINTER events here can cancel the Android
        // WebView gesture/click sequence on some devices, making normal
        // one-finger taps appear dead. Pinch zoom is disabled by WebView
        // settings below, so no custom touch listener is needed.
        web.setClickable(true);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus(View.FOCUS_DOWN);


        // --------------------------------------------------------
        // WebView settings
        // --------------------------------------------------------

        WebSettings s =
                web.getSettings();

        s.setJavaScriptEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // The dashboard is served from WebViewAssetLoader, not file://.
        // Disable legacy file-origin bridges to prevent local file exposure.
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            s.setAllowFileAccessFromFileURLs(false);
            s.setAllowUniversalAccessFromFileURLs(false);
        }

        // WebView JavaScript cannot perform raw LAN/UDP discovery safely by
        // itself. The native bridge below performs the real WiFi discovery
        // off the UI thread, then returns the detected board address to JS.
        scanBridge = new AndroidScanBridge();
        // Expose one complete bridge. The previous build exposed only the
        // board-scanner object as AndroidBridge, so startVoice()/speakText()
        // were invisible to JavaScript and Android voice chat could not start.
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        textToSpeech = createPreferredTts();
        if (textToSpeech != null) textToSpeech.setSpeechRate(0.98f);
        installTtsProgressListener();

        // Force UTF-8 explicitly. Without this, some WebView builds ignore
        // the page's own <meta charset="utf-8"> when content is served via
        // shouldInterceptRequest() and guess a different encoding instead -
        // Explicit UTF-8 avoids WebView guessing the page encoding.
        // garbage on screen, even though the actual files on disk are
        // correct UTF-8 (verified).
        s.setDefaultTextEncodingName("UTF-8");

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {

            // ALWAYS_ALLOW, not COMPATIBILITY_MODE: the page itself is served
            // from the https://appassets.androidplatform.net virtual origin,
            // but it then fetch()es the ESP32 board / PC server over plain
            // http:// on the LAN. COMPATIBILITY_MODE blocks some of those
            // requests as mixed content - this is almost certainly why
            // "can't connect to the board" only happens on Android and not
            // on the PC app (which is http-to-http throughout, no mixed
            // content rule applies there at all).
            s.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        }
        s.setDomStorageEnabled(true);

        s.setDatabaseEnabled(true);

        // Keep the bundled width=device-width page at the device scale.
        // Overview scaling makes some OEM WebViews behave like a browser.
        s.setUseWideViewPort(false);

        s.setLoadWithOverviewMode(false);

        s.setSupportZoom(false);

        s.setBuiltInZoomControls(false);

        s.setDisplayZoomControls(false);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(true);
        }

        // Keep the mobile surface at its CSS/device scale. The page itself
        // also declares width=device-width and user-scalable=no.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            s.setOffscreenPreRaster(true);
        }

        s.setTextZoom(100);

        s.setDefaultFontSize(16);

        // NO_CACHE: this app's HTML/CSS/JS ship inside the APK itself, so
        // there's nothing to gain from caching them, and LOAD_DEFAULT can
        // keep serving an old cached copy after an app update - which looks
        // exactly like "the fix didn't get applied" when it actually did.
        s.setCacheMode(
                WebSettings.LOAD_NO_CACHE
        );


        // --------------------------------------------------------
        // WebView client
        // --------------------------------------------------------

        web.setWebViewClient(
                new WebViewClient() {

                    @Override
                    public WebResourceResponse
                    shouldInterceptRequest(
                            WebView view,
                            WebResourceRequest request
                    ) {

                        return loader
                                .shouldInterceptRequest(
                                        request.getUrl()
                                );
                    }


                    @Override
                    @SuppressWarnings("deprecation")
                    public WebResourceResponse
                    shouldInterceptRequest(
                            WebView view,
                            String url
                    ) {

                        return loader
                                .shouldInterceptRequest(
                                        Uri.parse(url)
                                );
                    }


                    @Override
                    public void onPageStarted(
                            WebView view,
                            String url,
                            android.graphics.Bitmap favicon
                    ) {

                        pageLoaded = false;

                        hideError();

                        handler.removeCallbacks(
                                timeoutRunnable
                        );

                        handler.postDelayed(
                                timeoutRunnable,
                                PAGE_TIMEOUT_MS
                        );

                        super.onPageStarted(
                                view,
                                url,
                                favicon
                        );
                    }


                    @Override
                    public void onPageFinished(
                            WebView view,
                            String url
                    ) {

                        pageLoaded = true;

                        handler.removeCallbacks(
                                timeoutRunnable
                        );

                        hideError();

                        super.onPageFinished(
                                view,
                                url
                        );
                    }


                    @Override
                    public void onReceivedError(
                            WebView view,
                            int errorCode,
                            String description,
                            String failingUrl
                    ) {

                        if (failingUrl != null &&
                                failingUrl.startsWith(
                                        "https://appassets.androidplatform.net/"
                                )) {

                            showError(
                                    "Dashboard loading error.\n\n" +
                                    description
                            );
                        }

                        super.onReceivedError(
                                view,
                                errorCode,
                                description,
                                failingUrl
                        );
                    }


                    @Override
                    public boolean shouldOverrideUrlLoading(
                            WebView view,
                            WebResourceRequest request
                    ) {

                        String url =
                                request.getUrl()
                                        .toString();


                        if (url.startsWith(
                                "https://appassets.androidplatform.net/"
                        )) {
                            return false;
                        }


                        if (url.startsWith("http://") ||
                                url.startsWith("https://")) {

                            view.loadUrl(url);

                            return true;
                        }


                        return false;
                    }


                    @Override
                    @SuppressWarnings("deprecation")
                    public boolean shouldOverrideUrlLoading(
                            WebView view,
                            String url
                    ) {

                        if (url.startsWith(
                                "https://appassets.androidplatform.net/"
                        )) {

                            return false;
                        }


                        if (url.startsWith("http://") ||
                                url.startsWith("https://")) {

                            view.loadUrl(url);

                            return true;
                        }


                        return false;
                    }
                }
        );


        // --------------------------------------------------------
        // Chrome
        // --------------------------------------------------------

        web.setWebChromeClient(
                new WebChromeClient() {
                    @Override
                    public void onPermissionRequest(final PermissionRequest request) {
                        runOnUiThread(() -> {
                            if (request == null || request.getOrigin() == null ||
                                    !request.getOrigin().toString().startsWith("https://appassets.androidplatform.net/")) {
                                if (request != null) request.deny();
                                return;
                            }

                            boolean wantsCamera=false, wantsAudio=false;
                            for (String resource : request.getResources()) {
                                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) wantsCamera=true;
                                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) wantsAudio=true;
                            }
                            if (!wantsCamera && !wantsAudio) { request.deny(); return; }

                            java.util.ArrayList<String> missing=new java.util.ArrayList<>();
                            if (android.os.Build.VERSION.SDK_INT>=23) {
                                if (wantsCamera && androidx.core.content.ContextCompat.checkSelfPermission(MainActivity.this,android.Manifest.permission.CAMERA)!=android.content.pm.PackageManager.PERMISSION_GRANTED) missing.add(android.Manifest.permission.CAMERA);
                                if (wantsAudio && androidx.core.content.ContextCompat.checkSelfPermission(MainActivity.this,android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED) missing.add(android.Manifest.permission.RECORD_AUDIO);
                            }
                            if (!missing.isEmpty()) {
                                pendingMediaRequest=request;
                                androidx.core.app.ActivityCompat.requestPermissions(MainActivity.this,missing.toArray(new String[0]),MEDIA_PERMISSION);
                                return;
                            }
                            java.util.ArrayList<String> granted=new java.util.ArrayList<>();
                            if (wantsCamera) granted.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
                            if (wantsAudio) granted.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
                            request.grant(granted.toArray(new String[0]));
                        });
                    }

                    @Override
                    public boolean onConsoleMessage(android.webkit.ConsoleMessage cm) {
                        Log.e("SmartPlantJS", cm.message() + " | " + cm.sourceId() + ":" + cm.lineNumber());
                        return true;
                    }
                }
        );


        // --------------------------------------------------------
        // Retry
        // --------------------------------------------------------

        if (retryButton != null) {

            retryButton.setOnClickListener(
                    v -> loadDashboard()
            );
        }


        // --------------------------------------------------------
        // Load local dashboard
        // --------------------------------------------------------

        // Request microphone only after the activity is attached and the WebView
        // is visible. Requesting it before setContentView() can make the system
        // permission dialog appear behind the launch surface on some devices.
        handler.postDelayed(this::requestVoicePermissionOnce, 650L);
        loadDashboard();
    }


    // ============================================================
    // LOCAL GOOGLE TTS
    // ============================================================
    private TextToSpeech createPreferredTts() {
        // Use Android's currently selected/default TTS engine instead of probing
        // the installed engines before the TTS instance exists. This avoids the
        // compile-time error seen on Java/AGP builds and works across devices.
        final TextToSpeech[] holder = new TextToSpeech[1];
        TextToSpeech.OnInitListener listener = status -> {
            ttsReady = (status == TextToSpeech.SUCCESS);
            if (holder[0] != null && ttsReady) {
                holder[0].setSpeechRate(0.98f);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    holder[0].setAudioAttributes(new android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build());
                }
            }
        };
        try {
            boolean googleInstalled=false;
            try {
                android.content.Intent ttsIntent=new android.content.Intent(TextToSpeech.Engine.INTENT_ACTION_TTS_SERVICE);
                java.util.List<android.content.pm.ResolveInfo> engines=getPackageManager().queryIntentServices(ttsIntent,0);
                for(android.content.pm.ResolveInfo info:engines){
                    if(info!=null&&info.serviceInfo!=null&&"com.google.android.tts".equals(info.serviceInfo.packageName)){googleInstalled=true;break;}
                }
            } catch(Exception ignored) {}
            if(googleInstalled){
                holder[0]=new TextToSpeech(this,listener,"com.google.android.tts");
            } else {
                holder[0]=new TextToSpeech(this,listener);
            }
            return holder[0];
        } catch(Exception firstError){
            Log.w("SmartPlantTTS","Preferred Google TTS initialization failed; using device default",firstError);
            try{
                holder[0]=new TextToSpeech(this,listener);
                return holder[0];
            }catch(Exception fallbackError){
                Log.e("SmartPlantTTS","Unable to initialize Android TTS",fallbackError);
                holder[0]=null;
                return null;
            }
        }
    }

    private void installTtsProgressListener() {
        if (textToSpeech == null) return;
        try {
            textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) {
                    if ("smartplant-ai".equals(utteranceId)) sendVoiceState(false, "Voice reply playing…");
                }
                @Override public void onDone(String utteranceId) {
                    if ("smartplant-ai".equals(utteranceId)) { releaseVoiceAudioFocus(); sendTtsFinished(true, "Voice reply finished."); }
                }
                @Override public void onError(String utteranceId) {
                    if ("smartplant-ai".equals(utteranceId)) { releaseVoiceAudioFocus(); sendTtsFinished(false, "Speaker/TTS playback error."); }
                }
                @Override public void onError(String utteranceId, int errorCode) {
                    if ("smartplant-ai".equals(utteranceId)) { releaseVoiceAudioFocus(); sendTtsFinished(false, "Speaker/TTS playback error (" + errorCode + ")."); }
                }
            });
        } catch (Exception e) {
            Log.w("SmartPlantTTS", "Could not install TTS progress listener", e);
        }
    }

    private int configureTtsForLanguage(String language) {
        if (textToSpeech == null) return TextToSpeech.ERROR;
        Locale target = "si".equalsIgnoreCase(language) ? new Locale("si", "LK") :
                ("ja".equalsIgnoreCase(language) ? Locale.JAPAN : Locale.US);
        int best = textToSpeech.setLanguage(target);
        if ("si".equalsIgnoreCase(language) &&
                (best == TextToSpeech.LANG_MISSING_DATA || best == TextToSpeech.LANG_NOT_SUPPORTED)) {
            try {
                for (Voice voice : textToSpeech.getVoices()) {
                    if (voice != null && voice.getLocale() != null &&
                            "si".equalsIgnoreCase(voice.getLocale().getLanguage())) {
                        textToSpeech.setVoice(voice);
                        return TextToSpeech.SUCCESS;
                    }
                }
            } catch (Exception ignored) {}
        }
        return best;
    }

    // ============================================================
    // LOAD DASHBOARD
    // ============================================================

    private void loadDashboard() {

        pageLoaded = false;

        hideError();

        handler.removeCallbacks(
                timeoutRunnable
        );

        web.stopLoading();

        web.clearHistory();

        web.loadUrl(UI_URL);

        handler.postDelayed(
                timeoutRunnable,
                PAGE_TIMEOUT_MS
        );
    }


    // ============================================================
    // ERROR PANEL
    // ============================================================

    private void showError(String message) {

        if (errorPanel != null) {

            errorPanel.setVisibility(
                    View.VISIBLE
            );
        }

        if (errorText != null) {

            errorText.setText(
                    message
            );
        }
    }


    private void hideError() {

        if (errorPanel != null) {

            errorPanel.setVisibility(
                    View.GONE
            );
        }
    }


    // ============================================================
    // BACK BUTTON
    // ============================================================

    @Override
    public void onBackPressed() {

        if (web == null) {
            super.onBackPressed();
            return;
        }

        // Normal Android-app behaviour: let the page close its "More" sheet / dialog or
        // return to the Dashboard first. Only exit when the page says it has nothing to do.
        try {
            web.evaluateJavascript(
                    "(function(){try{return !!(window.SP&&SP.handleBack&&SP.handleBack());}catch(e){return false;}})()",
                    new android.webkit.ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String consumed) {
                            if ("true".equals(consumed)) return;
                            if (web != null && web.canGoBack()) web.goBack();
                            else MainActivity.super.onBackPressed();
                        }
                    });
        } catch (Exception e) {
            if (web.canGoBack()) web.goBack();
            else super.onBackPressed();
        }
    }


    // ============================================================
    // CLEANUP
    // ============================================================

    private void hideSystemBars() {
        // System bars stay visible (normal Android app). Make sure edge-to-edge hiding is off.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.show(android.view.WindowInsets.Type.statusBars()
                        | android.view.WindowInsets.Type.navigationBars());
            }
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    private void requestVoicePermissionOnce() {
        if (android.os.Build.VERSION.SDK_INT < 23) return;
        if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return;
        }
        if (voicePermissionRequestInFlight) return;
        voicePermissionRequestInFlight=true;
        androidx.core.app.ActivityCompat.requestPermissions(
                this,
                new String[]{android.Manifest.permission.RECORD_AUDIO},
                VOICE_PERMISSION
        );
    }

    private void showMicrophonePermissionHelp() {
        if (isFinishing()) return;
        boolean canAskAgain = android.os.Build.VERSION.SDK_INT < 30 || androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.RECORD_AUDIO);
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Microphone permission required")
                .setMessage(canAskAgain ? "Smart Plant Voice AI needs microphone access. Tap Allow Microphone, then speak to the plant AI." : "Android has blocked the microphone prompt. Open App Settings and enable Microphone for Smart Plant.")
                .setNegativeButton("Not now", null)
                .setPositiveButton(canAskAgain ? "Allow Microphone" : "Open App Settings", (dialog, which) -> {
                    if (canAskAgain) androidx.core.app.ActivityCompat.requestPermissions(MainActivity.this,new String[]{android.Manifest.permission.RECORD_AUDIO},VOICE_PERMISSION);
                    else { try { Intent i=new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS); i.setData(Uri.parse("package:"+getPackageName())); startActivity(i); } catch (Exception ignored) {} }
                }).show();
    }

    @Override
    protected void onDestroy() {

        voiceSessionActive=false;
        handler.removeCallbacks(timeoutRunnable);
        try { if (scanBridge != null) scanBridge.stopScan(); } catch (Exception ignored) {}
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && wifiNetworkCallback != null) cm.unregisterNetworkCallback(wifiNetworkCallback);
            if (cm != null) cm.bindProcessToNetwork(null);
        } catch (Exception ignored) {}

        try { if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; } } catch (Exception ignored) {}
        try { if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; } releaseVoiceAudioFocus(); } catch (Exception ignored) {}

        if (web != null) {

            web.stopLoading();

            web.destroy();

            web = null;
        }

        super.onDestroy();
    }


    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION && pendingCameraRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) pendingCameraRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            else pendingCameraRequest.deny();
            pendingCameraRequest = null;
            return;
        }
        if (requestCode == MEDIA_PERMISSION && pendingMediaRequest != null) {
            boolean cam = android.os.Build.VERSION.SDK_INT < 23 || androidx.core.content.ContextCompat.checkSelfPermission(this,android.Manifest.permission.CAMERA)==android.content.pm.PackageManager.PERMISSION_GRANTED;
            boolean mic = android.os.Build.VERSION.SDK_INT < 23 || androidx.core.content.ContextCompat.checkSelfPermission(this,android.Manifest.permission.RECORD_AUDIO)==android.content.pm.PackageManager.PERMISSION_GRANTED;
            java.util.ArrayList<String> granted=new java.util.ArrayList<>();
            for (String resource : pendingMediaRequest.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource) && cam) granted.add(resource);
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource) && mic) granted.add(resource);
            }
            if (!granted.isEmpty()) pendingMediaRequest.grant(granted.toArray(new String[0])); else pendingMediaRequest.deny();
            pendingMediaRequest = null;
            return;
        }
        if (requestCode == VOICE_PERMISSION) {
            voicePermissionRequestInFlight=false;
            boolean granted = grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            if (granted) {
                sendVoiceState(false, "Microphone permission granted.");
                if (pendingVoiceAfterPermission) {
                    pendingVoiceAfterPermission=false;
                    voiceSessionActive=true;
                    voiceConsecutiveErrors=0;
                    handler.post(() -> startVoiceRecognition(pendingVoiceLanguage));
                }
            } else {
                pendingVoiceAfterPermission=false;
                voiceSessionActive=false;
                sendVoiceState(false, "Microphone permission denied.");
                showMicrophonePermissionHelp();
            }
        }
    }

    // ============================================================
    // AI + VOICE BRIDGE
    // ============================================================
    private SharedPreferences aiPrefs(){ return getSharedPreferences("smartplant_ai", MODE_PRIVATE); }
    private String escJs(String value){ return value==null?"":value.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r"); }
    private String extractResponseText(JSONObject body){
        try {
            String d = body.optString("output_text", "");
            if (!d.trim().isEmpty()) return d.trim();
            JSONArray choices = body.optJSONArray("choices");
            if (choices != null && choices.length() > 0) {
                JSONObject choice = choices.optJSONObject(0);
                JSONObject message = choice == null ? null : choice.optJSONObject("message");
                JSONObject msg = message;
                if (msg != null) {
                    Object content = msg.opt("content");
                    if (content instanceof String && !((String) content).trim().isEmpty()) return ((String) content).trim();
                }
            }
            return "";
        } catch(Exception e){ return ""; }
    }
    // Android never stores or sends a Groq API key. AI requests are routed to the PC Smart Plant hub.
    @JavascriptInterface public void saveAiSettings(String ignoredKey,String model,String ignoredWeatherKey,String location,String enabled){
        aiPrefs().edit().putString("ai_model", (model==null||model.trim().isEmpty())?"openai/gpt-oss-20b":model.trim())
                .putString("weather_location",location==null?"":location.trim())
                .putBoolean("ai_enabled","1".equals(enabled))
                .remove("groq_key").remove("openweather_key").apply();
    }
    @JavascriptInterface public String hasAiKey(){ return "0"; }
    @JavascriptInterface public void validateGroqKey(String ignoredKey,String callbackId){
        runOnUiThread(() -> { if(web==null)return; String js="window.__androidGroqValidation&&window.__androidGroqValidation(\""+escJs(callbackId)+"\",\"false\",\"\");"; try{web.evaluateJavascript(js,null);}catch(Exception ignored){} });
    }
    @JavascriptInterface public void clearAiKey(){ aiPrefs().edit().remove("groq_key").remove("openweather_key").apply(); }
    private void requestVoiceAudioFocus() {
        try {
            voiceAudioManager = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
            if (voiceAudioManager == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                voiceAudioFocusRequest = new android.media.AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                        .setAudioAttributes(new android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build())
                        .build();
                voiceAudioManager.requestAudioFocus(voiceAudioFocusRequest);
            } else {
                voiceAudioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK);
            }
            if (Build.VERSION.SDK_INT >= 21) {
                voiceAudioManager.setMode(AudioManager.MODE_NORMAL);
            }
        } catch (Exception e) {
            Log.w("SmartPlantAudio", "Audio focus setup failed", e);
        }
    }

    private void releaseVoiceAudioFocus() {
        try {
            if (voiceAudioManager == null) return;
            if (Build.VERSION.SDK_INT >= 26 && voiceAudioFocusRequest != null) {
                voiceAudioManager.abandonAudioFocusRequest(voiceAudioFocusRequest);
            } else {
                voiceAudioManager.abandonAudioFocus(null);
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface public void speakText(String text,String language){
        final String clean = text == null ? "" : text.trim();
        if (clean.isEmpty()) return;
        runOnUiThread(() -> {
            try {
                if (textToSpeech == null) textToSpeech = createPreferredTts();
                if (textToSpeech == null) throw new IllegalStateException("Android TTS engine is unavailable.");
                if (!ttsReady) {
                    handler.postDelayed(() -> {
                        if (ttsReady) speakText(clean, language);
                        else {
                            sendVoiceState(false, "Android TTS engine is not ready.");
                            sendTtsFinished(false, "Android TTS engine is not ready.");
                        }
                    }, 450L);
                    return;
                }
                int r=configureTtsForLanguage(language);
                if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED){
                    // Keep the reply audible even when a Sinhala voice pack is missing.
                    r=configureTtsForLanguage("en");
                }
                if(r==TextToSpeech.LANG_MISSING_DATA||r==TextToSpeech.LANG_NOT_SUPPORTED){
                    throw new IllegalStateException("No supported TTS voice is installed on this device.");
                }
                requestVoiceAudioFocus();
                android.media.AudioManager am=(android.media.AudioManager)getSystemService(Context.AUDIO_SERVICE);
                if(am!=null){
                    try{
                        if(am.getStreamVolume(AudioManager.STREAM_MUSIC)<=0) sendVoiceState(false,"Media volume is muted; raise the phone media volume.");
                    }catch(Exception ignored){}
                }
                Bundle params=new Bundle();
                params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
                params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f);
                int rc=textToSpeech.speak(clean,TextToSpeech.QUEUE_FLUSH,params,"smartplant-ai");
                if(rc==TextToSpeech.ERROR){
                    try {
                        textToSpeech.stop();
                        int retry=textToSpeech.speak(clean,TextToSpeech.QUEUE_FLUSH,params,"smartplant-ai");
                        if(retry==TextToSpeech.ERROR) throw new IllegalStateException("Android TTS failed to start.");
                    } catch(Exception retryError) {
                        throw new IllegalStateException("Android TTS failed to start: " + retryError.getMessage());
                    }
                }
                sendVoiceState(false,"Voice reply playing…");
            }catch(Exception e){
                sendVoiceState(false,"Speaker/TTS error: "+e.getMessage());
                sendTtsFinished(false,"Speaker/TTS error: "+e.getMessage());
            }
        });
    }
    private String pendingVoiceLanguage="en";
    private boolean voicePermissionRequestInFlight=false;
    private boolean voiceSessionActive=false;
    private int voiceConsecutiveErrors=0;
    @JavascriptInterface public synchronized void startVoice(String language){
        pendingVoiceLanguage=(language==null||language.trim().isEmpty())?"en":language;
        voiceSessionActive=true;
        voiceConsecutiveErrors=0;
        if(Build.VERSION.SDK_INT>=23&&androidx.core.content.ContextCompat.checkSelfPermission(this,android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            pendingVoiceAfterPermission=true;
            if(!voicePermissionRequestInFlight){
                voicePermissionRequestInFlight=true;
                androidx.core.app.ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.RECORD_AUDIO},VOICE_PERMISSION);
            }
            return;
        }
        pendingVoiceAfterPermission=false;
        startVoiceRecognition(pendingVoiceLanguage);
    }
    @JavascriptInterface public synchronized void stopVoice(){
        voiceSessionActive=false;
        voiceConsecutiveErrors=0;
        try{ if(speechRecognizer!=null) speechRecognizer.cancel(); }catch(Exception ignored){}
        sendVoiceState(false,"Voice stopped.");
    }
    private String voiceErrorText(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_AUDIO: return "Microphone audio error.";
            case SpeechRecognizer.ERROR_CLIENT: return "Voice recognizer client error.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission is not granted.";
            case SpeechRecognizer.ERROR_NETWORK: return "Voice recognition network error.";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Voice recognition network timeout.";
            case SpeechRecognizer.ERROR_NO_MATCH: return "I could not understand the voice command. Please speak again.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Voice recognizer is busy. Try again in a moment.";
            case SpeechRecognizer.ERROR_SERVER: return "Voice recognition server error.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "No speech was detected. Please speak after the microphone starts.";
            default: return "Voice recognition error (" + code + ").";
        }
    }

    private void prepareNetworkForSpeechRecognition() {
        // The app pins its process to the controller Wi-Fi so LAN API calls
        // reliably reach the PC/ESP32. Android SpeechRecognizer may need the
        // normal internet-capable route, so temporarily release that pin while
        // a recognition turn is active. The process is rebound to Wi-Fi as soon
        // as recognition finishes or errors.
        try {
            ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm!=null) cm.bindProcessToNetwork(null);
        } catch(Exception e) {
            Log.w("SmartPlantNetwork", "Could not release LAN binding for speech", e);
        }
    }

    private void restoreWifiAfterSpeech() {
        try {
            ensureWifiNetworkBinding();
        } catch(Exception e) {
            Log.w("SmartPlantNetwork", "Could not restore Wi-Fi LAN binding", e);
        }
    }

    private void startVoiceRecognition(String language) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendVoiceState(false, "Speech recognition is not available on this device.");
            return;
        }

        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
        } catch (Exception ignored) {}

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle b) {
                sendVoiceState(true, "Listening…");
            }
            @Override public void onBeginningOfSpeech() {
                sendVoiceState(true, "Listening…");
            }
            @Override public void onRmsChanged(float v) {}
            @Override public void onBufferReceived(byte[] b) {}
            @Override public void onEndOfSpeech() {
                sendVoiceState(false, "Processing voice…");
            }
            @Override public void onError(int e) {
                restoreWifiAfterSpeech();
                voiceConsecutiveErrors++;
                String msg=voiceErrorText(e);
                sendVoiceState(false, msg);
                if(voiceSessionActive && e != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS && voiceConsecutiveErrors < 8) {
                    long delay=(e==SpeechRecognizer.ERROR_RECOGNIZER_BUSY)?900L:550L;
                    handler.postDelayed(() -> {
                        if(voiceSessionActive) startVoiceRecognition(pendingVoiceLanguage);
                    }, delay);
                } else if(voiceSessionActive && voiceConsecutiveErrors >= 8) {
                    voiceSessionActive=false;
                    sendVoiceState(false, "Voice chat stopped after repeated recognition errors.");
                }
            }
            @Override public void onResults(Bundle b) {
                restoreWifiAfterSpeech();
                voiceConsecutiveErrors=0;
                ArrayList<String> a = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String t = a != null && !a.isEmpty() ? a.get(0) : "";
                sendVoiceResult(t);
                sendVoiceState(false, t.isEmpty() ? "No speech captured." : "Processing voice…");
            }
            @Override public void onPartialResults(Bundle b) {}
            @Override public void onEvent(int e, Bundle b) {}
        });

        Intent in = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        in.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        in.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                "si".equalsIgnoreCase(language) ? "si-LK" :
                        ("ja".equalsIgnoreCase(language) ? "ja-JP" : "en-US"));
        in.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        in.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        in.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());

        prepareNetworkForSpeechRecognition();
        try {
            speechRecognizer.startListening(in);
        } catch (Exception e) {
            sendVoiceState(false, "Unable to start microphone: " + e.getClass().getSimpleName());
        }
    }
    private void sendTtsFinished(boolean ok,String message){
        if(web==null)return;
        String js="window.__androidTtsFinished&&window.__androidTtsFinished("+ok+",\""+escJs(message)+"\");";
        runOnUiThread(()->{try{web.evaluateJavascript(js,null);}catch(Exception ignored){}});
    }
    private void sendVoiceResult(String text){if(web==null)return;String js="window.__androidVoiceResult&&window.__androidVoiceResult(\""+escJs(text)+"\");";runOnUiThread(()->{try{web.evaluateJavascript(js,null);}catch(Exception ignored){}});}
    private void sendVoiceState(boolean active,String message){if(web==null)return;String js="window.__androidVoiceState&&window.__androidVoiceState("+active+",\""+escJs(message)+"\");";runOnUiThread(()->{try{web.evaluateJavascript(js,null);}catch(Exception ignored){}});}
    @JavascriptInterface
    public void aiChat(String keyArg, String modelArg, String msgArg, String language,
                       String callbackId, String sensorJson, String historyText) {
        // Security/architecture: Android is a client, not the Groq key holder.
        // The dashboard already posts Voice AI requests to the PC hub.
        sendAiResult(callbackId == null ? "" : callbackId, false,
                "Connect this Android app to the Smart Plant PC hub for Voice AI.");
    }

    private String readAll(InputStream in)throws java.io.IOException{if(in==null)return "";java.io.BufferedReader br=new java.io.BufferedReader(new java.io.InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);return sb.toString();}
    private void sendAiResult(String id,boolean ok,String text){if(web==null)return;String js="window.__androidAiResult&&window.__androidAiResult(\""+escJs(id)+"\","+ok+",\""+escJs(text)+"\");";runOnUiThread(()->{try{web.evaluateJavascript(js,null);}catch(Exception ignored){}});}

    // ============================================================
    // WIFI BINDING
    // ============================================================
    //
    // The ESP32's WiFi network has no internet access. Android's default
    // network selection prefers a network that DOES have internet, so even
    // while this phone shows "connected" to that WiFi, the OS can quietly
    // route this app's actual traffic over mobile data instead - which
    // obviously cannot reach a private 192.168.x.x / 10.x.x.x address.
    // Binding the process to the active WiFi network specifically forces
    // every request this app makes (WebView included) through it.

    private void bindToWifiNetwork() {

        try {

            final ConnectivityManager cm = (ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);

            if (cm == null) {
                return;
            }

            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .build();

            if (wifiNetworkCallback != null) {
                try { cm.unregisterNetworkCallback(wifiNetworkCallback); } catch (Exception ignored) {}
            }
            wifiNetworkCallback = new ConnectivityManager.NetworkCallback() {

                        @Override
                        public void onAvailable(Network network) {

                            super.onAvailable(network);

                            try {
                                cm.bindProcessToNetwork(network);
                            } catch (Exception ignored) {
                            }
                        }

                        @Override
                        public void onLost(Network network) {

                            super.onLost(network);

                            try {
                                cm.bindProcessToNetwork(null);
                            } catch (Exception ignored) {
                            }
                        }
                    };
            cm.requestNetwork(request, wifiNetworkCallback);

        } catch (Exception e) {
            // If this fails for any reason, the app still works exactly as
            // before - it just goes back to relying on Android's default
            // network choice.
        }
    }


    /**
     * Prefer the currently connected WiFi transport even when Android says
     * the WiFi network has no internet. Some phones otherwise route LAN
     * traffic through mobile data while the WiFi icon still shows connected.
     */
    private void ensureWifiNetworkBinding() {
        try {
            ConnectivityManager cm =
                    (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;

            Network active = cm.getActiveNetwork();
            if (active != null) {
                NetworkCapabilities activeCaps = cm.getNetworkCapabilities(active);
                if (activeCaps != null
                        && activeCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(active);
                    return;
                }
            }

            Network[] networks = cm.getAllNetworks();
            for (Network network : networks) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                if (caps != null
                        && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    cm.bindProcessToNetwork(network);
                    return;
                }
            }
        } catch (Exception ignored) {
            // Existing requestNetwork callback remains as a fallback.
        }

        bindToWifiNetwork();
    }

    // ============================================================
    // JAVASCRIPT BRIDGE
    // ============================================================
    // One stable bridge for the APK UI: discovery + voice + audio devices.
    // Each method is explicitly annotated because only @JavascriptInterface
    // members are visible inside Android WebView.
    private final class AndroidBridge {
        @JavascriptInterface public void openUrl(String link) {
            try {
                if (link == null || !(link.startsWith("https://github.com/")
                        || link.startsWith("https://objects.githubusercontent.com/"))) return;
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(link));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) { }
        }
        @JavascriptInterface public synchronized void scanBoard() {
            if (scanBridge != null) scanBridge.scanBoard();
        }

        @JavascriptInterface public void stopScan() {
            if (scanBridge != null) scanBridge.stopScan();
        }

        @JavascriptInterface public synchronized void startVoice(String language) {
            MainActivity.this.startVoice(language);
        }

        @JavascriptInterface public synchronized void stopVoice() {
            MainActivity.this.stopVoice();
        }

        @JavascriptInterface public void speakText(String text, String language) {
            MainActivity.this.speakText(text, language);
        }

        @JavascriptInterface public String audioDevices() {
            return MainActivity.this.audioDevicesJson();
        }
    }

    private String audioDeviceName(android.media.AudioDeviceInfo info) {
        if (info == null) return "Unknown audio device";
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                CharSequence product = info.getProductName();
                if (product != null && product.length() > 0) return product.toString();
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                CharSequence product = info.getProductName();
                if (product != null && product.length() > 0) return product.toString();
            }
        } catch (Exception ignored) {}
        try {
            int type = info.getType();
            switch (type) {
                case android.media.AudioDeviceInfo.TYPE_BUILTIN_MIC: return "Built-in microphone";
                case android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET: return "Wired headset";
                case android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO: return "Bluetooth headset";
                case android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP: return "Bluetooth audio";
                case android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER: return "Phone speaker";
                case android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE: return "Phone earpiece";
                case android.media.AudioDeviceInfo.TYPE_HDMI: return "HDMI audio";
                default: return "Audio device type " + type;
            }
        } catch (Exception ignored) {
            return "Audio device";
        }
    }

    private String audioDevicesJson() {
        try {
            JSONObject out = new JSONObject();
            JSONArray inputs = new JSONArray();
            JSONArray outputs = new JSONArray();
            if (android.os.Build.VERSION.SDK_INT >= 23) {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    for (android.media.AudioDeviceInfo info : am.getDevices(AudioManager.GET_DEVICES_INPUTS)) {
                        JSONObject item = new JSONObject();
                        item.put("id", info.getId());
                        item.put("name", audioDeviceName(info));
                        item.put("type", info.getType());
                        inputs.put(item);
                    }
                    for (android.media.AudioDeviceInfo info : am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                        JSONObject item = new JSONObject();
                        item.put("id", info.getId());
                        item.put("name", audioDeviceName(info));
                        item.put("type", info.getType());
                        outputs.put(item);
                    }
                }
            }
            // Every Android phone has at least the built-in mic/speaker path,
            // even if an OEM returns an empty AudioDeviceInfo list.
            if (inputs.length() == 0) {
                JSONObject item = new JSONObject(); item.put("id", -1); item.put("name", "Built-in microphone"); inputs.put(item);
            }
            if (outputs.length() == 0) {
                JSONObject item = new JSONObject(); item.put("id", -1); item.put("name", "Phone speaker"); outputs.put(item);
            }
            out.put("ok", true);
            out.put("inputs", inputs);
            out.put("outputs", outputs);
            out.put("input_count", inputs.length());
            out.put("output_count", outputs.length());
            return out.toString();
        } catch (Exception e) {
            try {
                JSONObject out = new JSONObject();
                out.put("ok", false);
                out.put("error", "Android audio device detection failed: " + e.getMessage());
                return out.toString();
            } catch (Exception ignored) {
                return "{\"ok\":false,\"error\":\"Android audio device detection failed.\"}";
            }
        }
    }

    // ============================================================
    // FIND MY BOARD - native Android discovery
    // ============================================================
    //
    // Discovery order:
    //   1) UDP broadcast on the active WiFi network (fast + DHCP-proof)
    //   2) TCP /api/state probe across the actual IPv4 prefix
    //
    // The WebView only receives the final result through this bridge.
    private class AndroidScanBridge {

        private volatile boolean stopRequested = false;
        private volatile boolean scanRunning = false;

        @JavascriptInterface
        public synchronized void scanBoard() {
            if (scanRunning) {
                return;
            }
            stopRequested = false;
            scanRunning = true;

            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    String found = null;
                    try {
                        ensureWifiNetworkBinding();
                        found = performScan();
                    } finally {
                        scanRunning = false;
                    }

                    final String result = found;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web == null) return;
                            String arg = (result == null || result.length() == 0)
                                    ? "null"
                                    : "\"" + result.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
                            web.evaluateJavascript(
                                    "window.__androidScanResult && window.__androidScanResult(" + arg + ");",
                                    null
                            );
                        }
                    });
                }
            }, "SmartPlantAndroidDiscovery");

            t.setDaemon(true);
            t.start();
        }

        @JavascriptInterface
        public void stopScan() {
            stopRequested = true;
        }

        private String performScan() {
            // --------------------------------------------------------
            // FAST PATH: ESP32 UDP broadcast discovery
            // --------------------------------------------------------
            String boardFound = udpDiscover();
            if (boardFound != null) {
                return boardFound;
            }
            if (stopRequested) {
                return null;
            }

            // --------------------------------------------------------
            // FALLBACK: actual IPv4 prefix, then direct ESP32 /api/health probes
            // --------------------------------------------------------
            List<String> targets = buildTargets();
            ExecutorService pool = Executors.newFixedThreadPool(48);
            java.util.concurrent.ExecutorCompletionService<ScanResult> completion =
                    new java.util.concurrent.ExecutorCompletionService<>(pool);

            int submitted = 0;
            for (final String ip : targets) {
                if (stopRequested) break;
                completion.submit(new java.util.concurrent.Callable<ScanResult>() {
                    @Override
                    public ScanResult call() {
                        return new ScanResult(ip, probe(ip));
                    }
                });
                submitted++;
            }

            int checked = 0;
            reportScanProgress(0, Math.max(1, submitted), "TCP FALLBACK // probing local WiFi hosts", 0);

            try {
                final long deadline = System.currentTimeMillis() + 15000L;
                while (checked < submitted && !stopRequested
                        && System.currentTimeMillis() < deadline) {

                    Future<ScanResult> f = completion.poll(250L, TimeUnit.MILLISECONDS);
                    if (f == null) continue;

                    checked++;
                    try {
                        ScanResult r = f.get();
                        reportScanProgress(
                                checked, submitted, r.ip,
                                (checked * 100) / Math.max(1, submitted)
                        );
                        if (r.found != null) {
                            stopRequested = true;
                            return r.found;
                        }
                    } catch (Exception ignored) {
                        // Keep scanning other hosts.
                    }
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                pool.shutdownNow();
            }

            reportScanProgress(
                    checked,
                    Math.max(1, submitted),
                    stopRequested ? "Scan stopped" : "Discovery complete",
                    submitted == 0 ? 100 : (checked * 100) / Math.max(1, submitted)
            );
            return null;
        }

        private String udpDiscover() {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setBroadcast(true);
                socket.setReuseAddress(true);
                socket.setSoTimeout(300);

                bindDatagramToActiveNetwork(socket);

                byte[] payload = "SMARTPLANT_DISCOVER_V2".getBytes("UTF-8");
                List<String> broadcasts = broadcastAddresses();
                reportScanProgress(0, Math.max(1, broadcasts.size()), "UDP DISCOVERY // WiFi broadcast", 8);

                for (String bcast : broadcasts) {
                    if (stopRequested) return null;
                    try {
                        DatagramPacket packet = new DatagramPacket(
                                payload, payload.length,
                                InetAddress.getByName(bcast), 4210
                        );
                        socket.send(packet);
                    } catch (Exception ignored) {}
                }

                long deadline = System.currentTimeMillis() + 2200L;
                byte[] buf = new byte[1024];

                while (!stopRequested && System.currentTimeMillis() < deadline) {
                    try {
                        DatagramPacket reply = new DatagramPacket(buf, buf.length);
                        socket.receive(reply);
                        String body = new String(
                                reply.getData(), reply.getOffset(), reply.getLength(), "UTF-8"
                        ).trim();
                        String[] parts = body.split("\\|", -1);
                        String packetIp = null;
                        if (parts.length >= 4 && "SMARTPLANT_DISCOVER_V2".equals(parts[0])
                                && parts[1] != null && parts[1].length() > 0
                                && parts[2].toLowerCase().replace(" ", "").contains("smartplant")) {
                            packetIp = parts[1].trim();
                        }
                        String sourceIp = reply.getAddress().getHostAddress();
                        String candidate = packetIp != null ? packetIp : sourceIp;
                        if (packetIp != null && packetIp.equals(sourceIp) && probe(candidate) != null) {
                            reportScanProgress(1, 1, "UDP controller response: " + candidate, 100);
                            return candidate;
                        }
                        if (packetIp == null && probe(sourceIp) != null) {
                            reportScanProgress(1, 1, "Verified controller: " + sourceIp, 100);
                            return sourceIp;
                        }
                    } catch (SocketTimeoutException ignored) {
                        // Continue until deadline.
                    }
                }
            } catch (Exception ignored) {
                // TCP fallback below.
            } finally {
                if (socket != null) socket.close();
            }
            return null;
        }

        private void bindDatagramToActiveNetwork(DatagramSocket socket) {
            try {
                ConnectivityManager cm =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                if (cm == null) return;
                Network network = cm.getActiveNetwork();
                if (network != null) {
                    network.bindSocket(socket);
                }
            } catch (Exception ignored) {}
        }

        private List<String> broadcastAddresses() {
            List<String> out = new ArrayList<>();
            out.add("255.255.255.255");

            try {
                ConnectivityManager cm =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network active = cm == null ? null : cm.getActiveNetwork();
                if (cm != null && active != null) {
                    android.net.LinkProperties lp = cm.getLinkProperties(active);
                    if (lp != null) {
                        for (android.net.LinkAddress la : lp.getLinkAddresses()) {
                            if (!(la.getAddress() instanceof java.net.Inet4Address)) continue;
                            int prefix = la.getPrefixLength();
                            if (prefix < 1 || prefix > 30) continue;

                            byte[] addr = la.getAddress().getAddress();
                            int ip = ((addr[0] & 0xff) << 24)
                                    | ((addr[1] & 0xff) << 16)
                                    | ((addr[2] & 0xff) << 8)
                                    | (addr[3] & 0xff);
                            int mask = (int) (0xffffffffL << (32 - prefix));
                            int broadcast = (ip & mask) | ~mask;

                            String b = ((broadcast >>> 24) & 0xff) + "."
                                    + ((broadcast >>> 16) & 0xff) + "."
                                    + ((broadcast >>> 8) & 0xff) + "."
                                    + (broadcast & 0xff);
                            if (!out.contains(b)) out.add(b);
                        }
                    }
                }
            } catch (Exception ignored) {}

            return out;
        }

        private List<String> buildTargets() {
            List<String> targets = new ArrayList<>();

            // Friendly mDNS first; the active Wi-Fi subnet below is the
            // authoritative fallback. No old hard-coded IP is required.
            String[] fast = new String[] {
                    "smartplant.local"
            };
            for (String host : fast) {
                if (!targets.contains(host)) targets.add(host);
            }

            try {
                ConnectivityManager cm =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network active = cm == null ? null : cm.getActiveNetwork();
                if (cm != null && active != null) {
                    android.net.LinkProperties lp = cm.getLinkProperties(active);
                    if (lp != null) {
                        for (android.net.LinkAddress la : lp.getLinkAddresses()) {
                            if (!(la.getAddress() instanceof java.net.Inet4Address)) continue;

                            byte[] addr = la.getAddress().getAddress();
                            int ip = ((addr[0] & 0xff) << 24)
                                    | ((addr[1] & 0xff) << 16)
                                    | ((addr[2] & 0xff) << 8)
                                    | (addr[3] & 0xff);

                            int prefix = Math.max(1, Math.min(30, la.getPrefixLength()));
                            int mask = (int) (0xffffffffL << (32 - prefix));
                            int network = ip & mask;
                            int broadcast = network | ~mask;

                            long first = (network & 0xffffffffL) + 1L;
                            long last = (broadcast & 0xffffffffL) - 1L;

                            // Don't generate enormous scans on /16 or broader networks.
                            if (last - first + 1L > 1024L) {
                                int hostBits = 8;
                                int hostMask = (1 << hostBits) - 1;
                                network = ip & ~hostMask;
                                first = (network & 0xffffffffL) + 1L;
                                last = (network & 0xffffffffL) + 254L;
                            }

                            for (long n = first; n <= last && n <= 0xffffffffL; n++) {
                                String host = ((n >>> 24) & 0xff) + "."
                                        + ((n >>> 16) & 0xff) + "."
                                        + ((n >>> 8) & 0xff) + "."
                                        + (n & 0xff);
                                if (!targets.contains(host)) targets.add(host);
                            }
                        }
                    }
                }
            } catch (Exception ignored) {}

            return targets;
        }

        private void reportScanProgress(final int checked, final int total,
                                        final String target, final int pct) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (web == null) return;
                    String safeTarget = target == null
                            ? "Scanning LAN..."
                            : target.replace("\\", "\\\\").replace("\"", "\\\"");
                    String js = "window.__androidScanProgress && window.__androidScanProgress("
                            + checked + "," + total + ",\"" + safeTarget + "\"," + pct + ");";
                    try { web.evaluateJavascript(js, null); } catch (Exception ignored) {}
                }
            });
        }

        class ScanResult {
            final String ip;
            final String found;
            ScanResult(String ip, String found) {
                this.ip = ip;
                this.found = found;
            }
        }

        private String probe(String host) {
            HttpURLConnection conn = null;
            try {
                String safeHost = host == null ? "" : host.trim();
                if (safeHost.length() == 0) return null;
                URL url = new URL("http://" + safeHost + "/api/health");
                conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
                conn.setConnectTimeout(550);
                conn.setReadTimeout(750);
                conn.setUseCaches(false);
                conn.setRequestProperty("Accept", "application/json");
                if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) return null;

                InputStream in = conn.getInputStream();
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[512];
                int n, total = 0;
                while ((n = in.read(buf)) != -1 && total < 4096) {
                    bos.write(buf, 0, n);
                    total += n;
                }
                String body = bos.toString("UTF-8").toLowerCase(Locale.ROOT);
                if (body.contains("smart plant esp32") || body.contains("smartplant")) {
                    return "http://" + safeHost;
                }
            } catch (Exception ignored) {
                // Try the next LAN host.
            } finally {
                if (conn != null) conn.disconnect();
            }
            return null;
        }
    }}
