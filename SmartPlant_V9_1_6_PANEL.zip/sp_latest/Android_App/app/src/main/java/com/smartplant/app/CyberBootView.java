package com.smartplant.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/** Lightweight boot background. It never schedules work from onDraw(). */
public class CyberBootView extends View {
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float scan;
    private long lastFrame;
    private boolean animating;

    public CyberBootView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public CyberBootView(Context context) { super(context); init(); }

    private void init() {
        setWillNotDraw(false);
        grid.setColor(0x2230FF84);
        grid.setStrokeWidth(1f);
        grid.setStyle(Paint.Style.STROKE);
        glow.setColor(0x082CFF8A);
        glow.setStyle(Paint.Style.FILL);
        line.setColor(0x3030FF84);
        line.setStrokeWidth(2f);
        line.setStyle(Paint.Style.STROKE);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        animating = true;
        lastFrame = System.nanoTime();
        postInvalidateOnAnimation();
    }

    @Override protected void onDetachedFromWindow() {
        animating = false;
        super.onDetachedFromWindow();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final int width = getWidth();
        final int height = getHeight();
        canvas.drawColor(0xFF020609);

        for (int x = 0; x < width; x += 42) canvas.drawLine(x, 0, x, height, grid);
        for (int y = 0; y < height; y += 42) canvas.drawLine(0, y, width, y, grid);

        glow.setColor(0x082CFF8A);
        float top = Math.max(0f, scan - 42f);
        float bottom = Math.min(height, scan);
        if (bottom > top) canvas.drawRect(0, top, width, bottom, glow);

        line.setColor(0x3030FF84);
        path.reset();
        path.moveTo(0, height * 0.78f);
        path.lineTo(width * 0.22f, height * 0.70f);
        path.lineTo(width * 0.46f, height * 0.74f);
        path.lineTo(width * 0.70f, height * 0.63f);
        path.lineTo(width, height * 0.68f);
        canvas.drawPath(path, line);

        if (animating) {
            long now = System.nanoTime();
            float dt = (now - lastFrame) / 1_000_000f;
            lastFrame = now;
            scan += dt * 0.08f;
            if (scan > height + 42f) scan = 0f;
            postInvalidateOnAnimation();
        }
    }
}
