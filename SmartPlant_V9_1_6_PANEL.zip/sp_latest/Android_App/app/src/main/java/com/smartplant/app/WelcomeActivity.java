package com.smartplant.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private static final long WELCOME_DELAY_MS = 2500L;

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private boolean opening = false;

    private final Runnable openDashboard =
            new Runnable() {

        @Override
        public void run() {

            if (opening ||
                    isFinishing() ||
                    isDestroyed()) {
                return;
            }

            opening = true;

            Intent intent =
                    new Intent(
                            WelcomeActivity.this,
                            MainActivity.class
                    );

            startActivity(intent);

            finish();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_welcome
        );

        handler.postDelayed(
                openDashboard,
                WELCOME_DELAY_MS
        );
    }


    @Override
    protected void onDestroy() {

        handler.removeCallbacks(
                openDashboard
        );

        super.onDestroy();
    }
}