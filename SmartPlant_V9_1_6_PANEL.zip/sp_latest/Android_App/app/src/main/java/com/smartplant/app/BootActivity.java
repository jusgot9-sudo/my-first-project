package com.smartplant.app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class BootActivity extends AppCompatActivity {

    private static final int STEP_DELAY = 35;
    private static final int WELCOME_DELAY = 700;

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private ProgressBar progressBar;
    private TextView percentText;
    private TextView statusText;

    private int progress = 0;
    private boolean opening = false;

    private final Runnable bootTick = new Runnable() {

        @Override
        public void run() {

            if (isFinishing() || isDestroyed()) {
                return;
            }

            progress++;

            if (progressBar != null) {
                progressBar.setProgress(progress);
            }

            if (percentText != null) {
                percentText.setText(
                        String.format(
                                Locale.US,
                                "%03d%%",
                                progress
                        )
                );
            }

            if (statusText != null) {

                if (progress < 25) {
                    statusText.setText("INITIALIZING CORE...");
                }
                else if (progress < 45) {
                    statusText.setText("LOADING SENSOR INTERFACE...");
                }
                else if (progress < 65) {
                    statusText.setText("LOADING CONTROLLER LINK...");
                }
                else if (progress < 85) {
                    statusText.setText("LOADING DASHBOARD UI...");
                }
                else if (progress < 100) {
                    statusText.setText("VERIFYING SYSTEM...");
                }
                else {
                    statusText.setText(
                            "SYSTEM READY // OPENING WELCOME"
                    );
                }
            }

            if (progress < 100) {

                handler.postDelayed(
                        this,
                        STEP_DELAY
                );

            }
            else {

                handler.postDelayed(
                        openWelcome,
                        WELCOME_DELAY
                );
            }
        }
    };


    private final Runnable openWelcome = new Runnable() {

        @Override
        public void run() {

            if (opening ||
                    isFinishing() ||
                    isDestroyed()) {
                return;
            }

            opening = true;

            Intent intent =
                    new Intent(
                            BootActivity.this,
                            WelcomeActivity.class
                    );

            startActivity(intent);

            finish();
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_boot
        );

        progressBar =
                findViewById(R.id.bootProgress);

        percentText =
                findViewById(R.id.bootPercent);

        statusText =
                findViewById(R.id.bootStatus);

        progress = 0;

        if (progressBar != null) {
            progressBar.setProgress(0);
        }

        if (percentText != null) {
            percentText.setText("000%");
        }

        if (statusText != null) {
            statusText.setText("INITIALIZING CORE...");
        }

        handler.postDelayed(
                bootTick,
                150
        );
    }


    @Override
    protected void onDestroy() {

        handler.removeCallbacks(bootTick);
        handler.removeCallbacks(openWelcome);

        super.onDestroy();
    }
}