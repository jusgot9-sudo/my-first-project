# Smart Plant V33 Network Architecture

## Required network path

```text
Phone -> Same Wi-Fi -> ESP32
PC    -> Same Wi-Fi -> ESP32
                         |
                         +--> UART2 --> Arduino UNO D7 relay
```

The ESP32 listens for UDP discovery on port 4210 and serves its HTTP API on port 80. The PC Flask process is not a required network middleman for the phone. Android uses native UDP discovery and TCP `/api/state` probes on the active Wi-Fi network. PC uses UDP discovery and TCP fallback on the local LAN.

## Sensor data policy

The ESP32 reports only actual sensor readings. A missing/invalid reading is JSON `null`, which the UI renders as `--`. No synthetic values are generated.
