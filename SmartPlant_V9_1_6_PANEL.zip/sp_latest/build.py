"""Smart Plant Windows build pipeline.

Windows usage:
  python build.py pc      -> PC EXE only
  python build.py setup   -> Setup.exe from an existing PC EXE
  python build.py all     -> PC EXE then Setup.exe then SHA256 manifest

All project paths are derived from this file, so the build is independent of
where the terminal was opened.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PC = ROOT / "PC_App"
INSTALLER = ROOT / "Installer"
OUT = ROOT / "Setup_Output"
APP_EXE = PC / "dist" / "SmartPlantIrrigationSystem.exe"
SETUP_EXE = OUT / "SmartPlantIrrigationSystem_Setup.exe"
VERSION_FILE = ROOT / "VERSION.txt"


def version() -> str:
    if not VERSION_FILE.is_file():
        raise RuntimeError(f"Missing required file: {VERSION_FILE}")
    return VERSION_FILE.read_text(encoding="utf-8").strip().lstrip("Vv")


def run(cmd: list[object], cwd: Path | None = None) -> None:
    rendered = " ".join(str(x) for x in cmd)
    print(f"> {rendered}", flush=True)
    subprocess.run([str(x) for x in cmd], cwd=str(cwd or ROOT), check=True)


def require_file(path: Path) -> None:
    if not path.is_file():
        raise RuntimeError(f"Missing required file: {path.relative_to(ROOT)}")


def require_dir(path: Path) -> None:
    if not path.is_dir():
        raise RuntimeError(f"Missing required directory: {path.relative_to(ROOT)}")


def validate_layout() -> None:
    for p in (
        VERSION_FILE,
        PC / "launcher.py",
        PC / "app.py",
        PC / "local_voice_engine.py",
        PC / "SmartPlantIrrigationSystem.spec",
        PC / "app_icon.ico",
        ROOT / "setup_assets" / "app_icon.ico",
        ROOT / "setup_assets" / "AGREEMENT.txt",
        INSTALLER / "installer.py",
        INSTALLER / "ui" / "index.html",
        INSTALLER / "ui" / "css" / "style.css",
        INSTALLER / "ui" / "js" / "main.js",
        INSTALLER / "ui" / "img" / "logo.png",
    ):
        require_file(p)
    for p in (PC / "templates", PC / "static"):
        require_dir(p)


def install_requirements() -> None:
    run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--upgrade", "pip"])
    run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", PC / "requirements.txt", "pyinstaller"])


def smoke_test_pc_runtime() -> None:
    code = (
        "import flask, webview, sounddevice, gtts, groq, pygame, pyttsx3, pystray; "
        "from PIL import Image; import local_voice_engine"
    )
    run([sys.executable, "-c", code], cwd=PC)
    print("PC runtime dependency smoke test: PASS", flush=True)


def build_pc() -> Path:
    validate_layout()
    install_requirements()
    smoke_test_pc_runtime()

    shutil.rmtree(PC / "build", ignore_errors=True)
    shutil.rmtree(PC / "dist", ignore_errors=True)

    run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--clean",
            str(PC / "SmartPlantIrrigationSystem.spec"),
        ],
        cwd=PC,
    )

    require_file(APP_EXE)
    print(f"PC EXE PASS: {APP_EXE}", flush=True)
    return APP_EXE


APK_CANDIDATES = [
    ROOT / "Android_App" / "app" / "build" / "outputs" / "apk" / "debug" / "SmartPlantAndroid.apk",
    ROOT / "Android_App" / "app" / "build" / "outputs" / "apk" / "SmartPlantAndroid.apk",
    ROOT / "Android_App" / "app" / "build" / "outputs" / "apk" / "release" / "app-release.apk",
    ROOT / "Android_App" / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk",
]


def find_apk() -> Path | None:
    return next((p for p in APK_CANDIDATES if p.is_file()), None)


def build_installer() -> Path:
    validate_layout()
    require_file(APP_EXE)

    payload = INSTALLER / "payload"
    shutil.rmtree(payload, ignore_errors=True)
    payload.mkdir(parents=True, exist_ok=True)
    shutil.copy2(APP_EXE, payload / APP_EXE.name)
    shutil.copy2(PC / "app_icon.ico", payload / "app_icon.ico")

    apk = find_apk()
    if apk:
        shutil.copy2(apk, payload / "SmartPlantAndroid.apk")
        print(f"APK payload PASS: {apk}", flush=True)
    else:
        print("APK payload SKIPPED: no APK found (run Android_App\\BUILD_ANDROID_APK.bat first if you want it inside Setup.exe)", flush=True)

    (INSTALLER / "VERSION.txt").write_text(version() + "\n", encoding="utf-8")
    shutil.copy2(ROOT / "setup_assets" / "AGREEMENT.txt", INSTALLER / "ui" / "AGREEMENT.txt")

    shutil.rmtree(INSTALLER / "build", ignore_errors=True)
    shutil.rmtree(OUT, ignore_errors=True)
    OUT.mkdir(parents=True, exist_ok=True)

    sep = os.pathsep
    run(
        [
            sys.executable,
            "-m",
            "PyInstaller",
            "--noconfirm",
            "--clean",
            "--onefile",
            "--windowed",
            "--uac-admin",
            "--name",
            "SmartPlantIrrigationSystem_Setup",
            "--icon",
            ROOT / "setup_assets" / "app_icon.ico",
            "--add-data",
            f"{INSTALLER / 'ui'}{sep}ui",
            "--add-data",
            f"{payload}{sep}payload",
            "--add-data",
            f"{INSTALLER / 'VERSION.txt'}{sep}.",
            "--collect-all",
            "webview",
            "--collect-all",
            "clr_loader",
            "--collect-all",
            "pythonnet",
            "--hidden-import",
            "clr",
            "--distpath",
            OUT,
            "--workpath",
            INSTALLER / "build",
            "--specpath",
            INSTALLER / "build",
            str(INSTALLER / "installer.py"),
        ],
        cwd=INSTALLER,
    )

    shutil.rmtree(payload, ignore_errors=True)
    require_file(SETUP_EXE)
    print(f"SETUP EXE PASS: {SETUP_EXE}", flush=True)
    return SETUP_EXE


def write_release_hashes() -> Path:
    require_file(APP_EXE)
    require_file(SETUP_EXE)

    release_app = OUT / APP_EXE.name
    shutil.copy2(APP_EXE, release_app)

    artifacts = [release_app, SETUP_EXE]
    apk = find_apk()
    if apk:
        release_apk = OUT / "SmartPlantAndroid.apk"
        shutil.copy2(apk, release_apk)
        artifacts.append(release_apk)

    manifest = OUT / "SHA256SUMS.txt"
    manifest.write_text(
        "\n".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}" for p in artifacts) + "\n",
        encoding="utf-8",
    )
    print(f"SHA256 PASS: {manifest}", flush=True)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["pc", "setup", "all"], default="all", nargs="?")
    args = parser.parse_args()

    print(f"SMART PLANT WINDOWS BUILD V{version()} - mode={args.mode}", flush=True)
    try:
        validate_layout()
        if args.mode in ("pc", "all"):
            build_pc()
        if args.mode in ("setup", "all"):
            build_installer()
        if args.mode == "all":
            write_release_hashes()
        print("BUILD_DONE", flush=True)
        return 0
    except subprocess.CalledProcessError as exc:
        print(f"BUILD_COMMAND_FAILED rc={exc.returncode}", flush=True)
        return int(exc.returncode or 1)
    except Exception as exc:
        print(f"BUILD_ERROR: {exc}", flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
