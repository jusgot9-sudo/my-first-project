/* Smart Plant custom installer UI.  Python (installer.py) exposes window.pywebview.api.* */
var MODE = "install";           // "install" | "uninstall"
var LANG = "en";
var STEPS = ["welcome", "license", "options", "install", "done"];
var cur = "welcome";
var busy = false;
var info = {};

var T = {
  en: {
    title: "Smart Plant Setup", stWelcome: "Welcome", stLicense: "Agreement", stOptions: "Options", stInstall: "Installing", stDone: "Finish",
    wTitle: "Welcome", wText: "This wizard will install the Smart Plant Irrigation System on your computer. It controls your pump, watches your soil, and talks to you in Sinhala and English.",
    f1: "🌱 Live soil, temperature and water-tank monitoring", f2: "🎙️ AI voice assistant (Sinhala / English)", f3: "📱 Works with the Android app on your Wi-Fi",
    upgradeNote: "An existing installation was found. It will be updated and your data is kept.",
    lTitle: "Agreement", lAgree: "I have read and accept the agreement",
    oTitle: "Install options", oFolder: "Install folder", oBrowse: "Browse…", oDesktop: "Create a Desktop shortcut", oMenu: "Add to the Start menu",
    oFw: "Allow phone / ESP32 on my home network (firewall)", oLaunch: "Start Smart Plant when finished",
    iTitle: "Installing…", dTitle: "All done!", dText: "Smart Plant Irrigation System was installed successfully.",
    back: "Back", next: "Next", install: "Install", finish: "Finish", cancel: "Cancel", retry: "Close",
    uTitle: "Uninstall Smart Plant", uText: "This will remove Smart Plant Irrigation System from your computer.", uData: "Also delete my settings, history and AI memory",
    uninstall: "Uninstall", uDone: "Smart Plant was removed.", failTitle: "Something went wrong", confirmClose: "Setup is not finished. Exit anyway?",
    version: "Version ", space: "Needs about {mb} MB of free space."
  },
  si: {
    title: "Smart Plant ස්ථාපනය", stWelcome: "සාදරයෙන් පිළිගනිමු", stLicense: "ගිවිසුම", stOptions: "තේරීම්", stInstall: "ස්ථාපනය වෙමින්", stDone: "අවසන්",
    wTitle: "සාදරයෙන් පිළිගනිමු", wText: "මේ විශාරදයා ඔයාගේ පරිගණකයට Smart Plant ජල සම්පාදන පද්ධතිය ස්ථාපනය කරනවා. පොම්පය පාලනය කරනවා, පස නිරීක්ෂණය කරනවා, සිංහලෙන් සහ ඉංග්‍රීසියෙන් කතා කරනවා.",
    f1: "🌱 පසේ තෙතමනය, උෂ්ණත්වය, ටැංකියේ වතුර සජීවීව බලන්න", f2: "🎙️ AI හඬ සහායකයා (සිංහල / English)", f3: "📱 Wi-Fi හරහා Android app එකත් එක්ක වැඩ කරනවා",
    upgradeNote: "කලින් ස්ථාපනයක් හමු වුණා. එය update වෙනවා, ඔයාගේ දත්ත ආරක්ෂිතයි.",
    lTitle: "ගිවිසුම", lAgree: "මම ගිවිසුම කියවා පිළිගන්නවා",
    oTitle: "ස්ථාපන තේරීම්", oFolder: "ස්ථාපන ෆෝල්ඩරය", oBrowse: "තෝරන්න…", oDesktop: "Desktop shortcut එකක් හදන්න", oMenu: "Start menu එකට එකතු කරන්න",
    oFw: "ෆෝන් / ESP32 වලට Wi-Fi හරහා ප්‍රවේශය දෙන්න (firewall)", oLaunch: "අවසන් වුණාම Smart Plant ආරම්භ කරන්න",
    iTitle: "ස්ථාපනය වෙමින්…", dTitle: "සාර්ථකයි!", dText: "Smart Plant ජල සම්පාදන පද්ධතිය සාර්ථකව ස්ථාපනය වුණා.",
    back: "ආපසු", next: "ඊළඟ", install: "ස්ථාපනය", finish: "අවසන්", cancel: "අවලංගු", retry: "වසන්න",
    uTitle: "Smart Plant ඉවත් කරන්න", uText: "මේකෙන් Smart Plant ජල සම්පාදන පද්ධතිය ඔයාගේ පරිගණකයෙන් ඉවත් වෙනවා.", uData: "මගේ settings, history සහ AI මතකයත් මකන්න",
    uninstall: "ඉවත් කරන්න", uDone: "Smart Plant ඉවත් කළා.", failTitle: "දෙයක් වැරදුණා", confirmClose: "ස්ථාපනය අවසන් නැහැ. ඉවත් වෙනවාද?",
    version: "අනුවාදය ", space: "ආසන්න වශයෙන් MB {mb}ක් හිස් ඉඩ ඕන."
  }
};

function $(id) { return document.getElementById(id); }
function t(k) { return (T[LANG] && T[LANG][k]) || T.en[k] || k; }
function api(name) {
  var a = window.pywebview && window.pywebview.api;
  if (!a || !a[name]) return Promise.resolve(null);
  return a[name].apply(a, Array.prototype.slice.call(arguments, 1));
}

function applyLang() {
  document.documentElement.lang = LANG;
  document.querySelectorAll("[data-t]").forEach(function (el) { el.textContent = t(el.getAttribute("data-t")); });
  $("tTitle").textContent = t("title");
  $("langBtn").textContent = LANG === "en" ? "සිං" : "EN";
  $("verLabel").textContent = t("version") + (info.version || "");
  if (info.space_mb) $("space").textContent = t("space").replace("{mb}", info.space_mb);
  syncButtons();
}
function toggleLang() { LANG = LANG === "en" ? "si" : "en"; applyLang(); }

function show(step) {
  cur = step;
  document.querySelectorAll(".page").forEach(function (p) { p.hidden = (p.id !== "p-" + step); });
  var idx = STEPS.indexOf(step);
  document.querySelectorAll("#steps li").forEach(function (li) {
    var i = STEPS.indexOf(li.getAttribute("data-step"));
    li.className = i < idx ? "done" : (i === idx ? "active" : "");
  });
  syncButtons();
}

function syncButtons() {
  var back = $("btnBack"), next = $("btnNext");
  back.style.display = "";
  next.disabled = false;
  next.textContent = t("next");
  if (MODE === "uninstall") {
    $("steps").style.visibility = "hidden";
    if (cur === "uninstall") { back.textContent = t("cancel"); next.textContent = t("uninstall"); }
    else if (cur === "install") { back.style.display = "none"; next.disabled = true; }
    else if (cur === "done") { back.style.display = "none"; next.textContent = t("finish"); }
    return;
  }
  back.textContent = t("back");
  if (cur === "welcome") { back.textContent = t("cancel"); }
  if (cur === "license") { next.disabled = !$("agree").checked; }
  if (cur === "options") { next.textContent = t("install"); }
  if (cur === "install") { back.style.display = "none"; next.disabled = true; }
  if (cur === "done") { back.style.display = "none"; next.textContent = t("finish"); }
}

function back() {
  if (busy) return;
  if (cur === "welcome" || (MODE === "uninstall" && cur === "uninstall")) return closeApp(true);
  if (cur === "license") show("welcome");
  else if (cur === "options") show("license");
}

function next() {
  if (busy) return;
  if (MODE === "uninstall") {
    if (cur === "uninstall") return startUninstall();
    if (cur === "done") return api("quit");
    return;
  }
  if (cur === "welcome") show("license");
  else if (cur === "license") { if ($("agree").checked) show("options"); }
  else if (cur === "options") startInstall();
  else if (cur === "done") finish();
}

function browse() {
  api("choose_folder", $("dir").value).then(function (p) { if (p) $("dir").value = p; });
}

function closeApp(force) {
  if (cur === "install" && busy) return;
  if (cur === "done" || force === true || confirm(t("confirmClose"))) api("quit");
}

/* ---- called from Python while installing ---- */
function setProgress(pct, text) {
  pct = Math.max(0, Math.min(100, pct));
  $("fill").style.width = pct + "%";
  $("pct").textContent = Math.round(pct) + "%";
  if (text) $("iStatus").textContent = text;
}
function addLog(line) {
  var l = $("log"); l.textContent += line + "\n"; l.scrollTop = l.scrollHeight;
}

function startInstall() {
  busy = true;
  show("install");
  var opts = {
    dir: $("dir").value.trim(),
    desktop: $("optDesktop").checked, menu: $("optMenu").checked,
    firewall: $("optFw").checked, launch: $("optLaunch").checked
  };
  api("install", opts).then(function (r) { installFinished(r || { ok: false, error: "No response from installer." }); });
}
function installFinished(r) {
  busy = false;
  show("done");
  var tick = $("tick");
  if (r.ok) {
    tick.className = "tick"; tick.textContent = "✓";
    $("dTitle").textContent = t("dTitle"); $("dText").textContent = t("dText");
    $("dPath").textContent = r.dir || "";
  } else {
    tick.className = "tick err"; tick.textContent = "!";
    $("dTitle").textContent = t("failTitle"); $("dText").textContent = r.error || "Unknown error";
    $("dPath").textContent = "";
  }
}
function finish() { api("finish", { launch: $("optLaunch").checked }); }

function startUninstall() {
  busy = true; show("install");
  $("iStatus").textContent = "…";
  api("uninstall", { delete_data: $("optData").checked }).then(function (r) {
    busy = false; show("done");
    var tick = $("tick");
    if (r && r.ok) { tick.className = "tick"; tick.textContent = "✓"; $("dTitle").textContent = t("uDone"); $("dText").textContent = ""; }
    else { tick.className = "tick err"; tick.textContent = "!"; $("dTitle").textContent = t("failTitle"); $("dText").textContent = (r && r.error) || ""; }
  });
}

function boot() {
  api("get_info").then(function (d) {
    info = d || {};
    MODE = info.mode || "install";
    if (info.lang) LANG = info.lang;
    $("dir").value = info.default_dir || "";
    $("upgradeNote").hidden = !info.upgrade;
    if (info.upgrade) { $("optDesktop").checked = !!info.had_desktop; }
    api("get_license").then(function (txt) { $("licenseText").textContent = txt || ""; });
    applyLang();
    show(MODE === "uninstall" ? "uninstall" : "welcome");
  });
}
window.addEventListener("pywebviewready", boot);
// Plain-browser preview (no Python): show the first page.
setTimeout(function () { if (!window.pywebview) { info = { version: "9.0.0", default_dir: "C:\\Program Files\\Smart Plant Irrigation System", space_mb: 120 }; applyLang(); show(location.hash === "#options" ? "options" : (location.hash === "#install" ? "install" : "welcome")); if (location.hash === "#install") setProgress(62, "Copying files…"); } }, 600);
