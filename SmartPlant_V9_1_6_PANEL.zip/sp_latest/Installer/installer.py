"""Smart Plant custom installer (HTML/CSS/JS UI in a native window).

    SmartPlantIrrigationSystem_Setup.exe            -> graphical installer
    ... /SILENT (or /VERYSILENT, --silent)           -> no UI (used by in-app auto-update)
    Uninstall.exe  (this same program, --uninstall) -> graphical uninstaller

Built by build.py with PyInstaller (--uac-admin). Payload lives in <bundle>/payload.
"""
import ctypes
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

APP_NAME = "Smart Plant Irrigation System"
EXE_NAME = "SmartPlantIrrigationSystem.exe"
UNINSTALL_NAME = "Uninstall.exe"
REG_UNINSTALL = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\SmartPlantIrrigationSystem"
REG_APP = r"SOFTWARE\SmartPlant"
FW_RULES = [("Smart Plant TCP 5000", "TCP", "5000"), ("Smart Plant UDP 4210", "UDP", "4210"), ("Smart Plant UDP 4211", "UDP", "4211")]
IS_WIN = sys.platform == "win32"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

BUNDLE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
UI_DIR = BUNDLE / "ui"
PAYLOAD = BUNDLE / "payload"
if not PAYLOAD.exists():                      # running from source tree
    PAYLOAD = Path(__file__).resolve().parent.parent / "PC_App" / "dist"


def read_version():
    for p in (BUNDLE / "VERSION.txt", Path(__file__).resolve().parent.parent / "VERSION.txt"):
        try:
            return p.read_text(encoding="utf-8").strip().lstrip("vV")
        except OSError:
            pass
    return "9.0.0"


def default_dir():
    base = os.environ.get("ProgramFiles", r"C:\Program Files") if IS_WIN else str(Path.home() / "SmartPlant")
    return str(Path(base) / APP_NAME)


# ---------------------------------------------------------------- windows helpers
def _reg_get(key, name, hive=None):
    if not IS_WIN:
        return None
    import winreg
    try:
        with winreg.OpenKey(hive or winreg.HKEY_LOCAL_MACHINE, key) as k:
            return winreg.QueryValueEx(k, name)[0]
    except OSError:
        return None


def installed_dir():
    return _reg_get(REG_APP, "InstallDir")


def _run(cmd, **kw):
    try:
        return subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW, **kw)
    except Exception:
        return None


def kill_app():
    if IS_WIN:
        _run(["taskkill", "/F", "/IM", EXE_NAME])
        time.sleep(0.8)


def desktop_dir():
    return Path(os.environ.get("PUBLIC", r"C:\Users\Public")) / "Desktop"


def startmenu_dir():
    return Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def make_shortcut(lnk, target, workdir, icon):
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut('%s');$s.TargetPath='%s';"
          "$s.WorkingDirectory='%s';$s.IconLocation='%s';$s.Save()") % (lnk, target, workdir, icon)
    _run(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps])


def firewall_add():
    for name, proto, port in FW_RULES:
        _run(["netsh", "advfirewall", "firewall", "delete", "rule", "name=" + name])
        _run(["netsh", "advfirewall", "firewall", "add", "rule", "name=" + name, "dir=in", "action=allow",
              "protocol=" + proto, "localport=" + port, "profile=domain,private"])


def firewall_remove():
    for name, _p, _port in FW_RULES:
        _run(["netsh", "advfirewall", "firewall", "delete", "rule", "name=" + name])


def dir_size_mb(path):
    total = 0
    for dp, _dn, fn in os.walk(path):
        for f in fn:
            try:
                total += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    return max(1, total // (1024 * 1024))


# ---------------------------------------------------------------- core install (testable)
def install_core(target, opts, progress, version, self_exe=None):
    """Copy files and register the app. progress(pct, text) is called along the way."""
    target = Path(target)
    log = lambda m: progress(None, None, m)
    progress(3, "Closing running copy…", None)
    kill_app()
    progress(8, "Creating folder…", None)
    target.mkdir(parents=True, exist_ok=True)

    files = [p for p in PAYLOAD.iterdir() if p.is_file()] if PAYLOAD.exists() else []
    if not any(p.name == EXE_NAME for p in files):
        raise RuntimeError("Installer payload is missing %s." % EXE_NAME)
    n = len(files)
    for i, src in enumerate(files):
        progress(10 + 55 * (i + 1) / max(1, n), "Copying %s…" % src.name, None)
        dst = target / src.name
        for attempt in range(5):               # exe may still be released by Windows
            try:
                shutil.copy2(src, dst)
                break
            except PermissionError:
                if attempt == 4:
                    raise
                kill_app(); time.sleep(0.6)
        log("copied " + src.name)

    progress(68, "Creating uninstaller…", None)
    if self_exe and Path(self_exe).exists():
        shutil.copy2(self_exe, target / UNINSTALL_NAME)
        log("created " + UNINSTALL_NAME)

    exe = target / EXE_NAME
    icon = target / "app_icon.ico"
    if IS_WIN:
        progress(75, "Creating shortcuts…", None)
        if opts.get("menu", True):
            folder = startmenu_dir() / APP_NAME
            folder.mkdir(parents=True, exist_ok=True)
            make_shortcut(str(folder / (APP_NAME + ".lnk")), str(exe), str(target), str(icon))
            make_shortcut(str(folder / ("Uninstall " + APP_NAME + ".lnk")), str(target / UNINSTALL_NAME), str(target), str(icon))
        if opts.get("desktop", True):
            make_shortcut(str(desktop_dir() / (APP_NAME + ".lnk")), str(exe), str(target), str(icon))
        if opts.get("firewall", True):
            progress(85, "Opening network access for phone / ESP32…", None)
            firewall_add()
        progress(92, "Registering with Windows…", None)
        import winreg
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, REG_UNINSTALL, 0, winreg.KEY_WRITE) as k:
            winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, APP_NAME)
            winreg.SetValueEx(k, "DisplayVersion", 0, winreg.REG_SZ, version)
            winreg.SetValueEx(k, "Publisher", 0, winreg.REG_SZ, "Tharusha")
            winreg.SetValueEx(k, "InstallLocation", 0, winreg.REG_SZ, str(target))
            winreg.SetValueEx(k, "DisplayIcon", 0, winreg.REG_SZ, str(icon))
            winreg.SetValueEx(k, "UninstallString", 0, winreg.REG_SZ, '"%s" --uninstall' % (target / UNINSTALL_NAME))
            winreg.SetValueEx(k, "EstimatedSize", 0, winreg.REG_DWORD, dir_size_mb(target) * 1024)
            winreg.SetValueEx(k, "NoModify", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(k, "NoRepair", 0, winreg.REG_DWORD, 1)
        with winreg.CreateKeyEx(winreg.HKEY_LOCAL_MACHINE, REG_APP, 0, winreg.KEY_WRITE) as k:
            winreg.SetValueEx(k, "InstallDir", 0, winreg.REG_SZ, str(target))
    progress(100, "Done", None)
    return str(target)


def uninstall_core(delete_data, progress):
    target = Path(installed_dir() or Path(sys.executable).parent)
    progress(10, "Closing the app…", None)
    kill_app()
    if IS_WIN:
        progress(30, "Removing shortcuts…", None)
        shutil.rmtree(startmenu_dir() / APP_NAME, ignore_errors=True)
        try:
            (desktop_dir() / (APP_NAME + ".lnk")).unlink()
        except OSError:
            pass
        progress(50, "Closing network access…", None)
        firewall_remove()
        progress(65, "Removing registry entries…", None)
        import winreg
        for key in (REG_UNINSTALL, REG_APP):
            try:
                winreg.DeleteKey(winreg.HKEY_LOCAL_MACHINE, key)
            except OSError:
                pass
    if delete_data:
        progress(75, "Deleting your data…", None)
        data = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "Smart Plant System"
        shutil.rmtree(data, ignore_errors=True)
    progress(85, "Removing files…", None)
    for p in list(target.iterdir()) if target.exists() else []:
        if p.name.lower() == UNINSTALL_NAME.lower():
            continue
        try:
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        except OSError:
            pass
    # The running uninstaller cannot delete itself: let a detached shell do it after we exit.
    if IS_WIN:
        subprocess.Popen('cmd /c ping 127.0.0.1 -n 3 >nul & rmdir /s /q "%s"' % target, shell=True,
                         creationflags=NO_WINDOW | getattr(subprocess, "DETACHED_PROCESS", 0))
    progress(100, "Done", None)


# ---------------------------------------------------------------- GUI bridge
class Api:
    def __init__(self, mode):
        self.mode = mode
        self.window = None
        self.version = read_version()

    # --- helpers
    def _js(self, code):
        try:
            self.window.evaluate_js(code)
        except Exception:
            pass

    def _progress(self, pct, text, line):
        import json
        if pct is not None:
            self._js("setProgress(%s,%s)" % (float(pct), json.dumps(text or "")))
        if line:
            self._js("addLog(%s)" % json.dumps(line))

    # --- exposed to JS
    def get_info(self):
        prev = installed_dir() if IS_WIN else None
        had_desktop = bool(IS_WIN and (desktop_dir() / (APP_NAME + ".lnk")).exists())
        lang = "en"
        try:
            if IS_WIN and ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0x3FF == 0x5B:   # Sinhala
                lang = "si"
        except Exception:
            pass
        mb = dir_size_mb(PAYLOAD) + 5 if PAYLOAD.exists() else 120
        return {"mode": self.mode, "version": self.version, "default_dir": prev or default_dir(),
                "upgrade": bool(prev), "had_desktop": had_desktop, "space_mb": mb, "lang": lang}

    def get_license(self):
        try:
            return (UI_DIR / "AGREEMENT.txt").read_text(encoding="utf-8")
        except OSError:
            return ""

    def choose_folder(self, start=""):
        try:
            import webview
            res = self.window.create_file_dialog(webview.FOLDER_DIALOG, directory=start or "")
            if res:
                p = Path(res[0] if isinstance(res, (list, tuple)) else res)
                return str(p if p.name.lower() == APP_NAME.lower() else p / APP_NAME)
        except Exception:
            pass
        return None

    def install(self, opts):
        try:
            target = (opts.get("dir") or default_dir()).strip()
            if not target or len(target) < 4:
                raise RuntimeError("Please choose an install folder.")
            self._opts = opts
            path = install_core(target, opts, self._progress, self.version, self_exe=sys.executable if getattr(sys, "frozen", False) else None)
            self._target = path
            return {"ok": True, "dir": path}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    def finish(self, opts):
        if opts and opts.get("launch") and getattr(self, "_target", None):
            launch(self._target)
        self.quit()

    def uninstall(self, opts):
        try:
            uninstall_core(bool(opts.get("delete_data")), self._progress)
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:400]}

    def minimize(self):
        self.window.minimize()

    def quit(self):
        try:
            self.window.destroy()
        except Exception:
            os._exit(0)


def launch(target):
    exe = Path(target) / EXE_NAME
    if exe.exists():
        subprocess.Popen([str(exe)], cwd=str(target), creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))


def silent_install():
    """Used by the in-app updater: no window, keep previous folder, relaunch the app."""
    target = installed_dir() or default_dir()
    had_desktop = bool(IS_WIN and (desktop_dir() / (APP_NAME + ".lnk")).exists())
    try:
        install_core(target, {"desktop": had_desktop, "menu": True, "firewall": True}, lambda *a: None, read_version(),
                     self_exe=sys.executable if getattr(sys, "frozen", False) else None)
        launch(target)
        return 0
    except Exception as exc:
        try:
            ctypes.windll.user32.MessageBoxW(0, "Update failed: %s" % exc, APP_NAME, 0x10)
        except Exception:
            print("Update failed:", exc)
        return 1


def main():
    args = [a.lower() for a in sys.argv[1:]]
    if any(a in ("/silent", "/verysilent", "--silent") for a in args):
        sys.exit(silent_install())
    mode = "uninstall" if "--uninstall" in args or Path(sys.executable).name.lower() == UNINSTALL_NAME.lower() else "install"
    import webview
    api = Api(mode)
    window = webview.create_window("Smart Plant Setup", str(UI_DIR / "index.html"), js_api=api, width=860, height=540,
                                   resizable=False, frameless=True, easy_drag=False, background_color="#05080d")
    api.window = window
    webview.start(debug=False)


if __name__ == "__main__":
    main()
