# Smart Plant - Local Voice AI

මෙය Gemini / Groq API key එකක් නොගෙන වැඩ කරන්න හදපු local-first voice pipeline එකක්.

## දාමය

Microphone -> Local Whisper STT -> භාෂා/උපභාෂා හඳුනාගැනීම -> Local Ollama LLM -> Local TTS

PC එකේ `PC_App/INSTALL_LOCAL_VOICE_AI.bat` එක run කරලා dependencies install කරන්න. Ollama install කරලා `qwen2.5:7b` වගේ local model එකක් pull කරන්න.

### Sinhala STT
`SMARTPLANT_WHISPER_MODEL` environment variable එකෙන් Whisper model එක තෝරාගන්න පුළුවන්. සැබෑ Sinhala fine-tuned model එකක් භාවිතා කරන්න ඕන නම් ඒ model එකට මේ pipeline එක සම්බන්ධ කළ හැක. මේ release එකේ custom Sinhala fine-tuning weights ඇතුළත් නොවන නිසා ඒක fine-tuned Sinhala model එකක් බව කියන්නේ නැහැ.

### Dialect detector
දැනට transparent custom lexicon classifier එකක් තියෙනවා. `local_voice_engine.py` හි `DIALECT_LEXICON` එකට වචන එකතු කරලා Colombo / Kandy / Southern වගේ labels customize කරන්න පුළුවන්.

### LLM
Ollama local HTTP API භාවිතා කරන නිසා Gemini, Groq, Claude API key එකක් මේ local mode එකට අවශ්‍ය නැහැ.

`SMARTPLANT_OLLAMA_MODEL` සහ `SMARTPLANT_OLLAMA_URL` මගින් model/server එක වෙනස් කළ හැක.

### TTS
PC local TTS එකට `pyttsx3` භාවිතා කරනවා. Windows එකේ ඇති voice provider එක අනුව Sinhala voice availability වෙනස් වෙනවා. වඩා හොඳ Sinhala voice එකක් සඳහා පසුව Coqui/Piper Sinhala model එකක් plug-in කළ හැකි පරිදි engine එක වෙන් කරලා තියෙනවා.

## V42.19.1 fixes
- `tempfile` import missing in app.py (local voice turn NameError) - fixed.
- Singlish (romanised Sinhala) detection + control commands: "pump eka on karanna 20 seconds", "pompaya nawattanna", "watura danna", "auto eka off".
- Reply language follows the speaker (Sinhala script reply for Sinhala/Singlish input).
- Duplicate user message to Ollama removed; helpful errors when Ollama/model missing; falls back to Groq if key set and Ollama is down.
- No Sinhala voice in pyttsx3 -> falls back to Google TTS (or set SMARTPLANT_COQUI_MODEL for a Coqui Sinhala model).
- Better Sinhala STT: `set SMARTPLANT_WHISPER_MODEL=medium` (or large-v3, or a path to a fine-tuned .pt).

## V42.19.2 - Memory
- "remember that ...", "... mathak thiyaganna", "... මතක තියාගන්න" -> saved permanently (SQLite, survives restart).
- Last chat turns are also stored, so the AI continues the conversation after restart.
- "memory eka clear karanna" / "මතකය මකන්න" clears it. API: GET /api/local-voice/memory, POST /api/local-voice/memory/clear.
- Whisper now auto-picks Sinhala vs English from the audio even if the UI language is English.
