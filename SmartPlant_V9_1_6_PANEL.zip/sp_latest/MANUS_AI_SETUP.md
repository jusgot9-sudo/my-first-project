# Manus AI for SmartPlant

SmartPlant can use the Manus API as its AI provider. The PC server calls `https://api.manus.ai` and keeps the key on the PC; the Android APK never receives the key.

## Configure securely on Windows

Do not paste the key into chat, source code, JavaScript, GitHub files, or the APK. Set it in the Windows user environment before starting the PC app:

```powershell
[Environment]::SetEnvironmentVariable('MANUS_API_KEY', 'PASTE_A_NEW_KEY_HERE', 'User')
```

Restart SmartPlant after setting it. The server reads `MANUS_API_KEY`, calls the Manus v2 task API with a private task and strict structured output, then applies only the existing SmartPlant safety-checked actions. If the key is saved through a future settings UI, it is stored in `manus_api_key.bin` using Windows DPAPI, just like the existing Groq key path.

The response schema is restricted to a short reply, one of `pump_on`, `pump_off`, `auto_on`, `auto_off`, or null, and an optional integer duration. The PC server still validates telemetry, tank safety, maximum runtime, and controller availability before executing any action.

## Important

The API key shown in the chat must be revoked and replaced because it was exposed. This project intentionally does not contain that key. The provider status is available from `/api/ai/health` and reports only whether a key exists, never the key itself.
